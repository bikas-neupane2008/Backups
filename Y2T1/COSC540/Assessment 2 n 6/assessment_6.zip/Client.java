import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.Arrays;

public class Client {
	private static final int TIMEOUT = 5000; // Timeout for socket operations, in milliseconds

	// Method to send a command to the server and receive a response
	private static String sendCommand(Socket serverSocket, String command) throws IOException {
		// Creating PrintWriter for sending data to the server
		PrintWriter out = new PrintWriter(serverSocket.getOutputStream(), true);
		// Creating BufferedReader for receiving data from the server
		BufferedReader in = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
		// Sending the command to the server
		out.println(command);
		// Reading the response from the server
		return in.readLine();
	}

	// Method to validate the username entered by the user
	private static boolean validateUsername(String username) {
		// Checking if the username contains spaces
		if (username.contains(" ")) {
			System.out.println("Error: Username cannot contain spaces");
			return false;
		}
		return true;
	}

	// Method to process the response received from the server
	private static void processResponse(String response) {
		// If there are no more unread messages
		if (response.equals("No More Unread Messages.")) {
			System.out.println(response);
		} else {
			// Splitting the response into parts
			String[] parts = response.split(" ");
			// Extracting the remaining unread message count
			int remainingUnreadCount = Integer.parseInt(parts[0]);
			// Extracting the sender's username
			String sender = parts[1];
			// Extracting the message content
			String message = String.join(" ", Arrays.copyOfRange(parts, 2, parts.length));
			// Displaying the unread message details
			System.out.printf("UNREAD MESSAGE:\nSent By: %s\nMessage: %s\nNow there are %d unread messages.\n", sender, message, remainingUnreadCount);
		}
	}

	// Method to start the client and establish connection with the server
	private static void startClient(String host, int port) {
		Socket serverSocket = null; // Socket for communicating with the server
		Scanner scanner = new Scanner(System.in); // Scanner for user input
		try {
			// Establishing connection with the server
			serverSocket = new Socket(host, port);
			serverSocket.setSoTimeout(TIMEOUT); // Setting socket timeout
			PrintWriter out = new PrintWriter(serverSocket.getOutputStream(), true);
			BufferedReader in = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
			System.out.print("Enter your username: ");
			String username = scanner.nextLine();
			// Validating the username entered by the user
			while (!validateUsername(username)) {
				System.out.print("Enter your username: ");
				username = scanner.nextLine();
			}
			// Sending LOGIN command to the server with the username
			System.out.println(sendCommand(serverSocket, "LOGIN " + username));
			// Main loop for handling user commands
			while (true) {
				System.out.print("Enter command (COMPOSE, READ, EXIT): ");
				String command = scanner.nextLine().trim().toUpperCase();
				if (command.equals("COMPOSE")) {
					String recipient = "";
					System.out.print("Enter recipient's username: ");
					recipient = scanner.nextLine();
					while (!validateUsername(recipient)) {
						System.out.print("Enter recipient's username: ");
						recipient = scanner.nextLine();
					}
					System.out.print("Enter message: ");
					String message = scanner.nextLine();
					// Sending COMPOSE command to the server with sender, recipient, and message
					System.out.println(sendCommand(serverSocket, "COMPOSE " + username + " " + recipient + " " + message));
				} else if (command.equals("READ")) {
					// Sending READ command to the server with the username
					String response = sendCommand(serverSocket, "READ " + username);
					// Processing and displaying the response
					processResponse(response);
				} else if (command.equals("EXIT")) {
					// Sending EXIT command to the server
					sendCommand(serverSocket, "EXIT");
					System.out.println("Sorry to see you go");
					break;
				} else {
					System.out.println("Invalid command.");
				}
			}
		} catch (UnknownHostException e) {
			System.err.println("Unknown host: " + host);
		} catch (IOException e) {
			System.err.println("Error: " + e.getMessage());
		} finally {
			try {
				// Closing the socket and scanner
				if (serverSocket != null)
					serverSocket.close();
				scanner.close();
			} catch (IOException e) {
				System.err.println("Error closing socket: " + e.getMessage());
			}
		}
	}

	// Main method to start the client
	public static void main(String[] args) {
		// Checking command-line arguments
		if (args.length != 2) {
			System.out.println("Usage: java Client <hostname> <port>");
			System.exit(1);
		}
		String host = args[0]; // Server hostname
		int port = Integer.parseInt(args[1]); // Server port number
		startClient(host, port); // Starting the client
	}
}