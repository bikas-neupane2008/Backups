#!/bin/bash

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <host> <port>"
    exit 1
fi

host=$1
port=$2

# Compile Client.java
javac Client.java

# Check if compilation was successful
if [ $? -eq 0 ]; then
    # Run Client.class with java
    echo "Compilation successful. Running Client"
    java Client $host $port
else
    echo "Compilation failed. Exiting..."
    exit 1
fi

