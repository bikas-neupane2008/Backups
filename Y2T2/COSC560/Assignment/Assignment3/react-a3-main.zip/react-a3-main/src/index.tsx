// src/index.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'; // Import Navigate for redirects
import './index.css';
import Home from './pages/Home';
import PostDetail from './components/PostDetail';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);

root.render(
  <React.StrictMode>
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />   {/* Homepage route */}
        <Route path="/post/:id" element={<PostDetail />} /> {/* Post detail route */}
        
        {/* Redirect any direct attempt to access /post without ID to the homepage */}
        <Route path="/post" element={<Navigate to="/" />} />
        
        {/* Catch-all route to handle non-existent routes */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  </React.StrictMode>
);

reportWebVitals();
