// src/components/PostDetail.tsx
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import homeStyles from '../styles/Home.module.css';
import Spinner from './Spinner';
import Header from './Header'; // Import Header

const PostDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>(); // Get the post ID from the URL
  const [post, setPost] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`https://blog_assignment1.test/api/posts/${id}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to fetch post');
        }
        return response.json();
      })
      .then((data) => setPost(data))
      .catch((error) => setError(error.message))
      .finally(() => setLoading(false));
  }, [id]);

  const handleBack = () => {
    if (window.history.length > 2) {
      navigate(-1); // Go back to previous page if possible
    } else {
      navigate('/post'); // Fallback to post list
    }
  };

  if (loading) {
    return <Spinner />;
  }

  if (error) {
    return (
      <div>
        <Header /> {/* Add Header here */}
        <p>Error fetching post: {error}</p>
        <button className={homeStyles.backButton} onClick={handleBack}>
          Go Back
        </button>
      </div>
    );
  }

  if (!post) {
    return (
      <div>
        <Header /> {/* Add Header here */}
        <p>Post not found!</p>
        <button className={homeStyles.backButton} onClick={handleBack}>
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div>
      <Header /> {/* Add Header here */}
      <div className={homeStyles.postDetail}>
        <button className={homeStyles.backButton} onClick={handleBack}>
          Back
        </button>
        <h1>{post.title || 'No title available'}</h1>
        <p>{post.content || 'No content available'}</p>
        <p className={homeStyles.metadata}>
          Created at: {new Date(post.created_at).toLocaleDateString()}
          <br />
          Updated at: {new Date(post.updated_at).toLocaleDateString()}
          <br />
          Updated by: {post.user?.email || 'Unknown'}
        </p>
      </div>
    </div>
  );
};

export default PostDetail;
