// src/components/Pagination.tsx
import React from 'react';
import homeStyles from '../styles/Home.module.css';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  handleNextPage: () => void;
  handlePreviousPage: () => void;
}

const Pagination: React.FC<PaginationProps> = ({ currentPage, totalPages, handleNextPage, handlePreviousPage }) => {
  return (
    <div className={homeStyles.pagination}>
      <button onClick={handlePreviousPage} disabled={currentPage === 1}>
        Previous
      </button>
      <span className={homeStyles.pageInfo}>
        Page {currentPage} of {totalPages}
      </span>
      <button onClick={handleNextPage} disabled={currentPage === totalPages}>
        Next
      </button>
    </div>
  );
};

export default Pagination;
