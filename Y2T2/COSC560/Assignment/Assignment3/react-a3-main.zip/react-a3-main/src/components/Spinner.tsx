// src/components/Spinner.tsx
import React from 'react';
import homeStyles from '../styles/Home.module.css';

const Spinner: React.FC = () => {
  return <div className={homeStyles.spinner}>Loading posts...</div>;
};

export default Spinner;
