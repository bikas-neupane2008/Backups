// src/components/Footer.tsx
import React from 'react';
import homeStyles from '../styles/Home.module.css';

const Footer: React.FC = () => {
  return (
    <footer className={homeStyles.footer}>
      <p>&copy; 2024 Blogs App. All Rights Reserved.<br /> &copy; bneupan2@myune.edu.au</p>
    </footer>
  );
};

export default Footer;
