// src/components/Header.tsx
import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import homeStyles from '../styles/Home.module.css';

const Header: React.FC = () => {
  return (
    <header className={homeStyles.header}>
      <Link to="/post" className={homeStyles.header}>
        Blogs App
      </Link>
    </header>
  );
};

export default Header;
