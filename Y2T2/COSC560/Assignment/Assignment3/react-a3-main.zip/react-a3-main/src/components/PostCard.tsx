// src/components/PostCard.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import homeStyles from '../styles/Home.module.css';

interface PostCardProps {
  _id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
  user?: {
    email: string;
  };
}

const PostCard: React.FC<PostCardProps> = ({ _id, title, content, created_at, updated_at, user }) => {
  return (
    <Link to={`/post/${_id}`} className={homeStyles.postLink}>
      <div className={homeStyles.post}>
        <h2 className={homeStyles.title}>
          {title.length > 30 ? title.slice(0, 30) + '...' : title || 'Untitled'}
        </h2>
        <p className={homeStyles.content}>
          {content.length > 200 ? content.slice(0, 200) + '...' : content || 'No content available.'}
          {content.length > 200 && <span> Read more</span>}
        </p>
        <p className={homeStyles.metadata}>
          Created at: {new Date(created_at).toLocaleDateString()}
          <br />
          Updated at: {new Date(updated_at).toLocaleDateString()}
          <br />
          Updated by: {user?.email || 'Unknown'}
        </p>
      </div>
    </Link>
  );
};

export default PostCard;
