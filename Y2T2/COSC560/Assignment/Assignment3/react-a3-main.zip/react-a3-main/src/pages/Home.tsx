import React, { useEffect } from 'react';
import Header from '../components/Header';
import PostList from '../components/PostList';
import Footer from '../components/Footer';

const Home: React.FC = () => {
  // Update the document title when the Home component loads
  useEffect(() => {
    document.title = 'Blog Frontend'; // Set the title to 'Blog Frontend'
  }, []); // Empty dependency array ensures this runs only on component mount

  return (
    <>
      <Header />
      <main>
        <PostList />
      </main>
      <Footer />
    </>
  );
};

export default Home;
