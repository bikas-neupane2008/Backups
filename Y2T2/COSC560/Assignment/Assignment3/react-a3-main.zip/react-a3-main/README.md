# myblog
# Assignment 3: ReactJS Blog Application
# GitHub Repository
The ReactJS project repository can be found here: <https://github.com/bikas-neupane2008/react-a3>
# ReactJS Blog Application
This project is the frontend application built using **ReactJS** with **TypeScript** that connects to the Laravel backend API to display a list of blog posts and their detailed view. It uses **fetch API** to retrieve data from the Laravel backend and **CSS** for styling the pages.
## Requirements
- Node.js
- NPM (Node Package Manager)
- A running instance of the **Laravel Blog API** (backend)
## Installation
1. Clone the repository:
```bash
git clone https://github.com/bikas-neupane2008/react-a3
```
2. Change to the project directory:
```bash
cd blog-frontend
```
3. Install dependencies:
```bash
npm install
```
4. Run the React development server:
```bash
npm start
```
This will start the React development server and the application will be available at `http://localhost:3000`.
## Features
### 1. Blog List Page:
- Displays a list of blog posts fetched from the Laravel backend.
- Each post card shows the title, content snippet, creation and update dates, and the user’s email.
- Users can click on a post to view its details.
### 2. Blog Detail Page:
- Shows the full content of a selected blog post.
- Includes details like the post’s creation date, last update date, and the user who created/updated it.
- A "Back" button allows navigation back to the post list.
### 3. Pagination:
- Implements pagination to make the list of blog posts more navigable, with **Previous** and **Next** buttons.
- Displays the current page and total number of pages.
### 4. Error Handling and Loading States:
- A loading spinner is displayed while posts are being fetched from the API.
- Proper error handling if the data fails to load, showing error messages if the API request fails.
### 5. CSS Styling:
- Custom CSS styles are applied for a better user experience.
- The application is responsive, ensuring it works well on various screen sizes.
## Components
- **Home.tsx**: The main page component that renders the list of posts using `PostList.tsx`.
- **PostDetail.tsx**: Displays the details of a single post based on the post ID from the URL.
- **PostList.tsx**: Displays a list of blog posts with pagination controls.
- **PostCard.tsx**: Renders individual blog post cards with a summary of each post.
- **Pagination.tsx**: A component that manages pagination for the post list.
- **Header.tsx** and **Footer.tsx**: Common components used across the application for consistent layout and navigation.
- **Spinner.tsx**: A spinner component used to display a loading indicator while waiting for the data to be fetched.
## API Integration
The application fetches data from the **Laravel backend API** using the **Fetch API**. The following API endpoints are used:
- **GET /api/posts**: Fetches the list of all blog posts.
- **GET /api/posts/{id}**: Fetches the details of a specific blog post by its ID.
### Fetching Data Example:
```typescript
useEffect(() => {
  fetch(`${process.env.REACT_APP_API_URL}/posts`)
    .then(response => response.json())
    .then(data => setPosts(data))
    .catch(error => console.error('Error fetching posts:', error));
}, []);
```
## Testing
### Backend API Testing:
To ensure the application works correctly with the backend, the following tests were performed using **Postman**:
- **GET /api/posts**: Verified that the list of blog posts is correctly retrieved.
- **GET /api/posts/{id}**: Verified that individual post details are fetched correctly.
### Frontend Testing:
- Tested the **pagination** to ensure it works correctly when navigating between pages of blog posts.
- Checked that all post data, including the user email, displays correctly in both the list view and detail view.
- Verified that errors are displayed properly when API requests fail.
## Challenges and Approach
1. **Fetching Data and Handling Errors**:
    - Handling errors from the API and ensuring that error messages are displayed to the user was a key challenge. This was handled by properly setting error states in the components.
2. **Pagination**:
    - Implementing pagination required calculating the number of posts per page and ensuring proper navigation between pages. This was achieved using React's state management and handling pagination clicks.
3. **Styling**:
    - Custom CSS was used to ensure the application was responsive, visually appealing, and user-friendly. Particular attention was given to layout consistency and ease of navigation.











# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can’t go back!**

If you aren’t satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you’re on your own.

You don’t have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn’t feel obligated to use this feature. However we understand that this tool wouldn’t be useful if you couldn’t customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).
