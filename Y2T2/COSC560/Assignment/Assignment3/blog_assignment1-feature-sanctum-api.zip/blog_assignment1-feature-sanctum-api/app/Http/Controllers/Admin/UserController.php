<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        // Middleware to check if the user is an admin
        $this->middleware(function ($request, $next) {
            if (Auth::check() && Auth::user()->role !== 'admin') {
                return redirect('/'); // Redirect non-admin users to the home page
            }
            return $next($request);
        });
    }

    /**
     * Display a listing of the users.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::orderBy('created_at', 'desc')->paginate(10); // Admin can view all users
        return view('admin.users.index', compact('users'));
    }

    /**
     * Show the form for creating a new user.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.users.create'); // Admin can create new users
    }

    /**
     * Store a newly created user in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:admin,author,user',
        ]);

        User::create([
            'name' => $validatedData['name'],
            'email' => $validatedData['email'],
            'password' => Hash::make($validatedData['password']),
            'role' => $validatedData['role'],
        ]);

        return redirect()->route('admin.users.index')->with('success', 'User created successfully.');
    }

    /**
     * Display the specified user.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        return view('admin.users.show', compact('user')); // Admin can view user details
    }

    /**
     * Show the form for editing the specified user.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        return view('admin.users.edit', compact('user')); // Admin can edit any user
    }

    /**
     * Update the specified user in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        // Validate the request data (no need for the unique email rule)
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'role' => 'required|in:admin,author,user',
            'password' => 'nullable|string|min:8|confirmed',
        ]);

        // Find the user by email, excluding the current user by ID
        $existingUser = User::where('email', $validatedData['email'])->where('_id', '!=', $user->id)->first();

        if ($existingUser) {
            // If another user with the same email exists, update the existing user
            $existingUser->name = $validatedData['name'];
            $existingUser->role = $validatedData['role'];

            if (!empty($validatedData['password'])) {
                $existingUser->password = Hash::make($validatedData['password']);
            }

            $existingUser->save();

            return redirect()->route('admin.users.index')->with('success', 'User updated successfully.');
        } else {
            // If no user with the email exists, update the current user
            $user->name = $validatedData['name'];
            $user->email = $validatedData['email'];
            $user->role = $validatedData['role'];

            if (!empty($validatedData['password'])) {
                $user->password = Hash::make($validatedData['password']);
            }

            $user->save();

            return redirect()->route('admin.users.index')->with('success', 'User updated successfully.');
        }
    }


    /**
     * Remove the specified user from storage.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Find the user by ID
        $user = User::findOrFail($id);

        // Prevent the authenticated user from deleting their own account
        if (auth()->user()->_id == $user->_id) {
            return redirect()->route('admin.users.index')->with('error', 'You cannot delete your own account.');
        }

        // Check if the user has any posts
        $posts = Post::where('user_id', $user->_id)->get();

        if ($posts->isNotEmpty()) {
            // Delete all posts associated with the user
            Post::where('user_id', $user->_id)->delete();
        }

        // Delete the user regardless of whether they had posts
        $user->delete();

        // Redirect back to the users index with a success message
        return redirect()->route('admin.users.index')->with('success', $posts->isNotEmpty() ? 'User and all related posts deleted successfully.' : 'User deleted successfully.');
    }


    public function search(Request $request)
    {
        $query = $request->get('query');
        $role = $request->get('role');

        // Fetch users based on the role and query (searching only by email)
        $users = User::where('role', $role)
            ->where('email', 'LIKE', "%$query%")
            ->get();

        return response()->json(['users' => $users]);
    }
}
