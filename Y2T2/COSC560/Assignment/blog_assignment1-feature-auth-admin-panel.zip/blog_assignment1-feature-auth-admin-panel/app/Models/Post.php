<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use MongoDB\Laravel\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Post extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'content', 'user_id'];

    protected static function booted()
    {
        static::creating(function (Post $post) {
            // Only set the user_id if it's not already set
            if (auth()->check() && is_null($post->user_id)) {
                $post->user_id = Auth::id();
            }
        });
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', '_id');
    }
}
