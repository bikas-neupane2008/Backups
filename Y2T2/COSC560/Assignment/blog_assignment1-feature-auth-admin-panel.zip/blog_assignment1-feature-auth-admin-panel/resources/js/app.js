import './bootstrap';

import './dashboard';

import './color-modes';

import '@docsearch/js';

