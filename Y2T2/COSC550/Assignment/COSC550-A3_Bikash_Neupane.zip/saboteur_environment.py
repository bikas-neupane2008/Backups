import random
from game_board import GameBoard, GOAL_LOCATIONS
from une_ai.models import GameEnvironment, Agent
from deck import Deck
from card import Card, PathCard, ActionCard
import copy

PLAYER_ROLES = ('Gold-Digger', 'Saboteurs')
NUM_PLAYERS = 8


def assign_roles():
    num_saboteurs = random.choice([2, 3])
    roles = ['Saboteurs'] * num_saboteurs + ['Gold-Digger'] * (NUM_PLAYERS - num_saboteurs)
    random.shuffle(roles)
    print(f"[DEBUG] Assigned roles: {roles}")
    return roles


_roles = assign_roles()

BOARD_SIZE = 20
HAND_SIZE = 4
ACTION_TYPES = ('play', 'map', 'sabotage', 'mend', 'dynamite', 'pass')

DIRECTIONS = ('north', 'east', 'south', 'west')
DIRECTION_OFFSET = {
    'north': (0, -1),
    'south': (0, 1),
    'west': (-1, 0),
    'east': (1, 0)
}

START_POS = (6, 10)
GOAL_CARDS = GOAL_LOCATIONS


class SaboteurEnvironment(GameEnvironment):
    def __init__(self):
        super().__init__("Saboteur Environment")
        print("[DEBUG] Initializing Saboteur Environment")

        self._players: dict[int, tuple[Agent, str]] = {}
        self._players_hands: dict[int, list[Card]] = {}
        self._sabotaged_players: list[bool] = [False] * NUM_PLAYERS
        self._game_board = GameBoard()
        self._deck = Deck()
        self._deck.shuffle()
        self._player_turn = random.randint(0, NUM_PLAYERS - 1)
        self._move_list: list[str] = []
        print(f"[DEBUG] Initial player turn: {self._player_turn}")

    def add_player(self, player: Agent):
        assert len(self._players) < NUM_PLAYERS, "Cannot add more than 8 players"
        player_id = len(self._players)
        role = _roles[player_id]
        self._players[player_id] = (player, role)
        self._players_hands[player_id] = [self._deck.draw() for _ in range(HAND_SIZE)]
        print(f"[DEBUG] Added player {player_id} with role {role} and hand: {self._players_hands[player_id]}")
        return player_id

    def get_player_role(self, player_id):
        print(f"[DEBUG] Getting role for player {player_id}: {self._players[player_id][1]}")
        return self._players[player_id][1]

    def get_all_roles(self):
        roles = {i: role for i, (player, role) in self._players.items()}
        print(f"[DEBUG] All player roles: {roles}")
        return roles

    def get_game_board(self):
        print("[DEBUG] Getting current game board.")
        return self._game_board

    def get_game_board_gridmap(self):
        print("[DEBUG] Getting game board gridmap.")
        return self._game_board.get_board()

    def set_environment(self, game_state: dict):
        self._deck = game_state['game-deck']
        self._game_board = game_state['game-board']
        self._player_turn = game_state['player-turn']
        self._players_hands = game_state['player-hands']
        self._sabotaged_players = game_state['sabotaged-players']
        print(f"[DEBUG] Environment set with new game state: {game_state}")

    def turn(self, game_state=None):
        if game_state is None:
            print(f"[DEBUG] Current player turn: {self._player_turn}")
            return self._player_turn
        else:
            print(f"[DEBUG] Returning player turn from game state: {game_state['player-turn']}")
            return game_state['player-turn']

    def get_game_state(self):
        game_state = {
            'game-board': self._game_board.get_board(),
            'game-deck': self._deck,
            'sabotaged-players': self._sabotaged_players,
            'player-turn': self._player_turn,
            'player-hands': self._players_hands,
        }
        print(f"[DEBUG] Returning game state: {game_state}")
        return game_state

    def get_percepts(self):
        cur_player = self.turn()
        percepts = {
            'game-board-sensor': self._game_board.get_board(),
            'player-turn': cur_player,
            'player-hand': self._players_hands[cur_player].copy(),
            'player-role': self._players[cur_player][1],
            'sabotaged-players': self._sabotaged_players.copy()
        }
        print(f"[DEBUG] Returning percepts for player {cur_player}: {percepts}")
        return percepts

    def state_transition(self, agent_actuators):
        card_selected = agent_actuators['card-selected']
        action_type = agent_actuators['play-type']
        player_id = self._player_turn
        played_card = self._players_hands[player_id][card_selected]
        print(f"[DEBUG] Player {player_id} is attempting action {action_type} with card {played_card}")

        if action_type == 'play':
            params = [card_selected, agent_actuators['position'][0], agent_actuators['position'][1],
                      agent_actuators['card-turned']]
            try:
                self._handle_play_action(params, played_card)
            except ValueError as e:
                print(f"[ERROR] Invalid play action: {e}")
                return
        elif action_type == 'map':
            params = [card_selected, agent_actuators['position'][0], agent_actuators['position'][1],
                      agent_actuators['tell-truth']]
            self._handle_map_action(params, played_card)
        elif action_type == 'dynamite':
            params = [card_selected, agent_actuators['position'][0], agent_actuators['position'][1]]
            self._handle_dynamite_action(params, played_card)
        elif action_type in ['sabotage', 'mend']:
            params = [card_selected, agent_actuators['player-select']]
            self._handle_sabotage_mend_action(action_type, params, played_card)
        elif action_type == 'pass':
            print("[DEBUG] Player passed their turn.")

        self._players_hands[player_id].remove(played_card)
        if self._deck:
            drew_card = self._deck.draw()
            if drew_card is not None:
                self._players_hands[player_id].append(drew_card)
                print(f"[DEBUG] Player {player_id} drew a new card: {drew_card}")

        self._player_turn = (player_id + 1) % NUM_PLAYERS
        print(f"[DEBUG] Next player turn: {self._player_turn}")

    def _handle_play_action(self, params, played_card):
        print(f"[DEBUG] Handling play action with params: {params}, card: {played_card}")
        assert isinstance(played_card, PathCard)
        x, y, turned = int(params[1]), int(params[2]), params[3] == "True"

        if turned:
            played_card.turn_card()
            print(f"[DEBUG] Played card turned.")

        self._game_board.add_path_card(x, y, played_card)
        print(f"[DEBUG] Added path card to board at ({x}, {y})")

        for goal_x, goal_y in GOAL_LOCATIONS:
            if abs(goal_x - x) <= 1 and abs(goal_y - y) <= 1:
                goal_card = self._game_board.get_board().get_item_value(goal_x, goal_y)
                if goal_card and not goal_card.is_revealed():
                    goal_card.reveal_card()
                    print(f"[DEBUG] Revealed goal card at ({goal_x}, {goal_y})")

    def _handle_map_action(self, params, played_card: ActionCard):
        x, y = int(params[1]), int(params[2])
        tell_truth = params[3] == "True"
        goal_card = self._game_board.get_board().get_item_value(x, y)
        real_answer = "gold" if goal_card.is_gold() else None
        revealed_info = real_answer if tell_truth else ("gold" if real_answer is None else None)
        print(f"[DEBUG] Map action at ({x}, {y}), revealed: {revealed_info}")

    def _handle_dynamite_action(self, params, played_card: ActionCard):
        x, y = int(params[1]), int(params[2])
        self._game_board.remove_path_card(x, y)
        print(f"[DEBUG] Dynamite action removed path card at ({x}, {y})")

    def _handle_sabotage_mend_action(self, action_type, params, played_card: ActionCard):
        player_index = int(params[1])
        is_sabotage = action_type == 'sabotage'
        self._sabotaged_players[player_index] = is_sabotage
        print(f"[DEBUG] {action_type.capitalize()} action on player {player_index}")

    @staticmethod
    def generate_playable_pathcards(players_hand, game_board):
        print("[DEBUG] Generating playable path cards.")
        actions = []
        path_cards = [(players_hand[index], index, False) for index in range(len(players_hand)) if
                      isinstance(players_hand[index], PathCard)]
        tuned_path_cards = [(copy.deepcopy(card).turn_card(), index, True) for card, index, _ in path_cards]
        all_path_cards = path_cards + tuned_path_cards
        seen_index = []
        queue = [START_POS]

        while len(queue) > 0:
            to_check = queue.pop()
            if to_check in seen_index:
                continue
            seen_index.append(to_check)
            item = game_board.get_board().get_item_value(*to_check)
            if item is None:
                continue
            exits = item.get_exits()

            for dir in exits:
                board_path, new_pos = game_board.future_state(to_check, dir)
                if new_pos is None:
                    continue
                if board_path is not None:
                    queue.append(new_pos)
                    continue
                for path_card, index, turned in all_path_cards:
                    actions.append(f"play-{index}-{new_pos[0]}-{new_pos[1]}-{turned}")
        print(f"[DEBUG] Playable path cards generated: {actions}")
        return actions

    @staticmethod
    def generate_playable_actions(current_player, players_hand, sabotaged_players, game_board):
        print("[DEBUG] Generating playable actions.")
        actions = []
        action_cards = [(players_hand[index], index) for index in range(len(players_hand)) if
                        isinstance(players_hand[index], ActionCard)]

        for card, index in action_cards:
            card_action = card.get_action()
            if card_action == 'map':
                for pos_goal in GOAL_CARDS:
                    for tell_truth in [True, False]:
                        actions.append(f"map-{index}-{pos_goal[0]}-{pos_goal[1]}-{tell_truth}")
            elif card_action == 'dynamite':
                for x in range(BOARD_SIZE):
                    for y in range(BOARD_SIZE):
                        item = game_board.get_board().get_item_value(x, y)
                        if item and not item.is_special_card():
                            actions.append(f"dynamite-{index}-{x}-{y}")
            elif card_action == 'sabotage':
                for i in range(NUM_PLAYERS):
                    if not sabotaged_players[i] and i != current_player:
                        actions.append(f"sabotage-{index}-{i}")
            elif card_action == 'mend':
                for i in range(NUM_PLAYERS):
                    if sabotaged_players[i]:
                        actions.append(f"mend-{index}-{i}")

        print(f"[DEBUG] Playable actions generated: {actions}")
        return actions

    def get_legal_actions(self, game_state=None):
        print("[DEBUG] Getting legal actions.")
        actions = []

        if game_state is None or not isinstance(game_state, dict):
            current_player = self._player_turn
            players_hand = self._players_hands[current_player]
        else:
            current_player = game_state['player-turn']
            players_hand = game_state['player_hands'][current_player]

        if not self._sabotaged_players[current_player]:
            actions += SaboteurEnvironment.generate_playable_pathcards(players_hand, self._game_board)

        actions += SaboteurEnvironment.generate_playable_actions(current_player, players_hand, self._sabotaged_players,
                                                                 self._game_board)

        for i in range(len(players_hand)):
            actions.append(f"pass-{i}")

        print(f"[DEBUG] Legal actions: {actions}")
        return actions

    @staticmethod
    def generate_legal_moves_from_percepts(percepts):
        print("[DEBUG] Generating legal moves from percepts.")
        actions = []

        current_player = percepts['player-turn']
        game_board = percepts['game-board-sensor']
        players_hand = percepts['player-hand']
        sabotaged_players = percepts['sabotaged-players']

        if not sabotaged_players[current_player]:
            actions += SaboteurEnvironment.generate_playable_pathcards(players_hand, GameBoard(game_board))

        actions += SaboteurEnvironment.generate_playable_actions(current_player, players_hand, sabotaged_players,
                                                                 GameBoard(game_board))

        for i in range(len(players_hand)):
            actions.append(f"pass-{i}")

        print(f"[DEBUG] Legal moves from percepts: {actions}")
        return actions

    def is_terminal(self, game_state=None):
        print("[DEBUG] Checking if game state is terminal.")
        for goal_x, goal_y in GOAL_LOCATIONS:
            goal_card = self._game_board.get_board().get_item_value(goal_x, goal_y)
            if goal_card and goal_card.is_gold() and self._game_board.is_connected(START_POS, (goal_x, goal_y)):
                print("[DEBUG] Gold-Diggers win condition met.")
                return True

        if self.all_players_hands_empty() or not self.any_legal_moves():
            print("[DEBUG] No legal moves or empty hands, game is terminal.")
            return True

        print("[DEBUG] Game is not terminal.")
        return False

    def all_players_hands_empty(self):
        all_empty = all(len(hand) == 0 for hand in self._players_hands.values())
        print(f"[DEBUG] Checking if all players' hands are empty: {all_empty}")
        return all_empty

    def any_legal_moves(self):
        for player_id in range(NUM_PLAYERS):
            if len(self.get_legal_actions(player_id)) > 0:
                print(f"[DEBUG] Player {player_id} has legal moves.")
                return True
        print("[DEBUG] No legal moves available for any player.")
        return False

    def get_winner_self(self):
        print("[DEBUG] Determining the winner.")
        for goal_x, goal_y in GOAL_LOCATIONS:
            goal_card = self._game_board.get_board().get_item_value(goal_x, goal_y)
            if goal_card and goal_card.is_gold() and self._game_board.is_connected(START_POS, (goal_x, goal_y)):
                print("[DEBUG] Gold-Diggers win!")
                return 'Gold-Diggers'

        print("[DEBUG] Saboteurs win!")
        return 'Saboteurs'

    @staticmethod
    def get_winner(game_state):
        print("[DEBUG] Determining winner from game state.")
        new_env = SaboteurEnvironment()
        new_env.set_environment(game_state)
        return new_env.get_winner_self()

    @staticmethod
    def transition_result(game_state: dict, action: str):
        print(f"[DEBUG] Transitioning game state with action: {action}")
        new_env = SaboteurEnvironment()
        new_env.set_environment(game_state)
        new_env.state_transition(action)
        return new_env.get_game_state()

    def payoff_self(self, player_name):
        if not self.is_terminal():
            return 0
        winner = self.get_winner_self()
        if self._players[player_name][1] == winner:
            return 1
        else:
            return -1

    @staticmethod
    def payoff(game_state, player_name):
        print(f"[DEBUG] Calculating payoff for player: {player_name}")
        new_env = SaboteurEnvironment()
        new_env.set_environment(game_state)
        return new_env.payoff_self(player_name)
