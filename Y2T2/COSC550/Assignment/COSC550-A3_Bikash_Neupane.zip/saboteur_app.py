from saboteur_environment import SaboteurEnvironment, NUM_PLAYERS
from saboteur_game import SaboteurGame, GameGUI
from saboteur_player import SaboteurPlayer
from agent_program import agent_program_random, agent_program_gold_digger, agent_program_saboteur

if __name__ == "__main__":
    # Initialize the environment
    print("[DEBUG] Initializing Saboteur environment...")
    env = SaboteurEnvironment()

    # Adding players
    print(f"[DEBUG] Adding {NUM_PLAYERS} players to the game...")
    for i in range(NUM_PLAYERS):
        # Add a player to the environment
        player_id = env.add_player(SaboteurPlayer(f"Player_{i}", agent_program_gold_digger))
        print(f"[DEBUG] Player added: ID = {player_id}, Name = Player_{i}")

        # Get and print player role
        role = env.get_player_role(player_id)
        print(f"[DEBUG] Player_{i} assigned role: {role}")

        # Assign the correct agent program based on role and print the assignment
        if role == 'Gold-Digger':
            env._players[player_id] = (SaboteurPlayer(f"Player_{i}", agent_program_gold_digger), role)
            print(f"[DEBUG] Player_{i} is a Gold-Digger and is assigned the gold digger agent program.")
        else:
            env._players[player_id] = (SaboteurPlayer(f"Player_{i}", agent_program_saboteur), role)
            print(f"[DEBUG] Player_{i} is a Saboteur and is assigned the saboteur agent program.")

        # Display player info
        print(f"[DEBUG] Player_{i} Info: Name = Player_{i}, Role = {role}, Agent Program = "
              f"{'Gold-Digger' if role == 'Gold-Digger' else 'Saboteur'}")

    # Start the game
    print("[DEBUG] Initializing Saboteur game...")
    saboteur_game = SaboteurGame(env)

    # Initialize the GUI
    print("[DEBUG] Launching Game GUI...")
    app = GameGUI(saboteur_game)
