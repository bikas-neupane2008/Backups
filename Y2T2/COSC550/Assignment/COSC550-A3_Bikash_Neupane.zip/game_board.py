from une_ai.models import GridMap
from card import PathCard
import random

GOAL_LOCATIONS = [(14, 8), (14, 10), (14, 12)]


class GameBoard:
    DIRECTIONS = ['north', 'south', 'east', 'west']
    OPPOSITES = {
        'north': 'south',
        'south': 'north',
        'east': 'west',
        'west': 'east',
    }
    DIRECTION_MOVEMENT: dict[str, tuple[int, int]] = {
        'north': (0, -1),
        'south': (0, 1),
        'east': (1, 0),
        'west': (-1, 0),
    }

    def __init__(self, board: GridMap | None = None):
        if board is not None:
            assert isinstance(board, GridMap), "board is not correct gridmap"
            self._board = board
            print("[DEBUG] Initialized GameBoard with an existing GridMap.")
            return

        print("[DEBUG] Initializing GameBoard with a 20x20 grid.")
        self._board = GridMap(20, 20, None)

        # Setting up the start and goal cards
        start_card = PathCard.cross_road(special_card='start')
        goal_cards = []
        gold_idx = random.choice([0, 1, 2])
        for i in range(3):
            if gold_idx == i:
                label = 'gold'
            else:
                label = 'goal'
            goal_cards.append(PathCard.cross_road(special_card=label))

        self._board.set_item_value(6, 10, start_card)
        print(f"[DEBUG] Set start card at position (6, 10).")

        goal_locations = [(14, 8), (14, 10), (14, 12)]
        for i, goal in enumerate(goal_cards):
            self._board.set_item_value(goal_locations[i][0], goal_locations[i][1], goal)
            print(f"[DEBUG] Set goal card at {goal_locations[i]} with label '{goal_cards[i]._special_card}'.")

    def get_board(self):
        print("[DEBUG] Returning current game board.")
        return self._board

    def is_connected(self, start_pos, goal_pos):
        print(f"[DEBUG] Checking if start_pos {start_pos} is connected to goal_pos {goal_pos}.")
        queue = [start_pos]
        visited = set([start_pos])

        while queue:
            current_pos = queue.pop(0)

            if current_pos == goal_pos:
                print("[DEBUG] Start and goal positions are connected.")
                return True

            current_card = self._board.get_item_value(current_pos[0], current_pos[1])
            if not current_card:
                continue

            exits = current_card.get_exits()
            for direction in exits:
                next_x, next_y = current_pos[0] + GameBoard.DIRECTION_MOVEMENT[direction][0], current_pos[1] + \
                                 GameBoard.DIRECTION_MOVEMENT[direction][1]
                next_pos = (next_x, next_y)

                if next_pos in visited or not (0 <= next_x < 20 and 0 <= next_y < 20):
                    continue

                next_card = self._board.get_item_value(next_x, next_y)
                if next_card and GameBoard.OPPOSITES[direction] in next_card.get_exits():
                    queue.append(next_pos)
                    visited.add(next_pos)

        print("[DEBUG] Start and goal positions are not connected.")
        return False

    def is_valid_placement(self, x, y, path_card):
        print(f"[DEBUG] Checking if the placement of card at ({x}, {y}) is valid.")
        existing_card = self._board.get_item_value(x, y)
        if existing_card is not None:
            print("[DEBUG] Invalid placement: A card already exists at the given coordinates.")
            return False

        for direction, movement in GameBoard.DIRECTION_MOVEMENT.items():
            adjacent_x, adjacent_y = x + movement[0], y + movement[1]

            if 0 <= adjacent_x < 20 and 0 <= adjacent_y < 20:
                adjacent_card = self._board.get_item_value(adjacent_x, adjacent_y)
                if adjacent_card is not None:
                    current_card_exits = path_card.get_exits()
                    adjacent_card_exits = adjacent_card.get_exits()

                    if direction in current_card_exits:
                        opposite_direction = GameBoard.OPPOSITES[direction]
                        if opposite_direction not in adjacent_card_exits:
                            print(f"[DEBUG] Invalid placement: Exit mismatch at ({adjacent_x}, {adjacent_y}).")
                            return False
        print("[DEBUG] Placement is valid.")
        return True

    def add_path_card(self, x, y, path_card):
        print(f"[DEBUG] Attempting to add path card at ({x}, {y}).")
        assert isinstance(path_card, PathCard), "The parameter path_card must be an instance of the class PathCard"
        assert 0 <= x < 20, "The x coordinate must be 0 <= x < 20"
        assert 0 <= y < 20, "The y coordinate must be 0 <= y < 20"

        if not self.is_valid_placement(x, y, path_card):
            raise ValueError(f"[ERROR] Invalid placement for the card at coordinates ({x}, {y})")

        self._board.set_item_value(x, y, path_card)
        print(f"[DEBUG] Path card added at ({x}, {y}).")

    def future_state(self, cur_location: tuple[int, int], direction: str):
        cur_x, cur_y = cur_location
        new_x, new_y = (cur_x + GameBoard.DIRECTION_MOVEMENT[direction][0],
                        cur_y + GameBoard.DIRECTION_MOVEMENT[direction][1])

        try:
            value: PathCard | None = self._board.get_item_value(new_x, new_y)
            new_location = (new_x, new_y)
            print(f"[DEBUG] Future state at ({new_x}, {new_y}) has card: {value}.")
        except:
            value = None
            new_location = None
            print(f"[DEBUG] Future state at ({new_x}, {new_y}) has no card.")

        return value, new_location

    def remove_path_card(self, x, y):
        print(f"[DEBUG] Attempting to remove path card at ({x}, {y}).")
        assert 0 <= x < 20, "The x coordinate must be 0 <= x < 20"
        assert 0 <= y < 20, "The y coordinate must be 0 <= y < 20"
        card_to_remove = self._board.get_item_value(x, y)
        assert card_to_remove is not None and not card_to_remove.is_special_card(), f"[ERROR] There is no valid card to remove at ({x}, {y})"

        self._board.set_item_value(x, y, None)
        print(f"[DEBUG] Path card removed from ({x}, {y}).")

    def __str__(self):
        no_card = '   \n   \n   '
        board_map = self._board.get_map()
        board_str = ''
        for row in board_map:
            for i in range(3):
                for card in row:
                    if card is None:
                        board_str += no_card.split('\n')[i]
                    else:
                        board_str += str(card).split('\n')[i]
                board_str += '\n'

        print("[DEBUG] Returning string representation of the game board.")
        return board_str


if __name__ == '__main__':
    board = GameBoard()
    path_card_cr = PathCard.cross_road()
    print("[DEBUG] Adding a crossroad path card at (7, 10).")
    board.add_path_card(7, 10, path_card_cr)

    print("[DEBUG] Removing the path card at (7, 10).")
    board.remove_path_card(7, 10)
