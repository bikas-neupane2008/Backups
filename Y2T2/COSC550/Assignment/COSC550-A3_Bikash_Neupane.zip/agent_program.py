import random
from saboteur_environment import SaboteurEnvironment, GOAL_LOCATIONS


def distance(pos1, pos2):
    dist = abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])
    print(f"[DEBUG] Calculating distance between {pos1} and {pos2}: {dist}")
    return dist


def is_path_near_goal(position, goal):
    near_goal = abs(position[0] - goal[0]) <= 1 and abs(position[1] - goal[1]) <= 1
    print(f"[DEBUG] Checking if position {position} is near goal {goal}: {near_goal}")
    return near_goal


def agent_program_pass(percepts, actuators):
    print(f"[DEBUG] Agent program pass activated.")
    return ['pass-0']


def agent_program_random(percepts, actuators):
    print(f"[DEBUG] Agent program random activated. Getting legal moves.")
    legal_moves = SaboteurEnvironment.generate_legal_moves_from_percepts(percepts)
    if len(legal_moves) > 0:
        chosen_move = random.choice(legal_moves)
        print(f"[DEBUG] Random legal move chosen: {chosen_move}")
        return [chosen_move]
    print(f"[DEBUG] No legal moves, defaulting to pass.")
    return agent_program_pass(percepts, actuators)


def gold_digger_heuristic(percepts, move):
    move_position = (int(move.split('-')[2]), int(move.split('-')[3]))
    closest_goal = min(GOAL_LOCATIONS, key=lambda goal: distance(move_position, goal))
    heuristic_value = -distance(move_position, closest_goal)
    print(f"[DEBUG] Gold Digger heuristic for move {move} at position {move_position}: {heuristic_value}")
    return heuristic_value


def agent_program_gold_digger(percepts, actuators):
    print(f"[DEBUG] Gold Digger agent activated. Getting legal moves.")
    legal_moves = SaboteurEnvironment.generate_legal_moves_from_percepts(percepts)
    game_board = percepts['game-board-sensor']
    start_pos = (6, 10)
    goal_locations = GOAL_LOCATIONS

    revealed_goals = []
    for goal_x, goal_y in goal_locations:
        goal_card = game_board.get_item_value(goal_x, goal_y)
        if goal_card and getattr(goal_card, '_revealed', False):
            revealed_goals.append((goal_x, goal_y))
            print(f"[DEBUG] Revealed goal found at: ({goal_x}, {goal_y})")

    if revealed_goals:
        for move in legal_moves:
            if move.startswith('play'):
                move_position = (int(move.split('-')[2]), int(move.split('-')[3]))
                for goal_x, goal_y in revealed_goals:
                    if is_path_near_goal(move_position, (goal_x, goal_y)):
                        print(f"[DEBUG] Gold Digger playing move near revealed goal: {move}")
                        return [move]

    if not revealed_goals:
        for move in legal_moves:
            if move.startswith('play'):
                move_position = (int(move.split('-')[2]), int(move.split('-')[3]))
                closest_goal = min(goal_locations, key=lambda goal: distance(move_position, goal))
                if is_path_near_goal(move_position, closest_goal):
                    print(f"[DEBUG] Gold Digger playing move near closest goal: {move}")
                    return [move]

    print(f"[DEBUG] No specific moves available, resorting to random move.")
    return agent_program_random(percepts, actuators)


def saboteur_heuristic(percepts, move):
    move_position = (int(move.split('-')[2]), int(move.split('-')[3]))
    closest_goal = min(GOAL_LOCATIONS, key=lambda goal: distance(move_position, goal))
    heuristic_value = distance(move_position, closest_goal)
    print(f"[DEBUG] Saboteur heuristic for move {move} at position {move_position}: {heuristic_value}")
    return heuristic_value


def agent_program_saboteur(percepts, actuators):
    print(f"[DEBUG] Saboteur agent activated. Getting legal moves.")
    legal_moves = SaboteurEnvironment.generate_legal_moves_from_percepts(percepts)
    game_board = percepts['game-board-sensor']
    sabotaged_players = percepts['sabotaged-players']

    revealed_goals = []
    for goal_x, goal_y in GOAL_LOCATIONS:
        goal_card = game_board.get_item_value(goal_x, goal_y)
        if goal_card and getattr(goal_card, '_revealed', False):
            revealed_goals.append((goal_x, goal_y))
            print(f"[DEBUG] Revealed goal found at: ({goal_x}, {goal_y})")

    for move in legal_moves:
        if move.startswith('sabotage'):
            target_player = int(move.split('-')[2])
            print(f"[DEBUG] Saboteur considering sabotage move on player {target_player}.")
            if target_player in actuators and 'current_position' in actuators[target_player]:
                player_position = actuators[target_player]['current_position']
                if any(is_path_near_goal(player_position, goal) for goal in revealed_goals):
                    print(f"[DEBUG] Sabotage move chosen near revealed goal: {move}")
                    return [move]
            else:
                print(f"[DEBUG] Skipping sabotage, invalid target player data.")

    for move in legal_moves:
        if move.startswith('play'):
            move_position = (int(move.split('-')[2]), int(move.split('-')[3]))
            for goal_x, goal_y in GOAL_LOCATIONS:
                if is_path_near_goal(move_position, (goal_x, goal_y)):
                    print(f"[DEBUG] Saboteur playing move near goal: {move}")
                    return [move]

    print(f"[DEBUG] No specific sabotage moves available, resorting to random move.")
    return agent_program_random(percepts, actuators)
