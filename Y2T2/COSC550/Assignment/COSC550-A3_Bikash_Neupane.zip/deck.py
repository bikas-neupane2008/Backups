from card import PathCard, ActionCard
import random


class Deck:
    def __init__(self):
        self._deck = []

        print("[DEBUG] Initializing deck...")
        self._initialise_deck()
        self.shuffle()

    def _initialise_deck(self):
        print("[DEBUG] Initializing PathCard and ActionCard deck...")

        for i in range(4):
            self._deck.append(PathCard.vertical_tunnel())
        print("[DEBUG] Added 4 vertical tunnel cards to the deck.")

        for i in range(5):
            self._deck.append(PathCard.vertical_junction())
        print("[DEBUG] Added 5 vertical junction cards to the deck.")

        for i in range(5):
            self._deck.append(PathCard.cross_road())
        print("[DEBUG] Added 5 cross road cards to the deck.")

        for i in range(5):
            self._deck.append(PathCard.horizontal_junction())
        print("[DEBUG] Added 5 horizontal junction cards to the deck.")

        for i in range(3):
            self._deck.append(PathCard.horizontal_tunnel())
        print("[DEBUG] Added 3 horizontal tunnel cards to the deck.")

        for i in range(4):
            self._deck.append(PathCard.turn())
        print("[DEBUG] Added 4 turn cards to the deck.")

        for i in range(5):
            self._deck.append(PathCard.reversed_turn())
        print("[DEBUG] Added 5 reversed turn cards to the deck.")

        self._deck.append(PathCard.dead_end(['south']))
        print("[DEBUG] Added dead end card with exit to the south.")

        self._deck.append(PathCard.dead_end(['north', 'south']))
        print("[DEBUG] Added dead end card with exits to the north and south.")

        self._deck.append(PathCard.dead_end(['north', 'east', 'south']))
        print("[DEBUG] Added dead end card with exits to the north, east, and south.")

        self._deck.append(PathCard.dead_end(['north', 'east', 'south', 'west']))
        print("[DEBUG] Added dead end card with exits in all directions.")

        self._deck.append(PathCard.dead_end(['west', 'north', 'east']))
        print("[DEBUG] Added dead end card with exits to the west, north, and east.")

        self._deck.append(PathCard.dead_end(['west', 'east']))
        print("[DEBUG] Added dead end card with exits to the west and east.")

        self._deck.append(PathCard.dead_end(['south', 'east']))
        print("[DEBUG] Added dead end card with exits to the south and east.")

        self._deck.append(PathCard.dead_end(['south', 'west']))
        print("[DEBUG] Added dead end card with exits to the south and west.")

        self._deck.append(PathCard.dead_end(['west']))
        print("[DEBUG] Added dead end card with an exit to the west.")

        for i in range(6):
            self._deck.append(ActionCard('map'))
        print("[DEBUG] Added 6 map action cards to the deck.")

        for i in range(9):
            self._deck.append(ActionCard('sabotage'))
        print("[DEBUG] Added 9 sabotage action cards to the deck.")

        for i in range(9):
            self._deck.append(ActionCard('mend'))
        print("[DEBUG] Added 9 mend action cards to the deck.")

        for i in range(3):
            self._deck.append(ActionCard('dynamite'))
        print("[DEBUG] Added 3 dynamite action cards to the deck.")

        print(f"[DEBUG] Deck initialized with a total of {len(self._deck)} cards.")

    def shuffle(self):
        print("[DEBUG] Shuffling the deck...")
        random.shuffle(self._deck)
        print("[DEBUG] Deck shuffled.")

    def draw(self):
        if len(self._deck) > 0:
            drawn_card = self._deck.pop()
            print(f"[DEBUG] Drew a card: {drawn_card}")
            return drawn_card
        else:
            print("[DEBUG] No more cards to draw from the deck.")
            return None
