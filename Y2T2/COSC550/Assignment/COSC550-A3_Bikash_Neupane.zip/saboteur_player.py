from une_ai.models import Agent, GridMap
from card import Card, PathCard


class SaboteurPlayer(Agent):
    NUM_PLAYERS = 8
    MAP_LENGTH = 20
    MAP_WIDTH = 20
    ROLES = ('Gold-Digger', 'Saboteurs')
    ACTION_TYPES = ('play', 'map', 'dynamite', 'sabotage', 'mend', 'pass')
    GOAL_LOCATIONS = ((14, 8), (14, 10), (14, 12))

    def __init__(self, agent_name, agent_program):
        print(f"[DEBUG] Initializing SaboteurPlayer: {agent_name}")
        super().__init__(agent_name, agent_program)

    def add_all_sensors(self):
        print(f"[DEBUG] Adding sensors for player {self._agent_name}")
        self.add_sensor('game-board-sensor', GridMap(20, 20, None), validate_game_board)
        self.add_sensor('player-turn', 0, lambda v: isinstance(v, int) and 0 <= v < SaboteurPlayer.NUM_PLAYERS)
        self.add_sensor('player-hand', [], lambda v: validate_list(v, lambda c: isinstance(c, Card)))
        self.add_sensor('player-role', SaboteurPlayer.ROLES[0], lambda v: v in SaboteurPlayer.ROLES)
        self.add_sensor('sabotaged-players', [False] * SaboteurPlayer.NUM_PLAYERS,
                        lambda v: validate_list(v, lambda x: isinstance(x, bool)))
        print(f"[DEBUG] Sensors added for player {self._agent_name}")

    def add_all_actuators(self):
        print(f"[DEBUG] Adding actuators for player {self._agent_name}")
        self.add_actuator('card-selected', 0,
                          lambda v: isinstance(v, int) and 0 <= v <= len(self.read_sensor_value('player-hand')))
        self.add_actuator('play-type', 'play', lambda v: v in SaboteurPlayer.ACTION_TYPES)
        self.add_actuator('position', (0, 0), validate_position)
        self.add_actuator('card-turned', False, lambda v: isinstance(v, bool))
        self.add_actuator('player-select', 0,
                          lambda v: isinstance(v, int) and 0 <= v < SaboteurPlayer.NUM_PLAYERS)
        self.add_actuator('tell-truth', False, lambda v: isinstance(v, bool))
        print(f"[DEBUG] Actuators added for player {self._agent_name}")

    def add_all_actions(self):
        print(f"[DEBUG] Adding actions for player {self._agent_name}")
        self._add_card_play_actions()
        self._add_sabotage_mend_actions()
        self._add_pass_actions()
        print(f"[DEBUG] Actions added for player {self._agent_name}")

    def _add_card_play_actions(self):
        print(f"[DEBUG] Adding card play actions for player {self._agent_name}")
        for card_select in range(4):
            for i in range(self.MAP_LENGTH):
                for j in range(self.MAP_WIDTH):
                    for turn in [True, False]:
                        self.add_action(
                            f'play-{card_select}-{i}-{j}-{turn}',
                            lambda card_selected=card_select, x=i, y=j, flip=turn: {
                                'card-selected': card_selected,
                                'play-type': 'play',
                                'position': (x, y),
                                'card-turned': flip
                            })
                    self.add_action(
                        f'dynamite-{card_select}-{i}-{j}',
                        lambda card_selected=card_select, x=i, y=j: {
                            'card-selected': card_selected,
                            'play-type': 'dynamite',
                            'position': (x, y)
                        }
                    )
            for i, j in SaboteurPlayer.GOAL_LOCATIONS:
                for tell_truth in [True, False]:
                    self.add_action(
                        f'map-{card_select}-{i}-{j}-{tell_truth}',
                        lambda card_selected=card_select, x=i, y=j, _tell_truth=tell_truth: {
                            'card-selected': card_selected,
                            'play-type': 'map',
                            'position': (x, y),
                            'tell-truth': _tell_truth
                        })
        print(f"[DEBUG] Card play actions added for player {self._agent_name}")

    def _add_sabotage_mend_actions(self):
        print(f"[DEBUG] Adding sabotage and mend actions for player {self._agent_name}")
        for card_select in range(4):
            for player_index in range(SaboteurPlayer.NUM_PLAYERS):
                self.add_action(
                    f'sabotage-{card_select}-{player_index}',
                    lambda card_selected=card_select, player_id=player_index: {
                        'card-selected': card_selected,
                        'play-type': 'sabotage',
                        'player-select': player_id
                    })
                self.add_action(
                    f'mend-{card_select}-{player_index}',
                    lambda card_selected=card_select, player_id=player_index: {
                        'card-selected': card_selected,
                        'play-type': 'mend',
                        'player-select': player_id
                    })
        print(f"[DEBUG] Sabotage and mend actions added for player {self._agent_name}")

    def _add_pass_actions(self):
        print(f"[DEBUG] Adding pass actions for player {self._agent_name}")
        for card_select in range(4):
            self.add_action(
                f'pass-{card_select}',
                lambda card_selected=card_select: {
                    'card-selected': card_selected,
                    'play-type': 'pass',
                }
            )
        print(f"[DEBUG] Pass actions added for player {self._agent_name}")


def validate_game_board(board):
    print("[DEBUG] Validating game board.")
    if ((not isinstance(board, GridMap)) or (board.get_width() != SaboteurPlayer.MAP_WIDTH)
            or (board.get_height() != SaboteurPlayer.MAP_LENGTH)):
        print("[ERROR] Game board validation failed.")
        return False

    for i in range(20):
        for j in range(20):
            item = board.get_item_value(i, j)
            if item is not None and not isinstance(item, PathCard):
                print(f"[ERROR] Invalid item on game board at position ({i}, {j}).")
                return False

    print("[DEBUG] Game board validation passed.")
    return True


def validate_list(test, item_validator):
    is_valid = isinstance(test, list) and all(item_validator(item) for item in test)
    print(f"[DEBUG] Validating list: {test} | Validation result: {is_valid}")
    return is_valid


def validate_position(position):
    is_valid = isinstance(position, tuple) and len(position) == 2 and all(isinstance(coord, int) for coord in position)
    print(f"[DEBUG] Validating position: {position} | Validation result: {is_valid}")
    return is_valid


def validate_action(action_str):
    if not isinstance(action_str, str):
        print(f"[ERROR] Invalid action string: {action_str}")
        return False
    action_type = action_str.split("-")[0]
    is_valid = action_type in SaboteurPlayer.ACTION_TYPES
    print(f"[DEBUG] Validating action: {action_str} | Validation result: {is_valid}")
    return is_valid
