from saboteur_environment import SaboteurEnvironment as gm
from une_ai.models import GraphNode


def minimax(node, player, depth):
    move_best = None

    # Get the current game state from the node
    game_state = node.get_state()

    # Extract player turn from the game state
    player_turn = game_state['player-turn']
    is_maximising = player_turn == player

    # Initialize the value based on whether we are maximizing or minimizing
    value = float('-Inf') if is_maximising else float('+Inf')

    # Base case: If we reach maximum depth or the game is terminal
    if depth <= 0 or gm.is_terminal(game_state):
        value = gm.payoff(game_state, player)  # Get the payoff for the current game state
        return value, move_best

    # Get legal actions for the current game state
    legal_actions = gm.get_legal_actions(game_state)

    # Explore each action
    for action in legal_actions:
        # Simulate the action and get the new game state
        new_state = gm.transition_result(game_state, action)
        # Create a new node for the child state
        child_node = GraphNode(new_state, node, action, 1)
        # Recursively call minimax for the child node
        value_new, _ = minimax(child_node, player, depth - 1)

        # Update the best move and value based on whether we are maximizing or minimizing
        if (is_maximising and value_new > value) or (not is_maximising and value_new < value):
            value = value_new
            move_best = action

    return value, move_best


def minimax_alpha_beta(node, player, alpha, beta, depth):
    # Get the current game state from the node
    game_state = node.get_state()

    # Extract player turn from the game state
    player_turn = game_state['player-turn']
    is_maximising = player_turn == player

    move_best = None
    # Initialize the value based on whether we are maximizing or minimizing
    value = float('-Inf') if is_maximising else float('+Inf')

    # Base case: If we reach maximum depth or the game is terminal
    if depth <= 0 or gm.is_terminal(game_state):
        value = gm.payoff(game_state, player)  # Get the payoff for the current game state
        return value, move_best

    # Get legal actions for the current game state
    legal_actions = gm.get_legal_actions(game_state)

    # Explore each action
    for action in legal_actions:
        # Simulate the action and get the new game state
        new_state = gm.transition_result(game_state, action)
        # Create a new node for the child state
        child_node = GraphNode(new_state, node, action, 1)
        # Recursively call minimax with alpha-beta pruning for the child node
        value_new, _ = minimax_alpha_beta(child_node, player, alpha, beta, depth - 1)

        if is_maximising:
            if value_new > value:
                value = value_new
                move_best = action
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        else:
            if value_new < value:
                value = value_new
                move_best = action
            beta = min(beta, value)
            if beta <= alpha:
                break

    return value, move_best
