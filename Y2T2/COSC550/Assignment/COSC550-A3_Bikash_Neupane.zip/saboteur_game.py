# saboteur_game.py
from saboteur_environment import SaboteurEnvironment
import tkinter as tk
from tkinter import font


class SaboteurGame:
    def __init__(self, environment: SaboteurEnvironment) -> None:
        assert type(environment).__name__ == 'SaboteurEnvironment', (
            "environment must be an instance of a subclass of the class SaboteurEnvironment")
        self._agents = [environment.get_player(i)[0] for i in range(8)]
        self._environment = environment

    def _play_step(self, num_steps=1, log=True):
        for _ in range(num_steps):
            if self._environment.is_terminal():
                break
            cur_player = self._environment.turn()
            self._agents[cur_player].sense(self._environment)
            actions = self._agents[cur_player].think()
            if log: print(f"{cur_player} is playing action: {actions[-1]}")
            self._agents[cur_player].act(actions, self._environment)

    def main(self):
        while not self._environment.is_terminal():
            self._play_step()
            print(self._environment.get_game_board())
        print("Game over!")


class GameGUI:
    def __init__(self, saboteur_game):
        self.root = tk.Tk()
        self.root.title("Saboteur Game Status")

        self.saboteur_game = saboteur_game

        self.custom_font = font.Font(family="Courier", size=10)  # Adjusted font size for better visibility

        # Main frame layout
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill="both", expand=True)

        # ===========================
        # Game Board (Top section)
        # Reduced the height to allow for a bigger move history section
        # ===========================
        self.canvas_frame = tk.Frame(self.main_frame)
        self.canvas_frame.pack(fill="both", expand=False, pady=5)  # Reduced expand to False to reduce height

        # Create canvas for game board
        self.canvas = tk.Canvas(self.canvas_frame, width=600, height=400, bg="lightgreen")  # Reduced height to 400
        self.canvas.pack(side="left", fill="both", expand=True)

        # Create both scrollbars for horizontal and vertical scrolling
        self.v_scrollbar = tk.Scrollbar(self.canvas_frame, orient="vertical", command=self.canvas.yview)
        self.v_scrollbar.pack(side="right", fill="y")

        self.h_scrollbar = tk.Scrollbar(self.main_frame, orient="horizontal", command=self.canvas.xview)
        self.h_scrollbar.pack(fill="x", pady=5)  # Horizontal scrollbar fully from left to right

        self.canvas.configure(yscrollcommand=self.v_scrollbar.set, xscrollcommand=self.h_scrollbar.set)

        # Set the scrollable region
        self.canvas.config(scrollregion=(0, 0, 600, 600))

        # ===========================
        # Player Info (Middle section)
        # ===========================
        self.player_info_label = tk.Label(self.main_frame, text="Player Moves", font=self.custom_font, anchor="nw")
        self.player_info_label.pack(pady=10, padx=10, fill="both", expand=False)

        # ===========================
        # Scrollable Move History (Bottom section)
        # Made it bigger by allocating more space with a higher height
        # ===========================
        self.history_frame = tk.Frame(self.main_frame)
        self.history_frame.pack(fill="both", expand=True, pady=10)

        # Scrollbar for history
        self.history_scrollbar = tk.Scrollbar(self.history_frame, orient="vertical")
        self.history_scrollbar.pack(side="right", fill="y")

        # Increased height to 25 to allow for more visible moves
        self.history_text = tk.Text(self.history_frame, font=self.custom_font, wrap="none", height=25,  # Increased height
                                    yscrollcommand=self.history_scrollbar.set)
        self.history_text.pack(side="left", fill="both", expand=True)

        # Bind the scrollbar to the text widget
        self.history_scrollbar.config(command=self.history_text.yview)

        # Define color tags for roles
        self.history_text.tag_config('gold-digger', foreground='green')
        self.history_text.tag_config('saboteur', foreground='red')
        self.history_text.tag_config('sabotaged', background='yellow')

        # ===========================
        # Status Bar (Game Info)
        # ===========================
        self.status_label = tk.Label(self.root, text="Game Information", bd=1, relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

        # Start the game loop
        self.update_game_status()
        self.render_game_board()  # Initial render
        self.root.mainloop()

    def on_frame_configure(self, event):
        # Update scroll region to include the entire game board
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def update_game_status(self):
        if not self.saboteur_game._environment.is_terminal():
            # Play a step in the game
            self.saboteur_game._play_step(num_steps=1, log=False)

        current_player = self.saboteur_game._environment.turn()
        game_board = self.saboteur_game._environment.get_game_board()

        # Render the game board
        self.render_game_board()

        # Update player moves (middle section)
        role = self.saboteur_game._environment.get_player_role(current_player)
        remaining_cards = len(self.saboteur_game._environment._players_hands[current_player])
        self.player_info_label.config(text=f"Current Player: Player {current_player} ({role}) | Cards in Hand: {remaining_cards}")

        # Append the current player's move to the move history (scrollable part)
        for id, player in enumerate(self.saboteur_game._agents):
            if id == current_player:
                card_selected = player.read_actuator_value('card-selected')
                play_type = player.read_actuator_value('play-type')
                position = player.read_actuator_value('position')
                sabotaged = self.saboteur_game._environment._sabotaged_players[id]
                player_info = (
                    f"Player {id}: card_selected={card_selected}, play_type={play_type}, "
                    f"position={position}, sabotaged={sabotaged}\n"
                )
                role = self.saboteur_game._environment.get_player_role(id)
                tag = 'gold-digger' if role == 'Gold-Digger' else 'saboteur'
                if sabotaged:
                    self.history_text.insert(tk.END, player_info, 'sabotaged')
                else:
                    self.history_text.insert(tk.END, player_info, tag)

        # Ensure the history part is scrollable
        self.history_text.see(tk.END)

        # Update the status bar
        current_turn = self.saboteur_game._environment.turn()
        deck_size = len(self.saboteur_game._environment._deck._deck)
        self.status_label.config(text=f"Current Turn: Player {current_turn} | Cards in Deck: {deck_size}")

        # Continue game loop or check for game over
        if not self.saboteur_game._environment.is_terminal():
            # Continue updating the status every 2 seconds
            self.root.after(2000, self.update_game_status)
        else:
            # When the game is over, do not clear the game board
            winner = self.saboteur_game._environment.get_winner_self()
            self.player_info_label.config(text=f"Game over! {winner} win!")
            self.history_text.insert(tk.END, f"Game over! {winner} win!\n")

            # Display player roles at the end of the game
            roles = self.saboteur_game._environment.get_all_roles()
            role_info = "\n".join([f"Player {i}: {role}" for i, role in roles.items()])
            self.history_text.insert(tk.END, f"\n--- Player Roles ---\n{role_info}\n")

    def render_game_board(self):
        self.canvas.delete("all")  # Clear the current canvas content

        cell_size = 30  # Define size of each cell
        board_map = self.saboteur_game._environment.get_game_board().get_board().get_map()

        for y, row in enumerate(board_map):
            for x, card in enumerate(row):
                if card is None:
                    continue

                # Calculate the top-left corner of the cell
                top_left_x = x * cell_size
                top_left_y = y * cell_size

                # Draw a rectangle for each card
                if card.is_special_card():
                    color = "lightblue"
                else:
                    color = "white"
                self.canvas.create_rectangle(top_left_x, top_left_y, top_left_x + cell_size, top_left_y + cell_size, fill=color, outline="black")

                # Draw tunnels based on card exits
                exits = card.get_exits()
                if 'north' in exits:
                    self.canvas.create_line(top_left_x + cell_size / 2, top_left_y, top_left_x + cell_size / 2, top_left_y + cell_size / 4, fill="black", width=2)
                if 'south' in exits:
                    self.canvas.create_line(top_left_x + cell_size / 2, top_left_y + cell_size, top_left_x + cell_size / 2, top_left_y + (3 * cell_size) / 4, fill="black", width=2)
                if 'east' in exits:
                    self.canvas.create_line(top_left_x + cell_size, top_left_y + cell_size / 2, top_left_x + (3 * cell_size) / 4, top_left_y + cell_size / 2, fill="black", width=2)
                if 'west' in exits:
                    self.canvas.create_line(top_left_x, top_left_y + cell_size / 2, top_left_x + cell_size / 4, top_left_y + cell_size / 2, fill="black", width=2)

                # Label special cards
                if card.is_special_card():
                    if card.is_gold():
                        text = "G"  # Gold
                        self.canvas.create_text(top_left_x + cell_size / 2, top_left_y + cell_size / 2, text=text, font=("Courier", 12, "bold"), fill="gold")
                    elif card._special_card == 'start':
                        text = "S"  # Start
                        self.canvas.create_text(top_left_x + cell_size / 2, top_left_y + cell_size / 2, text=text, font=("Courier", 12, "bold"), fill="blue")
                    else:
                        text = "?"  # Goal
                        self.canvas.create_text(top_left_x + cell_size / 2, top_left_y + cell_size / 2, text=text, font=("Courier", 12, "bold"), fill="grey")

    def manual_play_step(self):
        # Manually trigger a play step and update the game status
        self.saboteur_game._play_step(num_steps=1)
        self.update_game_status()

    def end_game(self):
        # Manually end the game and update the game status
        self.saboteur_game._environment.set_terminal(True)
        self.update_game_status()


# Create the game and start the GUI
if __name__ == "__main__":
    env = SaboteurEnvironment()  # Initialize your actual environment setup
    saboteur_game = SaboteurGame(env)
    app = GameGUI(saboteur_game)
