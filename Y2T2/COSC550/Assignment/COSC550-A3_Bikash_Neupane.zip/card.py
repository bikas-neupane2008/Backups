class Card:
    pass


class ActionCard(Card):

    def __init__(self, action):
        assert action in ['map', 'sabotage', 'mend', 'dynamite'], "The parameter action must be either map, sabotage, mend or dynamite"
        self._action = action
        print(f"[DEBUG] ActionCard initialized with action: {action}")

    def get_action(self):
        print(f"[DEBUG] ActionCard action requested: {self._action}")
        return self._action


class InvalidTunnel(Exception):
    pass


class PathCard(Card):

    def __init__(self, tunnels, special_card=None):
        assert isinstance(tunnels, list), "The parameter tunnels must be a list of tuples"
        assert special_card in ['start', 'goal', 'gold', None], "The parameter special_card must be either None, start, goal or gold"

        print(f"[DEBUG] Initializing PathCard with tunnels: {tunnels} and special_card: {special_card}")
        for tunnel in tunnels:
            if not self._is_valid_tunnel(tunnel):
                raise InvalidTunnel(f"[ERROR] The tunnel '{tunnel}' is invalid for this card.")

        self._special_card = special_card
        self._revealed = True
        if special_card:
            print(f"[DEBUG] PathCard is a special card: {special_card}")
            cross_road = PathCard.cross_road()
            self._tunnels = cross_road.get_tunnels()
            if special_card in ['goal', 'gold']:
                self._revealed = False
                print("[DEBUG] PathCard with goal or gold is not revealed.")
        else:
            self._tunnels = tunnels

    @staticmethod
    def cross_road(special_card=None):
        print(f"[DEBUG] Creating a cross road card with special_card: {special_card}")
        return PathCard(
            [
                ('north', 'south'),
                ('north', 'east'),
                ('north', 'west'),
                ('south', 'east'),
                ('south', 'west'),
                ('east', 'west')
            ], special_card=special_card
        )

    def get_exits(self):
        exits: list[str] = []
        for tunnel in self._tunnels:
            for exit in tunnel:
                if exit not in exits:
                    exits.append(exit)
        if None in exits:
            exits.remove(None)
        print(f"[DEBUG] PathCard exits: {exits}")
        return exits

    @staticmethod
    def vertical_tunnel():
        print("[DEBUG] Creating a vertical tunnel card.")
        return PathCard(
            [
                ('north', 'south')
            ]
        )

    @staticmethod
    def horizontal_tunnel():
        print("[DEBUG] Creating a horizontal tunnel card.")
        return PathCard(
            [
                ('east', 'west')
            ]
        )

    @staticmethod
    def vertical_junction():
        print("[DEBUG] Creating a vertical junction card.")
        return PathCard(
            [
                ('north', 'south'),
                ('north', 'east'),
                ('south', 'east')
            ]
        )

    @staticmethod
    def horizontal_junction():
        print("[DEBUG] Creating a horizontal junction card.")
        return PathCard(
            [
                ('east', 'north'),
                ('west', 'north'),
                ('east', 'west')
            ]
        )

    @staticmethod
    def turn():
        print("[DEBUG] Creating a turn card.")
        return PathCard(
            [
                ('south', 'east')
            ]
        )

    @staticmethod
    def reversed_turn():
        print("[DEBUG] Creating a reversed turn card.")
        return PathCard(
            [
                ('south', 'west')
            ]
        )

    @staticmethod
    def dead_end(directions):
        print(f"[DEBUG] Creating a dead end card with directions: {directions}")
        tunnels = []
        for direction in directions:
            tunnels.append((direction, None))
        return PathCard(tunnels)

    def _is_valid_tunnel(self, tunnel):
        print(f"[DEBUG] Validating tunnel: {tunnel}")
        if not isinstance(tunnel, tuple):
            print("[ERROR] Tunnel is not a tuple.")
            return False
        if len(tunnel) != 2:
            print("[ERROR] Tunnel does not have exactly two elements.")
            return False
        for direction in tunnel:
            if direction not in ['north', 'east', 'south', 'west', None]:
                print(f"[ERROR] Invalid direction in tunnel: {direction}")
                return False
        if tunnel[0] is None:
            print("[ERROR] Tunnel starting direction is None.")
            return False
        if tunnel[0] is None and tunnel[1] is None:
            print("[ERROR] Both tunnel directions are None.")
            return False
        if tunnel[0] == tunnel[1]:
            print("[ERROR] Tunnel directions are the same.")
            return False
        print("[DEBUG] Tunnel is valid.")
        return True

    def is_special_card(self):
        is_special = self._special_card is not None
        print(f"[DEBUG] PathCard is_special_card: {is_special}")
        return is_special

    def is_gold(self):
        is_gold_card = self._special_card == 'gold'
        print(f"[DEBUG] PathCard is_gold: {is_gold_card}")
        return is_gold_card

    def reveal_card(self):
        print(f"[DEBUG] Revealing card. Current revealed status: {self._revealed}")
        self._revealed = True

    def turn_card(self):
        print("[DEBUG] Turning the card.")
        tunnels = []
        opposite = {
            'north': 'south',
            'east': 'west',
            'west': 'east',
            'south': 'north',
        }
        for tunnel in self._tunnels:
            new_tunnel = (
                opposite[tunnel[0]] if tunnel[0] is not None else None,
                opposite[tunnel[1]] if tunnel[1] is not None else None
            )
            tunnels.append(new_tunnel)

        self._tunnels = tunnels
        print(f"[DEBUG] Card turned. New tunnels: {self._tunnels}")

    def get_tunnels(self):
        print(f"[DEBUG] Returning tunnels: {self._tunnels}")
        return self._tunnels.copy()

    def __str__(self):
        card_rep = ['   ', '   ', '   ']
        if self._revealed:
            for tunnel in self._tunnels:
                directions = [(tunnel[0], tunnel[1]), (tunnel[1], tunnel[0])]
                for direction in directions:
                    tunnel_from = direction[0]
                    tunnel_to = direction[1]
                    if tunnel_from == 'north':
                        card_rep[0] = card_rep[0][:1] + '|' + card_rep[0][2:]
                        if tunnel_to is not None:
                            card_rep[1] = card_rep[1][:1] + '┼' + card_rep[1][2:]
                    elif tunnel_from == 'south':
                        card_rep[2] = card_rep[2][:1] + '|' + card_rep[2][2:]
                        if tunnel_to is not None:
                            card_rep[1] = card_rep[1][:1] + '┼' + card_rep[1][2:]
                    elif tunnel_from == 'east':
                        card_rep[1] = card_rep[1][:2] + ''
                        if tunnel_to is not None:
                            card_rep[1] = card_rep[1][:1] + '┼' + card_rep[1][2:]
                    elif tunnel_from == 'west':
                        card_rep[1] = '' + card_rep[1][1:]
                        if tunnel_to is not None:
                            card_rep[1] = card_rep[1][:1] + '┼' + card_rep[1][2:]
        else:
            return '   \n ? \n   '
        print(f"[DEBUG] String representation of card:\n{card_rep}")
        return '\n'.join(card_rep)
