# Saboteur Game
## Overview
This is a Python implementation of the social deduction game **Saboteur**. In this game, players take on hidden roles as either *Gold-Diggers* or *Saboteurs*. The objective for the Gold-Diggers is to construct a path from the starting point to the hidden gold treasure, while the Saboteurs aim to secretly hinder the construction. The game is played on a 20x20 grid-based board, and players utilize both path and action cards during their turns.

## Game Components:
- **Path Cards**: Used to create tunnels and connect the starting card to goal cards.
- **Action Cards**: These cards include special abilities like sabotaging other players, mending broken tools, or dynamite to remove path cards.
- **Roles**: Each player is assigned a hidden role as either a Gold-Digger or a Saboteur. There are always 2-3 Saboteurs among the 8 players.
## Key Features:
- Hidden player roles.
- Complex decision-making for both Gold-Diggers and Saboteurs.
- Intelligent behavior models for AI players.
- Randomized goal card and path card placement.
- User interface using a Python GUI library (Tkinter).
## Setup Instructions
### Prerequisites
- Python 3.8 or higher.
- Conda
- une_ai packages
- Libraries: `Tkinter` (for GUI), `random`, `math`.
### Installing Dependencies
- Install Python 3.x on your system if you haven’t already.
- Install Conda and une_ai packages
- Install required Python libraries:
```bash
pip install tkinter
```
### Files Overview
Here is an overview of the key Python modules:

- `agent_program.py`: Contains the intelligent behavior and agent program logic, handling the AI strategy and decision-making for both Gold-Diggers and Saboteurs.
- `card.py`: Defines classes for path and action cards, such as path cards that allow players to build tunnels and action cards like sabotage and mend cards.
- `deck.py`: Manages the deck of cards, shuffling and dealing cards to players at the start of the game and after every turn.
- `game_board.py`: Implements the 20x20 grid board where the game is played. Handles placement and removal of cards on the board.
- `saboteur_app.py`: Manages the main application logic, including game initialization and managing the user interface.
- `saboteur_environment.py`: Defines the environment in which the game takes place, including state transitions, game state representation, and game ending conditions.
- `saboteur_game.py`: The main game logic that brings together the environment, agents, and user interface for gameplay.
- `saboteur_player`.py: Manages player roles, their interactions with the game board, and actions like placing cards or sabotaging others.
## Running the Game
- Clone the repository or download the project zip file.
- Navigate to the project directory:
```bash
cd path/to/project
```
- Run the main application file:
```bash
python3 saboteur_app.py
```
## Gameplay Overview
### Starting the Game
- The game begins with 8 players, each assigned a random hidden role of either *Gold-Digger* or *Saboteur*.
- Players are dealt 4 cards, and the objective is to either build a path to the hidden gold (Gold-Diggers) or prevent path completion (Saboteurs).
### Game Mechanics
- Players take turns, and each turn allows the player to either:
    - Place a path card to build the tunnel.
    - Play an action card (e.g., sabotage or mend).
    - Discard a card and pass their turn.
- The game ends when either:
    - The Gold-Diggers reach the gold card with an uninterrupted path.
    - All cards are played, and no legal moves remain, giving victory to the Saboteurs.
## Notes on AI and Environment
- **AI Implementation**: The AI for Gold-Diggers prioritizes path-building strategies, while Saboteurs focus on misleading and obstructing paths. The AI is implemented using decision-making algorithms based on the game state and possible actions.

- **Environment Design**: The game state is managed by the `SaboteurEnvironment` class, which handles transitions between game states, checks for terminal conditions, and manages player interactions with the game board.

## Key Features in Development
- Intelligent AI behaviors for both Gold-Diggers and Saboteurs.
- Graphical User Interface (GUI) for interactive gameplay using `Tkinter`.
- Modular game architecture allowing for easy expansion of cards, actions, and agent behaviors.
## Challenges & Learning Experience
One of the biggest challenges I encountered during this project was my unfamiliarity with the game *Saboteur*. Before this assignment, I had never heard of the game, and this posed significant obstacles, particularly in understanding how the game is played, what constitutes valid moves, and how the game is won. I invested time searching for information on YouTube, Wikipedia, and other online sources, but despite my efforts, I still struggled to grasp the game's core mechanics fully. This lack of clarity impacted my ability to implement the game logic and, more importantly, to design effective AI behaviors.

This challenge made me realize how crucial it is to have a solid understanding of a game's rules and logic before embarking on a project that involves AI. Since AI relies heavily on decision-making, the logic of the game must be crystal clear to design rational behaviors for agents. Without this foundational understanding, it becomes difficult to model behaviors accurately or anticipate the consequences of certain game states and actions.

Despite the confusion, I managed to develop a basic understanding of Saboteur and implemented some AI techniques. However, I believe that the AI could have been significantly more refined and strategic had I had a deeper grasp of the game mechanics from the start. The experience has taught me a valuable lesson: when working on game-related AI projects, especially for complex games like *Saboteur*, it's essential to spend adequate time understanding the game thoroughly before diving into code. This not only helps with designing better AI but also prevents wasted effort on trial-and-error approaches.

In conclusion, while I faced challenges in learning the game, I managed to overcome them to an extent and successfully implemented AI agents that exhibit basic rational behaviors. However, I recognize that a deeper understanding would have enabled me to create more sophisticated and varied strategies for the agents, enhancing the overall gameplay experience.
