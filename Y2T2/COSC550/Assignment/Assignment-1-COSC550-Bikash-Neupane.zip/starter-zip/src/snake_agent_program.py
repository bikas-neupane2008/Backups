"""
You can import modules if you need
NOTE:
your code must function properly without
requiring the installation of any additional
dependencies beyond those already included in
the Python package une_ai
"""
# import ...
from queue import PriorityQueue

# Here you can create additional functions
# you may need to use in the agent program function

"""
TODO:
You must implement this function with the
agent program for your snake agent.
Please, make sure that the code and implementation 
of your agent program reflects the requirements in
the assignment. Deviating from the requirements
may result to score a 0 mark in the
agent program criterion.

Please, do not change the parameters of this function.
"""


def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def a_star(start, goal, obstacles, body, grid_size):
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    open_set = PriorityQueue()
    open_set.put((0, start))
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}

    while not open_set.empty():
        _, current = open_set.get()

        if current == goal:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.reverse()
            return path

        for direction in directions:
            neighbor = (current[0] + direction[0], current[1] + direction[1])

            if 0 <= neighbor[0] < grid_size[0] and 0 <= neighbor[1] < grid_size[
                1] and neighbor not in obstacles and neighbor not in body:
                tentative_g_score = g_score[current] + 1

                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                    open_set.put((f_score[neighbor], neighbor))

    return []


def snake_agent_program(percepts, actuators):
    actions = []

    body = percepts['body-sensor']
    food = percepts['food-sensor']
    obstacles = percepts['obstacles-sensor']
    clock = percepts['clock']
    head_direction = actuators['head']

    head_x, head_y = body[0]
    grid_size = (64, 48)  # Assuming the grid size is 64x48

    def get_next_position(direction):
        return {'up': (head_x, head_y - 1), 'down': (head_x, head_y + 1), 'left': (head_x - 1, head_y),
            'right': (head_x + 1, head_y)}[direction]

    def is_safe(position):
        return position not in body and position not in obstacles

    def choose_new_direction():
        directions = ['up', 'down', 'left', 'right']
        directions.remove(opposite_direction(head_direction))
        for direction in directions:
            if is_safe(get_next_position(direction)):
                return direction
        return head_direction

    def opposite_direction(direction):
        return {'up': 'down', 'down': 'up', 'left': 'right', 'right': 'left'}[direction]

    if food:
        closest_food = min(food, key=lambda f: abs(f[0] - head_x) + abs(f[1] - head_y))
        food_x, food_y, food_value = closest_food
        path = a_star((head_x, head_y), (food_x, food_y), set(obstacles), set(body), grid_size)

        if path:
            next_position = path[0]
            next_direction = None

            if next_position == (head_x, head_y - 1):
                next_direction = 'up'
            elif next_position == (head_x, head_y + 1):
                next_direction = 'down'
            elif next_position == (head_x - 1, head_y):
                next_direction = 'left'
            elif next_position == (head_x + 1, head_y):
                next_direction = 'right'

            if next_direction and next_direction != opposite_direction(head_direction):
                actions.append(f'move-{next_direction}')

                if next_position == (food_x, food_y):
                    actions.append('open-mouth')
        else:
            next_position = get_next_position(head_direction)
            if is_safe(next_position):
                actions.append(f'move-{head_direction}')
            else:
                new_direction = choose_new_direction()
                actions.append(f'move-{new_direction}')

    if 'open-mouth' not in actions:
        actions.append('close-mouth')

    return actions
