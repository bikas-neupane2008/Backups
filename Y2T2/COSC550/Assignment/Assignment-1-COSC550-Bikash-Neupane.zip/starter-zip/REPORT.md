# Assignment 1 - Student's Report

## Author:
<b>Full Name : <i>Bikash Neupane</i></b>
<br>
<b>Student ID : <i>220245756</i></b>

## Class of the Agent Program

<p style="text-align: justify;">
The agent program for the snake game falls into the category of goal-based agents. This classification is due to the agent's primary objective of navigating the environment to reach food while avoiding obstacles and its own body. The agent makes decisions based on its current state and goal (finding food) rather than just reacting to the immediate environment. The use of the A* algorithm to find the optimal path to the food highlights its goal-oriented nature, as it systematically searches for the best route to achieve its goal.
</p>

## AI Techniques Considered

<p style="text-align: justify;">
Several AI techniques were considered to solve the problem, including simple reflex actions, model-based approaches, and search algorithms. Ultimately, the A* search algorithm was chosen to implement the agent program. The A* algorithm was selected because it effectively balances between exploration and exploitation by considering both the cost to reach a node and the estimated cost to the goal. This aligns with the agent's objective of efficiently navigating to the food while avoiding obstacles. The heuristic function used in the A* algorithm ensures that the agent makes informed decisions about the shortest path, enhancing its performance and reliability in complex environments.
</p>

## Reflections

<p style="text-align: justify;">
During the problem-solving and implementation process, several challenges were encountered:
<ol type="1">
<li>
<b>Handling Dynamic Obstacles:</b> One of the significant challenges was ensuring the agent could handle dynamic obstacles, including its growing body. To address this, the A* algorithm was adapted to account for the snake's body positions and obstacles dynamically, ensuring that the agent's pathfinding remained accurate and reliable.
</li>
<li>
<b>Real-time Decision Making:</b> Implementing real-time decision-making was another challenge, particularly in ensuring the agent could quickly and accurately determine the next move. Optimizing the A* algorithm for performance and ensuring the agent could react swiftly to changes in the environment was crucial. Techniques such as prioritizing directions and efficiently managing the open and closed sets in the A* algorithm were employed to tackle this issue.
</li>
<li>
<b>Safe Navigation:</b> Ensuring safe navigation around obstacles and avoiding collisions with the snake's own body required careful consideration of the agent's movement logic. The agent was programmed to evaluate potential moves and select the safest option, taking into account both immediate and future states. This involved implementing functions to check the safety of positions and choose new directions when necessary.
</li>
</ol>
By overcoming these challenges, the agent program was successfully implemented to navigate the snake efficiently towards the food while avoiding obstacles and handling real-time changes in the environment. The use of the A* algorithm proved to be effective in achieving the agent's goal, demonstrating its suitability for this type of problem.
<br><br>In conclusion, the development of the snake agent program involved thoughtful consideration of AI techniques, rigorous testing, and iterative improvements to ensure optimal performance. The goal-based approach and the implementation of the A* algorithm enabled the agent to navigate the environment effectively, fulfilling the assignment requirements and showcasing the potential of goal-based agents in solving complex navigation problems.
</p>
