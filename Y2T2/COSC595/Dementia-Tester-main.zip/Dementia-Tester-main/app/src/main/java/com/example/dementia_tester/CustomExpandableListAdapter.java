package com.example.dementia_tester;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

public class CustomExpandableListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> listDataHeader; // Header titles (submissionDateTime)
    private Map<String, List<Map<String, Object>>> listDataChild; // Child data (answers with SubmissionDateTime)

    public CustomExpandableListAdapter(Context context, List<String> listDataHeader,
                                       Map<String, List<Map<String, Object>>> listDataChild) {
        this.context = context;
        this.listDataHeader = listDataHeader;
        this.listDataChild = listDataChild;
    }

    @Override
    public int getGroupCount() {
        return this.listDataHeader.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return this.listDataChild.get(this.listDataHeader.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this.listDataHeader.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return this.listDataChild.get(this.listDataHeader.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.list_group, null);
        }

        TextView lblListHeader = convertView.findViewById(R.id.lblListHeader);
        lblListHeader.setText(headerTitle);

        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        Map<String, Object> childMap = (Map<String, Object>) getChild(groupPosition, childPosition);

        // Inflate and populate the child view with all available data fields
        convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);

        TextView txtAnswerNumber = convertView.findViewById(R.id.lblAnswerNumber);
        TextView txtAnswer = convertView.findViewById(R.id.lblAnswer);
        TextView txtCognitiveSituation = convertView.findViewById(R.id.lblCognitiveSituation);
        TextView txtDomain = convertView.findViewById(R.id.lblDomain);
        TextView txtScore = convertView.findViewById(R.id.lblScore);
        TextView txtTimestamp = convertView.findViewById(R.id.lblTimestamp);

        // Additional TextViews for different data types
        TextView txtCognitiveSummary = convertView.findViewById(R.id.lblCognitiveSummary);
        TextView txtDomainSummary = convertView.findViewById(R.id.lblDomainSummary);
        TextView txtNCDCategorisation = convertView.findViewById(R.id.lblNCDCategorisation);
        TextView txtTotalScore = convertView.findViewById(R.id.lblTotalScore);
        TextView txtPartialScore = convertView.findViewById(R.id.lblPartialScore);
        TextView txtLastUpdated = convertView.findViewById(R.id.lblLastUpdated);

        // Hide all TextViews by default
        txtAnswerNumber.setVisibility(View.GONE);
        txtAnswer.setVisibility(View.GONE);
        txtCognitiveSituation.setVisibility(View.GONE);
        txtDomain.setVisibility(View.GONE);
        txtScore.setVisibility(View.GONE);
        txtTimestamp.setVisibility(View.GONE);

        txtCognitiveSummary.setVisibility(View.GONE);
        txtDomainSummary.setVisibility(View.GONE);
        txtNCDCategorisation.setVisibility(View.GONE);
        txtTotalScore.setVisibility(View.GONE);
        txtPartialScore.setVisibility(View.GONE);
        txtLastUpdated.setVisibility(View.GONE);

        if (childMap.containsKey("Answer")) { // Handle answer data
            txtAnswerNumber.setVisibility(View.VISIBLE);
            txtAnswer.setVisibility(View.VISIBLE);
            txtCognitiveSituation.setVisibility(View.VISIBLE);
            txtDomain.setVisibility(View.VISIBLE);
            txtScore.setVisibility(View.VISIBLE);
            txtTimestamp.setVisibility(View.VISIBLE);

            txtAnswerNumber.setText("Answer " + (childPosition + 1) + ":");
            txtAnswer.setText("Answer: " + childMap.get("Answer"));
            txtCognitiveSituation.setText("Cognitive Situation: " + childMap.get("CognitiveSituation"));
            txtDomain.setText("Domain: " + childMap.get("Domain"));
            txtScore.setText("Score: " + childMap.get("Score"));
            txtTimestamp.setText("Submitted at: " + childMap.get("Timestamp"));
        } else { // Handle additional data
            if (childMap.containsKey("CognitiveSituationScores")) {
                txtCognitiveSummary.setVisibility(View.VISIBLE);
                StringBuilder scores = new StringBuilder("Cognitive Situation Summary:\n");
                Map<String, String> cognitiveSituationScores = (Map<String, String>) childMap.get("CognitiveSituationScores");
                for (Map.Entry<String, String> entry : cognitiveSituationScores.entrySet()) {
                    scores.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
                }
                txtCognitiveSummary.setText(scores.toString().trim());
            }

            if (childMap.containsKey("DomainScores")) {
                txtDomainSummary.setVisibility(View.VISIBLE);
                StringBuilder scores = new StringBuilder("Domain Summary:\n");
                Map<String, String> domainScores = (Map<String, String>) childMap.get("DomainScores");
                for (Map.Entry<String, String> entry : domainScores.entrySet()) {
                    scores.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
                }
                txtDomainSummary.setText(scores.toString().trim());
            }

            if (childMap.containsKey("NCD Categorisation")) {
                txtNCDCategorisation.setVisibility(View.VISIBLE);
                txtNCDCategorisation.setText("NCD Categorisation: " + childMap.get("NCD Categorisation"));
            }

            if (childMap.containsKey("Total Score")) {
                txtTotalScore.setVisibility(View.VISIBLE);
                txtTotalScore.setText("Total Score: " + childMap.get("Total Score"));
            }

            if (childMap.containsKey("Partial Score")) {
                txtPartialScore.setVisibility(View.VISIBLE);
                txtPartialScore.setText("Partial Score: " + childMap.get("Partial Score"));
            }

            if (childMap.containsKey("Last Updated")) {
                txtLastUpdated.setVisibility(View.VISIBLE);
                txtLastUpdated.setText("Last Updated: " + childMap.get("Last Updated"));
            }
        }

        return convertView;
    }


    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
