package com.example.dementia_tester;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnswerActivity extends AppCompatActivity {

    private TextView noAnswersTextView;
    private ExpandableListView expandableListView;
    private Button btnQuestions, btnProfile;

    private DatabaseReference userAnswersRef;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_answer);

        initializeUI();

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        userAnswersRef = firebaseDatabase.getReference("UserAnswers");

        userId = getUserID();

        if (userId != null) {
            fetchAndDisplayAnswers();
        }

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(AnswerActivity.this, ProfileActivity.class);
                startActivity(intent);
                finish();
            }
        };

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void initializeUI() {
        noAnswersTextView = findViewById(R.id.no_answers_text_view);
        expandableListView = findViewById(R.id.answers_expandable_list);
        btnQuestions = findViewById(R.id.backtoquestions);
        btnProfile = findViewById(R.id.profileView);
        btnQuestions.setOnClickListener(v -> {
            finish();
            startActivity(new Intent(AnswerActivity.this, QuestionsActivity.class));
        });
        btnProfile.setOnClickListener(v -> {
            finish();
            startActivity(new Intent(AnswerActivity.this, ProfileActivity.class));
        });
    }

    private String getUserID() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            return currentUser.getUid();
        } else {
            Toast.makeText(this, "User not signed in", Toast.LENGTH_SHORT).show();
            finish();
            return null;
        }
    }

    private void fetchAndDisplayAnswers() {
        if (userId == null) return;

        userAnswersRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<String> listDataHeader = new ArrayList<>();
                Map<String, List<Map<String, Object>>> listDataChild = new HashMap<>();

                List<DataSnapshot> attemptSnapshots = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    attemptSnapshots.add(snapshot);
                }

                Collections.sort(attemptSnapshots, (snapshot1, snapshot2) -> {
                    String key1 = snapshot1.getKey().replace("Attempt_", "");
                    String key2 = snapshot2.getKey().replace("Attempt_", "");
                    int attemptNumber1 = Integer.parseInt(key1);
                    int attemptNumber2 = Integer.parseInt(key2);
                    return Integer.compare(attemptNumber2, attemptNumber1); // Descending order
                });

                for (DataSnapshot attemptSnapshot : attemptSnapshots) {
                    String attemptKey = attemptSnapshot.getKey();
                    listDataHeader.add(attemptKey);
                    List<Map<String, Object>> answersAndAdditionalData = new ArrayList<>();

                    // Extract answers and additional data separately
                    for (DataSnapshot answerSnapshot : attemptSnapshot.getChildren()) {
                        String key = answerSnapshot.getKey();
                        if (key == null || key.matches("\\d+")) { // This is an answer
                            Map<String, Object> answerMap = new HashMap<>();
                            answerMap.put("Answer", answerSnapshot.child("Answer").getValue(String.class));
                            answerMap.put("Timestamp", answerSnapshot.child("Timestamp").getValue(String.class));
                            answerMap.put("CognitiveSituation", answerSnapshot.child("CognitiveSituation").getValue(String.class));
                            answerMap.put("Domain", answerSnapshot.child("Domain").getValue(String.class));
                            answerMap.put("Score", answerSnapshot.child("Score").getValue(String.class));
                            answersAndAdditionalData.add(answerMap);
                        } else { // This is additional data (CognitiveSituationScores, DomainScores, etc.)
                            Map<String, Object> additionalDataMap = new HashMap<>();
                            additionalDataMap.put(key, answerSnapshot.getValue());
                            answersAndAdditionalData.add(additionalDataMap);
                        }
                    }

                    listDataChild.put(attemptKey, answersAndAdditionalData);
                }

                displayAnswers(listDataHeader, listDataChild);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("AnswerActivity", "Error fetching and displaying answers", databaseError.toException());
                Toast.makeText(AnswerActivity.this, "Failed to load answers", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayAnswers(List<String> listDataHeader, Map<String, List<Map<String, Object>>> listDataChild) {
        if (listDataHeader.isEmpty()) {
            noAnswersTextView.setVisibility(TextView.VISIBLE);
            expandableListView.setVisibility(ExpandableListView.GONE);
        } else {
            noAnswersTextView.setVisibility(TextView.GONE);
            expandableListView.setVisibility(ExpandableListView.VISIBLE);

            CustomExpandableListAdapter listAdapter = new CustomExpandableListAdapter(this, listDataHeader, listDataChild);
            expandableListView.setAdapter(listAdapter);
        }
    }
}
