package com.example.dementia_tester;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CompareFragment extends Fragment {

    private FirebaseAuth mAuth;
    private DatabaseReference userProfileRef;
    private TextView welcomeTextView;
    private FirebaseUser currentUser;
    private Spinner userSpinner1, userSpinner2;
    private FrameLayout graphContainer;
    private Button compareButton;
    private String selectedUser1Id, selectedUser2Id;
    private String userType;

    private List<UserProfile> userList = new ArrayList<>(); // Store user profiles

    public CompareFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_compare, container, false);

        // Initialize UI elements
        initializeUI(view);

        // Setup Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        // Get userType from the parent activity
        if (getActivity() != null) {
            userType = ((NavigationDrawerActivity) getActivity()).getIntent().getStringExtra("USER_TYPE");
        }

        // Check if the user is logged in and set up the database reference
        if (currentUser != null) {
            userProfileRef = FirebaseDatabase.getInstance().getReference("UserProfiles").child(currentUser.getUid());
            fetchUserFullName();

            // Since the userType is "doctor", set up the doctor's view
            setupDoctorView();
        }

        return view;
    }

    /**
     * Setup the view for doctors.
     * Doctors will have access to view and compare the graphs of two users.
     */
    private void setupDoctorView() {
        // Show the GraphContainer and Compare Button
        graphContainer.setVisibility(View.VISIBLE);
        compareButton.setVisibility(View.GONE);
        userSpinner2.setVisibility(View.GONE); // Hide the second spinner initially

        // Fetch all user profiles for the doctor to view individual graphs
        DatabaseReference allUserProfilesRef = FirebaseDatabase.getInstance().getReference("UserProfiles");
        allUserProfilesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userList.clear();
                List<String> userNames = new ArrayList<>();

                // Add the placeholder option as the first item in the Spinner
                userNames.add("Select first user to compare");

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    UserProfile userProfile = snapshot.getValue(UserProfile.class);
                    if (userProfile != null && !"doctor".equalsIgnoreCase(userProfile.getUserType())) {
                        userList.add(userProfile);
                        userNames.add(userProfile.getFullName() + "\n<" + userProfile.getEmail() + ">");
                    }
                }

                // Setup the first Spinner (dropdown) with user names
                setupUserSpinner1(userList, userNames);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), "Failed to load user profiles: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Setup the first Spinner for doctors to select the first user.
     * @param userList The list of all user profiles.
     * @param userNames The list of all user names (for display in the Spinner).
     */
    private void setupUserSpinner1(List<UserProfile> userList, List<String> userNames) {
        try {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, userNames);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            userSpinner1.setAdapter(adapter);

            // Handle selection for the first user spinner
            userSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0) { // "Select first user to compare"
                        selectedUser1Id = null;
                        userSpinner2.setVisibility(View.GONE); // Hide the second spinner if no user is selected
                    } else {
                        UserProfile selectedUser1 = userList.get(position - 1); // Adjust for placeholder
                        selectedUser1Id = selectedUser1.getUserId();
                        setupUserSpinner2(selectedUser1Id); // Set up the second spinner with filtered list
                        userSpinner2.setVisibility(View.VISIBLE); // Show the second spinner
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Do nothing
                }
            });
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    /**
     * Setup the second Spinner for doctors to select the second user, excluding the first selected user.
     * @param selectedUser1Id The ID of the user selected in the first spinner.
     */

    private void setupUserSpinner2(String selectedUser1Id) {
        List<String> userNames = new ArrayList<>();
        userNames.add("Select second user to compare");

        // Filter out the first selected user
        List<UserProfile> filteredUserList = new ArrayList<>();
        for (UserProfile userProfile : userList) {
            // Safely handle the case where selectedUser1Id is null
            if (selectedUser1Id == null || !selectedUser1Id.equals(userProfile.getUserId())) {
                filteredUserList.add(userProfile);
                userNames.add(userProfile.getFullName() + " <" + userProfile.getEmail() + ">");
            }
        }

        try {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, userNames);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            userSpinner2.setAdapter(adapter);

            // Handle selection for the second user spinner
            userSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0) { // "Select second user to compare"
                        selectedUser2Id = null;
                        compareButton.setVisibility(View.GONE); // Hide the compare button
                    } else {
                        UserProfile selectedUser2 = filteredUserList.get(position - 1); // Adjust for placeholder
                        selectedUser2Id = selectedUser2.getUserId();
                        compareButton.setVisibility(View.VISIBLE); // Show the compare button
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Do nothing
                }
            });
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }


    /**
     * Initialize UI components and setup initial values or listeners.
     * @param view The root view of the fragment.
     */
    private void initializeUI(View view) {
        // Find and assign the Spinners for user selection
        userSpinner1 = view.findViewById(R.id.userSpinner1);
        userSpinner2 = view.findViewById(R.id.userSpinner2);

        // Find and assign the TextView for the welcome message
        welcomeTextView = view.findViewById(R.id.helloText);

        // Find and assign the GraphContainer
        graphContainer = view.findViewById(R.id.graphContainer);

        // Find and assign the Compare Button
        compareButton = view.findViewById(R.id.buttonCompare);

        // Set an OnClickListener for the compare button to show graphs when clicked
        compareButton.setOnClickListener(v -> showComparisonGraphs());
    }

    /**
     * Fetch the user's full name from Firebase and update the welcome TextView.
     */
    private void fetchUserFullName() {
        userProfileRef.child("fullName").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String fullName = dataSnapshot.getValue(String.class);
                if (fullName != null) {
                    welcomeTextView.setText("Hello, " + fullName);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getActivity(), "Failed to load full name: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Show the graphs of the selected users for comparison.
     */
    private void showComparisonGraphs() {
        if (selectedUser1Id != null && selectedUser2Id != null) {
            Fragment compareGraphFragment = CompareGraphFragment.newInstance(selectedUser1Id, selectedUser2Id);
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.graphContainer, compareGraphFragment)
                    .commit();
        }
    }
}
