package com.example.dementia_tester;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


public class AppointmentDetailsFragment extends Fragment {
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Find the TextView for accordions
        TextView patientInfoTitle = view.findViewById(R.id.patientInfoTitle);
        TextView specialist1InfoTitle = view.findViewById(R.id.specialist1Title);
        TextView specialist2InfoTitle = view.findViewById(R.id.specialist2Title);

        //Find the LinearLayout for accordions content
        LinearLayout patientInfoContent = view.findViewById(R.id.patientInfoContent);
        LinearLayout specialist1InfoContent = view.findViewById(R.id.specialist1InfoContent);
        LinearLayout specialist2InfoContent = view.findViewById(R.id.specialist2InfoContent);

        // Set click listener to toggle visibility for patient information accordion
        patientInfoTitle.setOnClickListener(v -> {
            toggleVisibility(patientInfoContent);
        });

        // Set click listener to toggle visibility for specialist 1 information accordion
        specialist1InfoTitle.setOnClickListener(v -> {
            toggleVisibility(specialist1InfoContent);
        });

        // Set click listener to toggle visibility for specialist 2 information accordion
        specialist2InfoTitle.setOnClickListener(v -> {
            toggleVisibility(specialist2InfoContent);
        });


    }

    public void toggleVisibility(LinearLayout content){
        if (content.getVisibility() == View.GONE) {
            content.setVisibility(View.VISIBLE);
        } else {
            content.setVisibility(View.GONE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_appointment_details, container, false);
    }
}