package com.example.dementia_tester;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class DailyTasksFragment extends Fragment {

    private RecyclerView recyclerView;
    private ToDoAdapter adapter;
    private List<ToDoItem> toDoList;

    public DailyTasksFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daily_tasks, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        toDoList = new ArrayList<>();
        // Sample data
        toDoList.add(new ToDoItem("Take medications at 10:00 PM", "Pending", true));
        toDoList.add(new ToDoItem("Evening walk at 6:00 PM", "Pending", true));
        toDoList.add(new ToDoItem("Nap for the 1hr at 3:00 PM", "Completed", false));
        toDoList.add(new ToDoItem("Take Meal at 12:00 PM", "Completed", false));

        adapter = new ToDoAdapter(toDoList);
        recyclerView.setAdapter(adapter);
    }
}