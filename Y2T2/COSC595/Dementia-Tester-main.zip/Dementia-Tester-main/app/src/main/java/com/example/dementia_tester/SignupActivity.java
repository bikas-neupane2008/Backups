package com.example.dementia_tester;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Pattern;

public class SignupActivity extends AppCompatActivity {
    private EditText email, password;
    private FirebaseAuth mAuth;
    private DatabaseReference usersDbRef;
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^.{6,}$"); // Minimum six characters

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_signup);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Firebase Auth and Database reference
        mAuth = FirebaseAuth.getInstance();
        usersDbRef = FirebaseDatabase.getInstance().getReference("UserProfiles");

        initializeUI();
    }

    private void initializeUI() {
        email = findViewById(R.id.emailEditText);
        password = findViewById(R.id.passwordEditText);
        TextView login = findViewById(R.id.loginTextView);
        Button signup = findViewById(R.id.btnSignup);

        login.setOnClickListener(view -> startActivity(new Intent(SignupActivity.this, LoginActivity.class)));
        signup.setOnClickListener(view -> signup());
    }

    private void signup() {
        String dbemail = email.getText().toString().trim().toLowerCase();
        String dbpassword = password.getText().toString().trim();

        if (!validateInput(dbemail, dbpassword)) {
            return;
        }

        // Create a new user with email and password
        mAuth.createUserWithEmailAndPassword(dbemail, dbpassword)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Sign in success, get the new user
                        FirebaseUser newUser = mAuth.getCurrentUser();
                        if (newUser != null) {
                            // Save user email and type to the database
                            saveUserToDatabase(newUser.getUid(), dbemail);
                        }
                    } else {
                        // If sign in fails, display a message to the user
                        Exception exception = task.getException();
                        String errorMessage = (exception != null) ? exception.getMessage() : "Unknown error occurred";
                        Toast.makeText(SignupActivity.this, "Authentication failed: " + errorMessage, Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void saveUserToDatabase(String userId, String email) {
        UserProfile userProfile = new UserProfile(userId, "User", "", "", "", email, "", "", "", "", "", "", "", "");

        usersDbRef.child(userId).setValue(userProfile)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(SignupActivity.this, "New User Created", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignupActivity.this, LoginActivity.class));
                    finish(); // Close the signup activity
                })
                .addOnFailureListener(e -> Toast.makeText(SignupActivity.this, "Failed to create user: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private boolean validateInput(String email, String password) {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            Toast.makeText(this, "Invalid email format", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!PASSWORD_PATTERN.matcher(password).matches()) {
            Toast.makeText(this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
