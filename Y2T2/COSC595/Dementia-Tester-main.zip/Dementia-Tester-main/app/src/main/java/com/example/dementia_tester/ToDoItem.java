package com.example.dementia_tester;


public class ToDoItem {
    private String title;
    private String state;
    private boolean notification;


    public ToDoItem(String title, String state, boolean notification) {
        this.title = title;
        this.state = state;
        this.notification = notification;
    }

    public String getTitle() {
        return title;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public boolean isNotification() {
        return notification;
    }

    public void setNotification(boolean notification) {
        this.notification = notification;
    }
}
