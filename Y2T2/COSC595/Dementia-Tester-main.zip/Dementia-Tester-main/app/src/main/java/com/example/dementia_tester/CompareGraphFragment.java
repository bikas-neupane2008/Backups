package com.example.dementia_tester;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CompareGraphFragment extends Fragment {

    private LineChart lineChart;
    private TextView tvGraphTopDetails, tvGraphLeftDetails, tvGraphRightDetails;
    private DatabaseReference userAnswersRef;
    private String userId1, userId2;

    public static CompareGraphFragment newInstance(String userId1, String userId2) {
        CompareGraphFragment fragment = new CompareGraphFragment();
        Bundle args = new Bundle();
        args.putString("USER_ID_1", userId1);
        args.putString("USER_ID_2", userId2);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        View view = inflater.inflate(R.layout.fragment_graph, container, false);

        lineChart = view.findViewById(R.id.lineChart);
        tvGraphTopDetails = view.findViewById(R.id.tvGraphTopDetails);
        tvGraphLeftDetails = view.findViewById(R.id.tvGraphLeftDetails);
        tvGraphRightDetails = view.findViewById(R.id.tvGraphRightDetails);

        if (getArguments() != null) {
            userId1 = getArguments().getString("USER_ID_1");
            userId2 = getArguments().getString("USER_ID_2");
        }

        if (userId1 != null && userId2 != null) {
            fetchAndDisplayGraphData();
        } else {
            Toast.makeText(getContext(), "User IDs are missing, hence no chart data available.", Toast.LENGTH_SHORT).show();
        }

        return view;
    }

    private void fetchAndDisplayGraphData() {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        userAnswersRef = firebaseDatabase.getReference("UserAnswers");

        // Fetch data for User 1
        userAnswersRef.child(userId1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<Entry> entriesUser1 = new ArrayList<>();
                final List<String> ncdDetailsUser1 = new ArrayList<>();
                final List<String> cognitiveDetailsUser1 = new ArrayList<>();
                final List<String> domainDetailsUser1 = new ArrayList<>();

                populateUserData(dataSnapshot, entriesUser1, ncdDetailsUser1, cognitiveDetailsUser1, domainDetailsUser1);

                // Fetch data for User 2 after User 1's data has been fetched
                userAnswersRef.child(userId2).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<Entry> entriesUser2 = new ArrayList<>();
                        final List<String> ncdDetailsUser2 = new ArrayList<>();
                        final List<String> cognitiveDetailsUser2 = new ArrayList<>();
                        final List<String> domainDetailsUser2 = new ArrayList<>();

                        populateUserData(dataSnapshot, entriesUser2, ncdDetailsUser2, cognitiveDetailsUser2, domainDetailsUser2);

                        if (entriesUser1.isEmpty() && entriesUser2.isEmpty()) {
                            Toast.makeText(getContext(), "Both users have no data to compare.", Toast.LENGTH_SHORT).show();
                        } else if (entriesUser1.isEmpty()) {
                            Toast.makeText(getContext(), "User 1 has no data to compare.", Toast.LENGTH_SHORT).show();
                        } else if (entriesUser2.isEmpty()) {
                            Toast.makeText(getContext(), "User 2 has no data to compare.", Toast.LENGTH_SHORT).show();
                        } else {
                            displayLineChart(entriesUser1, ncdDetailsUser1, cognitiveDetailsUser1, domainDetailsUser1,
                                    entriesUser2, ncdDetailsUser2, cognitiveDetailsUser2, domainDetailsUser2);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("GraphFragment", "Error fetching graph data for User 2", databaseError.toException());
                        Toast.makeText(getContext(), "Failed to load graph data for User 2", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("GraphFragment", "Error fetching graph data for User 1", databaseError.toException());
                Toast.makeText(getContext(), "Failed to load graph data for User 1", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void populateUserData(DataSnapshot dataSnapshot, List<Entry> entries,
                                  List<String> ncdDetails, List<String> cognitiveDetails, List<String> domainDetails) {
        List<DataSnapshot> sortedAttempts = new ArrayList<>();
        for (DataSnapshot attemptSnapshot : dataSnapshot.getChildren()) {
            sortedAttempts.add(attemptSnapshot);
        }
        sortedAttempts.sort((snapshot1, snapshot2) -> {
            int attemptNumber1 = extractAttemptNumber(snapshot1.getKey());
            int attemptNumber2 = extractAttemptNumber(snapshot2.getKey());
            return Integer.compare(attemptNumber1, attemptNumber2);
        });

        int attemptNumber = 1;

        for (DataSnapshot attemptSnapshot : sortedAttempts) {
            Map<String, Object> attemptData = (Map<String, Object>) attemptSnapshot.getValue();

            if (attemptData != null && attemptData.containsKey("Total Score")) {
                int totalScore = Integer.parseInt(attemptData.get("Total Score").toString());
                entries.add(new Entry(attemptNumber, totalScore));

                String ncdCategorisation = attemptData.containsKey("NCD Categorisation")
                        ? attemptData.get("NCD Categorisation").toString()
                        : "Unknown";
                ncdDetails.add(ncdCategorisation);

                Map<String, String> cognitiveSituationScores = (Map<String, String>) attemptData.get("CognitiveSituationScores");
                StringBuilder cognitiveInfo = new StringBuilder();
                if (cognitiveSituationScores != null) {
                    for (Map.Entry<String, String> entry : cognitiveSituationScores.entrySet()) {
                        cognitiveInfo.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
                    }
                }
                cognitiveDetails.add(cognitiveInfo.toString().trim());

                Map<String, String> domainScores = (Map<String, String>) attemptData.get("DomainScores");
                StringBuilder domainInfo = new StringBuilder();
                if (domainScores != null) {
                    for (Map.Entry<String, String> entry : domainScores.entrySet()) {
                        domainInfo.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
                    }
                }
                domainDetails.add(domainInfo.toString().trim());

                attemptNumber++;
            }
        }
    }

    private int extractAttemptNumber(String attemptKey) {
        if (attemptKey != null && attemptKey.startsWith("Attempt_")) {
            try {
                return Integer.parseInt(attemptKey.replace("Attempt_", ""));
            } catch (NumberFormatException e) {
                Log.e("GraphFragment", "Error parsing attempt number from key: " + attemptKey, e);
            }
        }
        return 0; // Default to 0 if there's an issue
    }

    private void displayLineChart(List<Entry> entriesUser1, final List<String> ncdDetailsUser1,
                                  final List<String> cognitiveDetailsUser1, final List<String> domainDetailsUser1,
                                  List<Entry> entriesUser2, final List<String> ncdDetailsUser2,
                                  final List<String> cognitiveDetailsUser2, final List<String> domainDetailsUser2) {

        LineDataSet dataSet1 = new LineDataSet(entriesUser1, "User 1 Scores");
        LineDataSet dataSet2 = new LineDataSet(entriesUser2, "User 2 Scores");

        dataSet1.setLineWidth(2f);
        dataSet1.setCircleRadius(5f);
        dataSet1.setColor(ColorTemplate.COLORFUL_COLORS[0]);
        dataSet1.setCircleColor(ColorTemplate.COLORFUL_COLORS[1]);
        dataSet1.setValueTextSize(10f);
        dataSet1.setDrawHighlightIndicators(true);
        dataSet1.setHighLightColor(Color.RED);
        dataSet1.setDrawFilled(true);
        dataSet1.setFillColor(ColorTemplate.COLORFUL_COLORS[2]);

        dataSet2.setLineWidth(2f);
        dataSet2.setCircleRadius(5f);
        dataSet2.setColor(ColorTemplate.COLORFUL_COLORS[3]);
        dataSet2.setCircleColor(ColorTemplate.COLORFUL_COLORS[4]);
        dataSet2.setValueTextSize(10f);
        dataSet2.setDrawHighlightIndicators(true);
        dataSet2.setHighLightColor(Color.BLUE);
        dataSet2.setDrawFilled(true);
        dataSet2.setFillColor(ColorTemplate.COLORFUL_COLORS[4]);

        // Format values as integers
        dataSet1.setValueFormatter(new ValueFormatter() {
            @Override
            public String getPointLabel(Entry entry) {
                return String.valueOf((int) entry.getY());
            }
        });

        dataSet2.setValueFormatter(new ValueFormatter() {
            @Override
            public String getPointLabel(Entry entry) {
                return String.valueOf((int) entry.getY());
            }
        });

        lineChart.setDrawGridBackground(false);
        lineChart.getAxisRight().setEnabled(false);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(true);

        YAxis leftAxis = lineChart.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setAxisMaximum(100f);
        leftAxis.setDrawGridLines(true);

        lineChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                int index = (int) e.getX() - 1;
                String topDetails, leftDetails, rightDetails;

                if (index >= 0) {
                    if (entriesUser1.contains(e)) {
                        topDetails = "User 1 - Attempt: " + (index + 1) +
                                "\nTotal Score: " + (int) e.getY() +
                                "\nNCD Categorisation: " + safeGet(ncdDetailsUser1, index);
                        leftDetails = "Cognitive Details\n" + safeGet(cognitiveDetailsUser1, index);
                        rightDetails = "Domain Details\n" + safeGet(domainDetailsUser1, index);
                    } else {
                        topDetails = "User 2 - Attempt: " + (index + 1) +
                                "\nTotal Score: " + (int) e.getY() +
                                "\nNCD Categorisation: " + safeGet(ncdDetailsUser2, index);
                        leftDetails = "Cognitive Details\n" + safeGet(cognitiveDetailsUser2, index);
                        rightDetails = "Domain Details\n" + safeGet(domainDetailsUser2, index);
                    }

                    tvGraphTopDetails.setText(topDetails);
                    tvGraphLeftDetails.setText(leftDetails);
                    tvGraphRightDetails.setText(rightDetails);
                }
            }

            @Override
            public void onNothingSelected() {
                tvGraphTopDetails.setText("Select a point on the graph to see details");
                tvGraphLeftDetails.setText("Cognitive Details");
                tvGraphRightDetails.setText("Domain Details");
            }
        });

        LineData lineData = new LineData(dataSet1, dataSet2);
        lineChart.setData(lineData);

        Description description = new Description();
        description.setText("Scores over Attempts");
        lineChart.setDescription(description);

        lineChart.invalidate();
    }

    private String safeGet(List<String> list, int index) {
        if (index >= 0 && index < list.size()) {
            return list.get(index);
        }
        return "N/A";
    }
}
