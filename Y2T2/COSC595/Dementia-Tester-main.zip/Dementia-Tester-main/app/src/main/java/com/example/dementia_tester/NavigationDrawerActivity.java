package com.example.dementia_tester;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class NavigationDrawerActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private FirebaseAuth mAuth;
    private DrawerLayout drawerLayout;
    private DatabaseReference userProfileRef;
    private TextView navHeaderUserName, navHeaderUserAge;
    private ImageView navHeaderUserImage;
    private String userType;  // Store the user type
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        // Get userType from intent or SharedPreferences
        userType = getIntent().getStringExtra("USER_TYPE");
        if (userType == null) {
            userType = sharedPreferences.getString("USER_TYPE", "");
        } else {
            // Save userType in SharedPreferences
            sharedPreferences.edit().putString("USER_TYPE", userType).apply();
        }

        // Initialize Firebase
        FirebaseApp.initializeApp(this);

        setContentView(R.layout.activity_navigation_drawer);

        // Initialize FirebaseAuth instance
        mAuth = FirebaseAuth.getInstance();
        userProfileRef = FirebaseDatabase.getInstance().getReference("UserProfiles");

        // Initialize UI elements
        initializeUI();

        if ("doctor".equalsIgnoreCase(userType)) {
            // Restrict access for doctors
            restrictAccessForDoctors();
        }

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new DashboardFragment()).commit();
            NavigationView navigationView = findViewById(R.id.nav_view);
            navigationView.setCheckedItem(R.id.nav_dashboard);
        }
    }

    private void initializeUI() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View headerView = navigationView.getHeaderView(0);
        navHeaderUserName = headerView.findViewById(R.id.userFullName);
        navHeaderUserAge = headerView.findViewById(R.id.userAge);
        navHeaderUserImage = headerView.findViewById(R.id.userImage);

        headerView.setOnClickListener(v -> {
            Intent intent = new Intent(NavigationDrawerActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void restrictAccessForDoctors() {
        NavigationView navigationView = findViewById(R.id.nav_view);
        Menu menu = navigationView.getMenu();
        menu.findItem(R.id.nav_compare).setVisible(true);
        // Disable all other menu items except Dashboard for doctors
        menu.findItem(R.id.nav_activities).setVisible(false);
        menu.findItem(R.id.nav_remainders).setVisible(false);
        menu.findItem(R.id.nav_book_appointment).setVisible(false);
        menu.findItem(R.id.nav_contact).setVisible(false);
        menu.findItem(R.id.nav_chat).setVisible(false);
        menu.findItem(R.id.nav_settings).setVisible(false);
        menu.findItem(R.id.nav_help).setVisible(false);
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            startActivity(new Intent(NavigationDrawerActivity.this, LoginActivity.class));
        } else {
            loadUserProfile(currentUser.getEmail());
        }
    }

    private void loadUserProfile(String email) {
        userProfileRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    UserProfile userProfile = snapshot.getValue(UserProfile.class);
                    if (userProfile != null) {
                        updateNavHeaderWithProfileData(userProfile);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(NavigationDrawerActivity.this, "Failed to load profile: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateNavHeaderWithProfileData(UserProfile userProfile) {
        navHeaderUserName.setText(userProfile.getFullName());
        int age = calculateAge(userProfile.getDob());
        navHeaderUserAge.setText(String.format(Locale.getDefault(), "%d years", age));

        // Load the profile image
        if (userProfile.getProfileImageUrl() != null && !userProfile.getProfileImageUrl().isEmpty()) {
            Picasso.get()
                    .load(userProfile.getProfileImageUrl())
                    .transform(new CircleTransform())
                    .into(navHeaderUserImage);
        } else {
            Picasso.get()
                    .load(R.drawable.ic_person) // Default placeholder image
                    .transform(new CircleTransform())
                    .into(navHeaderUserImage);
        }
    }

    private int calculateAge(String dob) {
        if (dob == null || dob.isEmpty()) {
            return 0; // Return default age if dob is null or empty
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        try {
            Calendar dobCalendar = Calendar.getInstance();
            dobCalendar.setTime(sdf.parse(dob)); // Parse date of birth
            Calendar today = Calendar.getInstance();

            int age = today.get(Calendar.YEAR) - dobCalendar.get(Calendar.YEAR);

            if (today.get(Calendar.DAY_OF_YEAR) < dobCalendar.get(Calendar.DAY_OF_YEAR)) {
                age--; // Adjust age if the current day of the year is before the birth day
            }

            return age;
        } catch (Exception e) {
            e.printStackTrace();
            return 0; // Return default age in case of error
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        // Handle navigation for all users
        if (id == R.id.nav_logout) {
            // Clear all data from SharedPreferences
            sharedPreferences.edit().clear().apply();
            // Logout should be available for all users
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(NavigationDrawerActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } else if (id == R.id.nav_dashboard) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new DashboardFragment()).commit();
        }else if (id == R.id.nav_compare) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new CompareFragment()).commit();
        }else if (!"doctor".equalsIgnoreCase(userType)) {
            // If user is not a doctor, allow access to other fragments
            if (id == R.id.nav_activities) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ActivitiesFragment()).commit();
            } else if (id == R.id.nav_remainders) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new RemaindersFragment()).commit();
            } else if (id == R.id.nav_book_appointment) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Book_AppointmentFragment()).commit();
            } else if (id == R.id.nav_contact) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ContactFragment()).commit();
            } else if (id == R.id.nav_chat) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ChatFragment()).commit();
            } else if (id == R.id.nav_settings) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new SettingsFragment()).commit();
            } else if (id == R.id.nav_help) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HelpFragment()).commit();
            }
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            // Check if the current fragment handles back presses
            Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
            if (currentFragment instanceof OnBackPressedListener) {
                ((OnBackPressedListener) currentFragment).onBackPressed();
            } else {
                super.onBackPressed();
            }
        }
    }

    // Interface for fragments to handle back presses
    public interface OnBackPressedListener {
        void onBackPressed();
    }
}
