package com.example.dementia_tester;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GraphFragment extends Fragment {

    private LineChart lineChart;
    private TextView tvGraphTopDetails, tvGraphLeftDetails, tvGraphRightDetails, mlPrediction;
    private DatabaseReference userAnswersRef;
    private String userId;

    public static GraphFragment newInstance(String userId) {
        GraphFragment fragment = new GraphFragment();
        Bundle args = new Bundle();
        args.putString("USER_ID", userId);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_graph, container, false);

        // Initialize the lineChart view and TextView for graph details
        lineChart = view.findViewById(R.id.lineChart);
        mlPrediction = view.findViewById(R.id.mlPrediction);
        tvGraphTopDetails = view.findViewById(R.id.tvGraphTopDetails);
        tvGraphLeftDetails = view.findViewById(R.id.tvGraphLeftDetails);
        tvGraphRightDetails = view.findViewById(R.id.tvGraphRightDetails);

        if (getArguments() != null) {
            userId = getArguments().getString("USER_ID");
        }

        if (userId != null) {
            fetchAndDisplayGraphData();
        } else {
            Toast.makeText(getContext(), "User ID is missing, hence no chart data available.", Toast.LENGTH_SHORT).show();
        }

        return view;
    }

    private void fetchAndDisplayGraphData() {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        userAnswersRef = firebaseDatabase.getReference("UserAnswers");

        userAnswersRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                // Existing code to collect entries and details
                List<Entry> entries = new ArrayList<>();
                final List<String> ncdDetails = new ArrayList<>();
                final List<String> cognitiveDetails = new ArrayList<>();
                final List<String> domainDetails = new ArrayList<>();

                // Create a sorted list based on the numeric value of the attempt number
                List<DataSnapshot> sortedAttempts = new ArrayList<>();
                for (DataSnapshot attemptSnapshot : dataSnapshot.getChildren()) {
                    sortedAttempts.add(attemptSnapshot);
                }
                sortedAttempts.sort((snapshot1, snapshot2) -> {
                    int attemptNumber1 = extractAttemptNumber(snapshot1.getKey());
                    int attemptNumber2 = extractAttemptNumber(snapshot2.getKey());
                    return Integer.compare(attemptNumber1, attemptNumber2);
                });

                int attemptNumber = 1;

                for (DataSnapshot attemptSnapshot : sortedAttempts) {
                    Map<String, Object> attemptData = (Map<String, Object>) attemptSnapshot.getValue();

                    if (attemptData != null && attemptData.containsKey("Total Score")) {
                        int totalScore = Integer.parseInt(attemptData.get("Total Score").toString());

                        entries.add(new Entry(attemptNumber, totalScore));

                        // Store NCD categorization, cognitive details, and domain details for this attempt
                        String ncdCategorisation = attemptData.containsKey("NCD Categorisation")
                                ? attemptData.get("NCD Categorisation").toString()
                                : "Unknown";
                        ncdDetails.add(ncdCategorisation);

                        // Cognitive situation scores
                        Map<String, String> cognitiveSituationScores = (Map<String, String>) attemptData.get("CognitiveSituationScores");
                        StringBuilder cognitiveInfo = new StringBuilder();
                        if (cognitiveSituationScores != null) {
                            for (Map.Entry<String, String> entry : cognitiveSituationScores.entrySet()) {
                                cognitiveInfo.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
                            }
                        }
                        cognitiveDetails.add(cognitiveInfo.toString().trim());

                        // Domain scores
                        Map<String, String> domainScores = (Map<String, String>) attemptData.get("DomainScores");
                        StringBuilder domainInfo = new StringBuilder();
                        if (domainScores != null) {
                            for (Map.Entry<String, String> entry : domainScores.entrySet()) {
                                domainInfo.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
                            }
                        }
                        domainDetails.add(domainInfo.toString().trim());

                        attemptNumber++;
                    }
                }

                // Display the line chart
                displayLineChart(entries, ncdDetails, cognitiveDetails, domainDetails);

                // Perform ML Prediction if there are at least 6 attempts
                if (entries.size() >= 6) {
                    computeMLPrediction(entries);
                } else {
                    mlPrediction.setText("At least 6 attempts needed for ML Prediction.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("GraphFragment", "Error fetching graph data", databaseError.toException());
                Toast.makeText(getContext(), "Failed to load graph data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void computeMLPrediction(List<Entry> entries) {
        int N = entries.size();
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

        for (Entry entry : entries) {
            double x = entry.getX();
            double y = entry.getY();
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumX2 += x * x;
        }

        // Calculate slope (m) and intercept (b)
        double m = (N * sumXY - sumX * sumY) / (N * sumX2 - sumX * sumX);
        double b = (sumY - m * sumX) / N;

        // Get the last total score and attempt number
        double lastAttemptNumber = entries.get(N - 1).getX();
        double lastTotalScore = entries.get(N - 1).getY();

        // Determine current NCD stage
        String currentStage = getNCDStage((int) lastTotalScore);

        // Determine next NCD stage
        String nextStage = getNextNCDStage(currentStage);

        if (nextStage.equals("Maximum")) {
            mlPrediction.setText("ML Prediction: Already at the highest NCD stage.");
            return;
        }

        // Threshold scores for NCD stages
        int thresholdScore = getThresholdScore(nextStage);

        // Predict when the total score will reach the threshold
        if (m <= 0) {
            mlPrediction.setText("ML Prediction: Not progressing to the next NCD stage.");
            return;
        }

        double predictedAttemptNumber = (thresholdScore - b) / m;
        double deltaAttempts = predictedAttemptNumber - lastAttemptNumber;

        if (deltaAttempts <= 0) {
            mlPrediction.setText("ML Prediction: Not progressing to the next NCD stage.");
            return;
        }

        // Each attempt is 2 weeks apart
        int deltaWeeks = (int) Math.round(deltaAttempts * 2);

        mlPrediction.setText("ML Prediction: Next stage (" + nextStage + ") in next " + deltaWeeks + " weeks.");
    }

    private String getNCDStage(int totalScore) {
        if (totalScore >= 0 && totalScore <= 40) {
            return "NO NCD";
        } else if (totalScore >= 41 && totalScore <= 75) {
            return "Mild NCD";
        } else if (totalScore >= 76 && totalScore <= 100) {
            return "Major NCD";
        } else {
            return "Unknown";
        }
    }

    private String getNextNCDStage(String currentStage) {
        switch (currentStage) {
            case "NO NCD":
                return "Mild NCD";
            case "Mild NCD":
                return "Major NCD";
            case "Major NCD":
                return "Maximum";
            default:
                return "Unknown";
        }
    }

    private int getThresholdScore(String nextStage) {
        switch (nextStage) {
            case "Mild NCD":
                return 41;
            case "Major NCD":
                return 76;
            default:
                return 100; // Assuming 100 is the maximum possible score
        }
    }

    private int extractAttemptNumber(String attemptKey) {
        if (attemptKey != null && attemptKey.startsWith("Attempt_")) {
            try {
                return Integer.parseInt(attemptKey.replace("Attempt_", ""));
            } catch (NumberFormatException e) {
                Log.e("GraphFragment", "Error parsing attempt number from key: " + attemptKey, e);
            }
        }
        return 0; // Default to 0 if there's an issue
    }

    private void displayLineChart(List<Entry> entries, final List<String> ncdDetails,
                                  final List<String> cognitiveDetails, final List<String> domainDetails) {
        LineDataSet dataSet = new LineDataSet(entries, "Attempt Scores");

        // Customize dataset appearance
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(5f);
        dataSet.setColor(ColorTemplate.COLORFUL_COLORS[0]);
        dataSet.setCircleColor(ColorTemplate.COLORFUL_COLORS[1]);
        dataSet.setValueTextSize(10f);
        dataSet.setDrawHighlightIndicators(true);
        dataSet.setHighLightColor(Color.RED);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(ColorTemplate.COLORFUL_COLORS[2]);

        // Format values as integers
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getPointLabel(Entry entry) {
                return String.valueOf((int) entry.getY());
            }
        });

        // Style chart appearance
        lineChart.setDrawGridBackground(false);
        lineChart.getAxisRight().setEnabled(false); // Disable right axis

        // X-axis configuration
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f); // Only display whole numbers on the x-axis
        xAxis.setDrawGridLines(true);

        // Y-axis configuration
        YAxis leftAxis = lineChart.getAxisLeft();
        leftAxis.setAxisMinimum(0f); // Start y-axis from 0
        leftAxis.setAxisMaximum(100f); // Assuming maximum score is 100
        leftAxis.setDrawGridLines(true);

        // Adding markers and tooltips
        lineChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                int index = (int) e.getX() - 1; // Adjust for 0-based indexing
                String topDetails = "Attempt: " + (index + 1) +
                        "\nTotal Score: " + (int) e.getY() +
                        "\nNCD Categorisation: " + ncdDetails.get(index);
                String leftDetails = "Cognitive Details\n" + cognitiveDetails.get(index);
                String rightDetails = "Domain Details\n" + domainDetails.get(index);

                // Update the TextViews with selected data
                tvGraphTopDetails.setText(topDetails);
                tvGraphLeftDetails.setText(leftDetails);
                tvGraphRightDetails.setText(rightDetails);
            }

            @Override
            public void onNothingSelected() {
                // Reset the TextViews when no point is selected
                tvGraphTopDetails.setText("Select a point on the graph to see details");
                tvGraphLeftDetails.setText("Cognitive Details");
                tvGraphRightDetails.setText("Domain Details");
            }
        });

        LineData lineData = new LineData(dataSet);
        lineChart.setData(lineData);

        // Description
        Description description = new Description();
        description.setText("Scores over Attempts");
        lineChart.setDescription(description);

        // Refresh the chart
        lineChart.invalidate();
    }
}
