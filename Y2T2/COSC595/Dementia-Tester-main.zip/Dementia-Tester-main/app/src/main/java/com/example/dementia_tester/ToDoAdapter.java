package com.example.dementia_tester;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ToDoAdapter extends RecyclerView.Adapter<ToDoAdapter.ViewHolder> {

    private List<ToDoItem> toDoList;

    public ToDoAdapter(List<ToDoItem> toDoList) {
        this.toDoList = toDoList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_todo, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ToDoItem toDoItem = toDoList.get(position);
        holder.todoTitle.setText(toDoItem.getTitle());
        holder.todoNotification.setText(toDoItem.isNotification() ? "On" : "Off");
    }

    @Override
    public int getItemCount() {
        return toDoList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView todoTitle;
        public TextView todoNotification;

        public ViewHolder(View itemView) {
            super(itemView);
            todoTitle = itemView.findViewById(R.id.todo_title);
            todoNotification = itemView.findViewById(R.id.todo_notification);
        }
    }
}
