package com.example.dementia_tester;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DashboardFragment extends Fragment {

    private FirebaseAuth mAuth;
    private DatabaseReference userProfileRef;
    private TextView welcomeTextView;
    private FirebaseUser currentUser;
    private Spinner userSpinner;
    private FrameLayout graphContainer;
    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private String userType;  // To hold the user type passed from the parent activity

    public DashboardFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        // Initialize UI elements
        initializeUI(view);

        // Setup Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        // Get userType from the parent activity
        if (getActivity() != null) {
            userType = ((NavigationDrawerActivity) getActivity()).getIntent().getStringExtra("USER_TYPE");
        }

        // Check if the user is logged in and set up the database reference
        if (currentUser != null) {
            userProfileRef = FirebaseDatabase.getInstance().getReference("UserProfiles").child(currentUser.getUid());
            fetchUserFullName();
        }

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Check if the user is logged in before proceeding with the view setup
        if (currentUser != null) {
            // First, try to get userType from the intent
            userType = ((NavigationDrawerActivity) getActivity()).getIntent().getStringExtra("USER_TYPE");

            // If userType is not available from the intent, retrieve it from SharedPreferences
            if (userType == null) {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                userType = preferences.getString("USER_TYPE", "");  // Default to an empty string if not found
            }

            if ("doctor".equalsIgnoreCase(userType)) {
                setupDoctorView();
            } else {
                setupUserView();
            }
        }
    }

    /**
     * Setup the view for doctors.
     * Doctors will only have access to view the graphs of all users.
     */
    private void setupDoctorView() {
        // Show the Spinner and GraphContainer, hide the TabLayout and ViewPager
        userSpinner.setVisibility(View.VISIBLE);
        graphContainer.setVisibility(View.VISIBLE);
        tabLayout.setVisibility(View.GONE);
        viewPager.setVisibility(View.GONE);

        // Fetch all user profiles for the doctor to view individual graphs
        DatabaseReference allUserProfilesRef = FirebaseDatabase.getInstance().getReference("UserProfiles");
        allUserProfilesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<UserProfile> userList = new ArrayList<>();
                List<String> userNames = new ArrayList<>();

                // Add the placeholder option as the first item in the Spinner
                userNames.add("Select user to view graph");

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    UserProfile userProfile = snapshot.getValue(UserProfile.class);
                    if (userProfile != null) {
                        // Skip adding doctors to the dropdown list
                        if (!"doctor".equalsIgnoreCase(userProfile.getUserType())) {
                            userList.add(userProfile);
                            userNames.add(userProfile.getFullName() + " <" + userProfile.getEmail() + ">");
                        }
                    }
                }

                // Setup the Spinner (dropdown) with user names
                setupUserSpinner(userList, userNames);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), "Failed to load user profiles: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Setup the Spinner for doctors to select a user and view their graph.
     * @param userList The list of all user profiles.
     * @param userNames The list of all user names (for display in the Spinner).
     */
    private void setupUserSpinner(List<UserProfile> userList, List<String> userNames) {
        // Ensure the context is available
        try {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, userNames);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            userSpinner.setAdapter(adapter);

            userSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0) {
                        // If the first item (placeholder) is selected, clear the graph container
                        getActivity().getSupportFragmentManager().beginTransaction()
                                .replace(R.id.graphContainer, new Fragment())  // Replace with an empty fragment
                                .commit();
                        return;
                    }

                    // Get the selected user profile (subtract 1 from position to account for the placeholder)
                    UserProfile selectedUser = userList.get(position - 1);

                    // Open the GraphFragment for the selected user without checking for data availability
                    Fragment graphFragment = GraphFragment.newInstance(selectedUser.getUserId());
                    getActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.graphContainer, graphFragment)
                            .commit();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Do nothing
                }
            });
        } catch (IllegalStateException e) {
            // If context is not available, log the exception or handle the error gracefully
            e.printStackTrace();
        }
    }

    /**
     * Setup the regular user view with multiple tabs.
     */
    private void setupUserView() {
        // Show the TabLayout and ViewPager, hide the Spinner and GraphContainer
        userSpinner.setVisibility(View.GONE);
        graphContainer.setVisibility(View.GONE);
        tabLayout.setVisibility(View.VISIBLE);
        viewPager.setVisibility(View.VISIBLE);

        // Regular user view with tabs for different activities
        String userId = currentUser != null ? currentUser.getUid() : null;

        if (userId != null) {
            ViewPagerAdapter adapter = new ViewPagerAdapter(requireActivity(), userId);
            viewPager.setAdapter(adapter);

            new TabLayoutMediator(tabLayout, viewPager,
                    (tab, position) -> {
                        switch (position) {
                            case 0:
                                tab.setText("Daily tasks");
                                break;
                            case 1:
                                tab.setText("Graph View");
                                break;
                            case 2:
                                tab.setText("Memory games");
                                break;
                        }
                    }).attach();
        }
    }

    /**
     * Initialize UI components and setup initial values or listeners.
     * @param view The root view of the fragment.
     */
    private void initializeUI(View view) {
        // Find and assign the Spinner for the user selection
        userSpinner = view.findViewById(R.id.userSpinner);

        // Find and assign the TextView for the welcome message
        welcomeTextView = view.findViewById(R.id.helloText);

        // Find and assign the GraphContainer
        graphContainer = view.findViewById(R.id.graphContainer);

        // Find and assign the TabLayout and ViewPager for regular users
        tabLayout = view.findViewById(R.id.tabLayout);
        viewPager = view.findViewById(R.id.viewPager);

        // Optionally set initial text or perform other UI setup here
        welcomeTextView.setText("Hello,");
    }

    /**
     * Fetch the user's full name from Firebase and update the welcome TextView.
     */
    private void fetchUserFullName() {
        userProfileRef.child("fullName").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String fullName = dataSnapshot.getValue(String.class);
                if (fullName != null) {
                    welcomeTextView.setText("Hello, " + fullName);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getActivity(), "Failed to load full name: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
