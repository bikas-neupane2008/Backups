package com.example.dementia_tester;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {
    private static final int RC_SIGN_IN = 9001;
    private EditText email, password;
    private FirebaseAuth mAuth;
    private ProgressBar loadingIndicator;
    private GoogleSignInClient googleSignInClient;
    private DatabaseReference usersDbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            // If the user is still logged in, sign them out
            FirebaseAuth.getInstance().signOut();
        }

        initializeUI();

        // Configure Google Sign-In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, gso);
        mAuth = FirebaseAuth.getInstance();
        usersDbRef = FirebaseDatabase.getInstance().getReference("UserProfiles");
    }

    private void initializeUI() {
        email = findViewById(R.id.editTextEmail);
        password = findViewById(R.id.editTextPassword);
        TextView signup = findViewById(R.id.textViewSignUp);
        Button login = findViewById(R.id.buttonLogin);
        loadingIndicator = findViewById(R.id.loadingIndicator);
        TextView forgotPassword = findViewById(R.id.textViewForgotPassword);
        SignInButton googlelogin = findViewById(R.id.buttonGoogleLogin);

        signup.setOnClickListener(view -> startActivity(new Intent(LoginActivity.this, SignupActivity.class)));
        login.setOnClickListener(view -> loginWithEmailPassword());
        googlelogin.setOnClickListener(view -> loginWithGoogle());
        forgotPassword.setOnClickListener(view -> resetPassword());
    }

    private void resetPassword() {
        String emailAddress = email.getText().toString().trim().toLowerCase();

        if (emailAddress.isEmpty()) {
            Toast.makeText(this, "Please enter your email address.", Toast.LENGTH_SHORT).show();
            return;
        }

        loadingIndicator.setVisibility(View.VISIBLE);

        mAuth.sendPasswordResetEmail(emailAddress)
                .addOnCompleteListener(task -> {
                    loadingIndicator.setVisibility(View.GONE);
                    if (task.isSuccessful()) {
                        Toast.makeText(LoginActivity.this, "Password reset email sent.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "Failed to send password reset email. Please check your email and try again.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void loginWithEmailPassword() {
        String dbemail = email.getText().toString().trim().toLowerCase();
        String dbpassword = password.getText().toString().trim();

        if (!validateInput(dbemail, dbpassword)) {
            return;
        }

        loadingIndicator.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(dbemail, dbpassword)
                .addOnCompleteListener(this, signInTask -> {
                    loadingIndicator.setVisibility(View.GONE);
                    if (signInTask.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            fetchUserType(user.getUid());
                        }
                    } else {
                        // Notify user if authentication failed
                        Toast.makeText(LoginActivity.this, "Authentication Failed. Please check your credentials or sign up.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void loginWithGoogle() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                String email = account.getEmail();
                String idToken = account.getIdToken();

                if (email != null) {
                    handleGoogleSignIn(email, idToken);
                }
            } catch (ApiException e) {
                Toast.makeText(this, "Google sign-in failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void handleGoogleSignIn(String email, String googleIdToken) {
        loadingIndicator.setVisibility(View.VISIBLE);

        mAuth.fetchSignInMethodsForEmail(email)
                .addOnCompleteListener(task -> {
                    loadingIndicator.setVisibility(View.GONE);
                    if (task.isSuccessful()) {
                        boolean isEmailPasswordAccountExists = task.getResult().getSignInMethods().contains(EmailAuthProvider.EMAIL_PASSWORD_SIGN_IN_METHOD);

                        AuthCredential googleCredential = GoogleAuthProvider.getCredential(googleIdToken, null);
                        mAuth.signInWithCredential(googleCredential)
                                .addOnCompleteListener(this, googleSignInTask -> {
                                    if (googleSignInTask.isSuccessful()) {
                                        FirebaseUser user = mAuth.getCurrentUser();
                                        if (user != null) {
                                            if (!isEmailPasswordAccountExists) {
                                                // Only link the account with default password if there is no existing email/password account
                                                linkAccountWithDefaultPassword(user, email);
                                            } else {
                                                // Account is already linked, proceed to check user type
                                                checkAndCreateUser(user);
                                            }
                                        }
                                    } else {
                                        Toast.makeText(LoginActivity.this, "Google sign-in failed: " + googleSignInTask.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        Toast.makeText(LoginActivity.this, "Failed to check email existence: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // Method to link Google account with a default password if no email/password account exists
    private void linkAccountWithDefaultPassword(FirebaseUser user, String email) {
        // Use "password" as the default password only if no email/password account exists
        String defaultPassword = "password";

        AuthCredential credential = EmailAuthProvider.getCredential(email, defaultPassword);

        user.linkWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // The account linking was successful
                        Toast.makeText(LoginActivity.this, "Email/Password account linked with default password.", Toast.LENGTH_SHORT).show();
                        FirebaseUser updatedUser = task.getResult().getUser();
                        // Optionally update the UI or perform additional actions
                        checkAndCreateUser(updatedUser);
                    } else {
                        // If account linking fails because it's already linked, proceed to user verification
                        checkAndCreateUser(user);
                    }
                });
    }

    private void checkAndCreateUser(FirebaseUser user) {
        String userId = user.getUid();
        String userEmail = user.getEmail();
        usersDbRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    createUserEntry(userId, userEmail, "User");
                } else {
                    fetchUserType(userId);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(LoginActivity.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createUserEntry(String userId, String email, String userType) {
        UserProfile userProfile = new UserProfile(userId, userType, "", "", "", email, "", "", "", "", "", "", "", "");
        usersDbRef.child(userId).setValue(userProfile)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(LoginActivity.this, "New user entry created for: " + email, Toast.LENGTH_SHORT).show();
                    fetchUserType(userId);
                })
                .addOnFailureListener(e -> Toast.makeText(LoginActivity.this, "Failed to create user entry: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void fetchUserType(String userId) {
        usersDbRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    UserProfile userProfile = dataSnapshot.getValue(UserProfile.class);
                    if (userProfile != null) {
                        String userType = userProfile.getUserType();
                        switch (userType.toLowerCase()) {
                            case "user":
                                updateUI(userType);
                                break;
                            case "doctor":
                                updateUI(userType);
                                break;
                            case "carer":
                                updateUI(userType);
                                break;
                            default:
                                Toast.makeText(LoginActivity.this, "User type not recognized.", Toast.LENGTH_SHORT).show();
                                break;
                        }
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "User data not found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(LoginActivity.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validateInput(String email, String password) {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void updateUI(String userType) {
        Intent intent = null;
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("USER_TYPE", userType);  // Save the userType
        editor.apply();
        if ("user".equalsIgnoreCase(userType)) {
            Toast.makeText(LoginActivity.this, "Logged in as: User", Toast.LENGTH_SHORT).show();
            intent = new Intent(LoginActivity.this, ProfileActivity.class);
        } else if ("doctor".equalsIgnoreCase(userType)) {
            Toast.makeText(LoginActivity.this, "Logged in as: Doctor", Toast.LENGTH_SHORT).show();
            intent = new Intent(LoginActivity.this, NavigationDrawerActivity.class);
            intent.putExtra("USER_TYPE", "doctor");
        } else if ("carer".equalsIgnoreCase(userType)) {
            Toast.makeText(LoginActivity.this, "Logged in as: Carer", Toast.LENGTH_SHORT).show();
            // intent = new Intent(LoginActivity.this, AnswerActivity.class);
        }
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        // Prevent back navigation
        moveTaskToBack(true);
    }
}
