package com.example.dementia_tester;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ProfileActivity extends AppCompatActivity {

    private DatabaseReference userProfileRef;
    private FirebaseAuth mAuth;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    private EditText fullNameEditText, dobEditText, contactNumberEditText, emailEditText, addressEditText,
            emergencyContactNameEditText, relationEditText, emergencyContactNumberEditText, emergencyEmailEditText,
            emergencyAddressEditText;
    private RadioGroup genderGroup;
    private Button btnSave, btnQuestions, btnAnswers, btnCancel;
    private String userfullname;
    private TextView user_fullname, user_age, emergencyContactTitle;
    private ImageView profileImageView;
    private ProgressBar progressBar;
    private RelativeLayout contentLayout;
    private Uri imageUri;
    SharedPreferences sharedPreferences;
    String userType;
    FirebaseDatabase database;
    FirebaseUser currentUser;

    // Initialize the Photo Picker Activity Result Launcher
    private final ActivityResultLauncher<Intent> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    imageUri = result.getData().getData();
                    Picasso.get()
                            .load(imageUri)
                            .transform(new CircleTransform())
                            .into(profileImageView);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        userProfileRef = database.getReference("UserProfiles");
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference("ProfileImages");

        currentUser = mAuth.getCurrentUser();

        initializeUI();

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        userType = sharedPreferences.getString("USER_TYPE", "");

        // If the user is a doctor, hide the relevant fields
        if ("doctor".equalsIgnoreCase(userType)) {
            hideFieldsForDoctor();
        }

        btnSave.setOnClickListener(view -> {
            if (currentUser != null) {
                if (areFieldsValid(userType)) {
                    uploadImageAndSaveProfile();
                } else {
                    Toast.makeText(ProfileActivity.this, "Please fill all mandatory fields.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        profileImageView.setOnClickListener(view -> openImageChooser());

        loadUserProfile();
    }

    private void initializeUI() {
        user_fullname = findViewById(R.id.userName);
        fullNameEditText = findViewById(R.id.fullName);
        dobEditText = findViewById(R.id.dob);
        contactNumberEditText = findViewById(R.id.contactNumber);
        emailEditText = findViewById(R.id.email);
        addressEditText = findViewById(R.id.address);
        emergencyContactTitle = findViewById(R.id.emergencyContactTitle);
        emergencyContactNameEditText = findViewById(R.id.emergencyContactName);
        relationEditText = findViewById(R.id.relation);
        emergencyContactNumberEditText = findViewById(R.id.emergencycontactNumber);
        emergencyEmailEditText = findViewById(R.id.emergencyemail);
        emergencyAddressEditText = findViewById(R.id.emergencyaddress);
        genderGroup = findViewById(R.id.genderGroup);

        btnCancel = findViewById(R.id.cancelButton);
        btnSave = findViewById(R.id.saveButton);
        btnQuestions = findViewById(R.id.questionsButton);
        btnAnswers = findViewById(R.id.answersButton);
        profileImageView = findViewById(R.id.profileImage);
        progressBar = findViewById(R.id.progressBar);
        contentLayout = findViewById(R.id.contentLayout);

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            userfullname = currentUser.getDisplayName();
            emailEditText.setText(userEmail);
            emailEditText.setFocusable(false);
            emailEditText.setFocusableInTouchMode(false);
            emailEditText.setInputType(0);
            user_fullname.setText(userfullname);
        } else {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
        }

        btnQuestions.setOnClickListener(view -> {
            Intent intent = new Intent(ProfileActivity.this, QuestionsActivity.class);
            startActivity(intent);
        });

        btnAnswers.setOnClickListener(view -> {
            Intent intent = new Intent(ProfileActivity.this, AnswerActivity.class);
            startActivity(intent);
        });

        btnCancel.setOnClickListener(view -> {
            Intent intent = new Intent(ProfileActivity.this, NavigationDrawerActivity.class);
            startActivity(intent);
        });

        dobEditText.setFocusable(false);
        dobEditText.setFocusableInTouchMode(false);
        dobEditText.setInputType(InputType.TYPE_NULL);
        dobEditText.setOnClickListener(v -> showDatePickerDialog());
    }

    private void openImageChooser() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Use the Photo Picker API
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            pickImageLauncher.launch(intent);
        } else {
            // Use the traditional way for older Android versions
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            pickImageLauncher.launch(intent);
        }
    }

    private void loadUserProfile() {
        showLoading(true);

        if (currentUser != null) {
            String userId = currentUser.getUid();
            userProfileRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    UserProfile userProfile = dataSnapshot.getValue(UserProfile.class);
                    if (userProfile != null) {
                        updateUIWithProfileData(userProfile);
                    } else {
                        Toast.makeText(ProfileActivity.this, "Profile data not found.", Toast.LENGTH_SHORT).show();
                    }
                    showLoading(false);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    showLoading(false);
                    Toast.makeText(ProfileActivity.this, "Failed to load profile: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            showLoading(false);
        }
    }

    private void uploadImageAndSaveProfile() {
        showLoading(true);

        if (imageUri != null) {
            String userId = currentUser.getUid();
            // Update the path to /userID/profilepicture/profileimage.jpg
            StorageReference fileRef = storageReference.child(userId + "/profilepicture/profileimage.jpg");

            // Compress and upload the image
            compressAndUploadImage(fileRef, imageUri);
        } else {
            saveUserProfile(null);
        }
    }

    private void compressAndUploadImage(StorageReference fileRef, Uri imageUri) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);

            // Scale down the image if it's too large
            int maxDimension = Math.max(bitmap.getWidth(), bitmap.getHeight());
            if (maxDimension > 500) { // Arbitrary threshold, can be adjusted
                float scaleFactor = 500.0f / maxDimension;
                bitmap = Bitmap.createScaledBitmap(bitmap,
                        (int) (bitmap.getWidth() * scaleFactor),
                        (int) (bitmap.getHeight() * scaleFactor),
                        true);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int quality = 100;
            do {
                baos.reset();
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos);
                quality -= 5; // Decrease quality by 5% each time if not under 32KB
            } while (baos.toByteArray().length > 16 * 1024 && quality > 5); // Ensure size < 16KB

            ByteArrayInputStream imageStream = new ByteArrayInputStream(baos.toByteArray());

            fileRef.putStream(imageStream)
                    .addOnSuccessListener(taskSnapshot -> fileRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        // Store the URL in the database under /userID/profilepicture/profileImageUrl
                        userProfileRef.child(currentUser.getUid()).child("profilepicture").child("profileImageUrl").setValue(uri.toString())
                                .addOnSuccessListener(aVoid -> saveUserProfile(uri.toString()))
                                .addOnFailureListener(e -> {
                                    showLoading(false);
                                    Toast.makeText(ProfileActivity.this, "Failed to update profile image URL: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    }))
                    .addOnFailureListener(e -> {
                        showLoading(false);
                        Toast.makeText(ProfileActivity.this, "Image Upload Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });

        } catch (IOException e) {
            showLoading(false);
            e.printStackTrace();
            Toast.makeText(ProfileActivity.this, "Failed to process image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    private void saveUserProfile(String profileImageUrl) {
        String userId = currentUser.getUid();
        String userType = sharedPreferences.getString("USER_TYPE", "");
        String fullName = fullNameEditText.getText().toString().trim();
        String dob = dobEditText.getText().toString().trim();
        String contactNumber = contactNumberEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim().toLowerCase();
        String address = addressEditText.getText().toString().trim();
        String gender = ((RadioButton) findViewById(genderGroup.getCheckedRadioButtonId())).getText().toString();

        String emergencyContactName = emergencyContactNameEditText.getText().toString().trim();
        String relation = relationEditText.getText().toString().trim();
        String emergencyContactNumber = emergencyContactNumberEditText.getText().toString().trim();
        String emergencyEmail = emergencyEmailEditText.getText().toString().trim();
        String emergencyAddress = emergencyAddressEditText.getText().toString().trim();

        UserProfile userProfile = new UserProfile(userId, userType, fullName, dob, contactNumber, email, address, gender,
                emergencyContactName, relation, emergencyContactNumber, emergencyEmail, emergencyAddress, profileImageUrl);

        userProfileRef.child(userId).setValue(userProfile)
                .addOnSuccessListener(aVoid -> {
                    showLoading(false);
                    Toast.makeText(ProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(ProfileActivity.this, NavigationDrawerActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    showLoading(false);
                    Toast.makeText(ProfileActivity.this, "Profile Update Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void updateUIWithProfileData(UserProfile userProfile) {
        user_fullname.setText(userProfile.getFullName());
        user_age = findViewById(R.id.userAge);
        int age = calculateAge(userProfile.getDob());
        user_age.setText(String.format(Locale.getDefault(), "%d years", age));
        fullNameEditText.setText(userProfile.getFullName());
        dobEditText.setText(userProfile.getDob());
        contactNumberEditText.setText(userProfile.getContactNumber());
        emailEditText.setText(userProfile.getEmail());
        addressEditText.setText(userProfile.getAddress());
        setSelectedGender(userProfile.getGender());
        emergencyContactNameEditText.setText(userProfile.getEmergencyContactName());
        relationEditText.setText(userProfile.getRelation());
        emergencyContactNumberEditText.setText(userProfile.getEmergencyContactNumber());
        emergencyEmailEditText.setText(userProfile.getEmergencyEmail());
        emergencyAddressEditText.setText(userProfile.getEmergencyAddress());

        // Load profile image with circular transformation
        if (userProfile.getProfileImageUrl() != null && !userProfile.getProfileImageUrl().isEmpty()) {
            Picasso.get()
                    .load(userProfile.getProfileImageUrl())
                    .transform(new CircleTransform())
                    .into(profileImageView);
        } else {
            Picasso.get()
                    .load(R.drawable.ic_person)
                    .transform(new CircleTransform())
                    .into(profileImageView);
        }
    }

    private int calculateAge(String dob) {
        if (dob == null || dob.isEmpty()) {
            return 0; // Return default age if dob is null or empty
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        try {
            Calendar dobCalendar = Calendar.getInstance();
            dobCalendar.setTime(sdf.parse(dob)); // Parse date of birth
            Calendar today = Calendar.getInstance();

            int age = today.get(Calendar.YEAR) - dobCalendar.get(Calendar.YEAR);

            if (today.get(Calendar.DAY_OF_YEAR) < dobCalendar.get(Calendar.DAY_OF_YEAR)) {
                age--; // Adjust age if the current day of the year is before the birth day
            }

            return age;
        } catch (Exception e) {
            e.printStackTrace();
            return 0; // Return default age in case of error
        }
    }

    private void setSelectedGender(String gender) {
        for (int i = 0; i < genderGroup.getChildCount(); i++) {
            View view = genderGroup.getChildAt(i);
            if (view instanceof RadioButton) {
                RadioButton radioButton = (RadioButton) view;
                if (radioButton.getText().toString().equalsIgnoreCase(gender)) {
                    radioButton.setChecked(true);
                    break;
                }
            }
        }
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year1, month1, dayOfMonth) -> {
                    calendar.set(year1, month1, dayOfMonth);
                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
                    String formattedDate = sdf.format(calendar.getTime());
                    dobEditText.setText(formattedDate);
                },
                year, month, day);
        datePickerDialog.show();
    }

    private boolean areFieldsValid(String userType) {
        String fullName = fullNameEditText.getText().toString().trim();
        String dob = dobEditText.getText().toString().trim();
        String contactNumber = contactNumberEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String address = addressEditText.getText().toString().trim();

        if (fullName.isEmpty() || dob.isEmpty() || contactNumber.isEmpty() || email.isEmpty() || address.isEmpty()) {
            return false;
        }

        if (!"doctor".equalsIgnoreCase(userType)) {
            String emergencyContactName = emergencyContactNameEditText.getText().toString().trim();
            String relation = relationEditText.getText().toString().trim();
            String emergencyContactNumber = emergencyContactNumberEditText.getText().toString().trim();
            String emergencyEmail = emergencyEmailEditText.getText().toString().trim();
            String emergencyAddress = emergencyAddressEditText.getText().toString().trim();

            return !emergencyContactName.isEmpty() && !relation.isEmpty() &&
                    !emergencyContactNumber.isEmpty() && !emergencyEmail.isEmpty() && !emergencyAddress.isEmpty();
        }

        return true;
    }

    private void showLoading(boolean isLoading) {
        if (isLoading) {
            progressBar.setVisibility(View.VISIBLE);
            contentLayout.setVisibility(View.GONE);
        } else {
            progressBar.setVisibility(View.GONE);
            contentLayout.setVisibility(View.VISIBLE);
        }
    }

    private void hideFieldsForDoctor() {
        // Hide the emergency contact fields
        emergencyContactNameEditText.setVisibility(View.GONE);
        relationEditText.setVisibility(View.GONE);
        emergencyContactNumberEditText.setVisibility(View.GONE);
        emergencyEmailEditText.setVisibility(View.GONE);
        emergencyAddressEditText.setVisibility(View.GONE);
        emergencyContactTitle.setVisibility(View.GONE);

        // Hide the questions and answers buttons
        btnQuestions.setVisibility(View.GONE);
        btnAnswers.setVisibility(View.GONE);
    }
}
