package com.example.dementia_tester;

import android.app.AlertDialog;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class QuestionsActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_NOTIFICATION = 1;
    private static final int TOTAL_QUESTIONS = 24; // Define the total number of questions

    private TextView txtQuestionNumber, txtQuestionDomain, txtQuestionCognitive, txtQuestion;
    private RadioGroup radioGroup;
    private Button submitButton, continueButton, backButton;
    private RelativeLayout mainLayout;

    private int currentQuestionIndex;
    private String userId;
    private int attemptNumber;

    private final Map<Integer, String> selectedAnswers = new HashMap<>();

    private DatabaseReference questionsRef;
    private DatabaseReference userAnswersRef;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_questions);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        questionsRef = firebaseDatabase.getReference("Questions");
        userAnswersRef = firebaseDatabase.getReference("UserAnswers");

        initializeUI();

        userId = getUserID();
        determineAttemptAndLoadQuestion();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null && !alarmManager.canScheduleExactAlarms()) {
                showAlarmPermissionDialog();
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission();
        }

        createNotificationChannel();
    }

    private void initializeUI() {
        txtQuestionNumber = findViewById(R.id.txtquestionnumber);
        txtQuestionDomain = findViewById(R.id.txtquestiondomain);
        txtQuestionCognitive = findViewById(R.id.txtquestioncognitive);
        txtQuestion = findViewById(R.id.txtquestion);
        radioGroup = findViewById(R.id.txtradiogroup);
        submitButton = findViewById(R.id.submitButton);
        backButton = findViewById(R.id.backButton);
        continueButton = findViewById(R.id.continueButton);
        mainLayout = findViewById(R.id.main);

        submitButton.setEnabled(false);
        continueButton.setEnabled(false);

        backButton.setOnClickListener(v -> {
            startActivity(new Intent(QuestionsActivity.this, ProfileActivity.class));
            finish();
        });

        submitButton.setOnClickListener(v -> {
            saveSelectedAnswer();
            Intent intent = new Intent(QuestionsActivity.this, ProfileActivity.class);
            startActivity(intent);
            finish();
        });

        continueButton.setOnClickListener(v -> {
            saveSelectedAnswer();  // Save the current answer

            if (currentQuestionIndex < TOTAL_QUESTIONS) {
                currentQuestionIndex++;  // Move to the next question
                loadQuestion(currentQuestionIndex);  // Load the next question
            } else {
                // All questions answered, navigate to a final screen or back to ProfileActivity
                Toast.makeText(this, "You have completed all the questions.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(QuestionsActivity.this, ProfileActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void scheduleNotificationInOneMinute() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, NotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long oneMinuteInMillis = 60 * 1000; // 1 minute

        // Set the one-time alarm
        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + oneMinuteInMillis, pendingIntent);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    private void requestNotificationPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE_NOTIFICATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_NOTIFICATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("QuestionsActivity", "Notification permission granted.");
            } else {
                Log.d("QuestionsActivity", "Notification permission denied.");
                Toast.makeText(this, "Notification permission is required to send reminders.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String getUserID() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            return currentUser.getUid();
        } else {
            Toast.makeText(this, "User not signed in", Toast.LENGTH_SHORT).show();
            finish();
            return null;
        }
    }

    private void determineAttemptAndLoadQuestion() {
        if (userId == null) return;

        userAnswersRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int lastAttempt = (int) dataSnapshot.getChildrenCount();
                if (lastAttempt == 0) {
                    // First attempt
                    attemptNumber = 1;
                    currentQuestionIndex = 1;
                } else {
                    // Check the latest attempt for unanswered questions
                    DataSnapshot latestAttemptSnapshot = dataSnapshot.child("Attempt_" + lastAttempt);
                    boolean allAnswered = true;
                    for (int question = 1; question <= TOTAL_QUESTIONS; question++) {
                        if (!latestAttemptSnapshot.hasChild(String.valueOf(question))) {
                            currentQuestionIndex = question;
                            attemptNumber = lastAttempt;
                            allAnswered = false;
                            break;
                        }
                    }
                    if (allAnswered) {
                        // All questions answered in the latest attempt, start a new attempt
                        attemptNumber = lastAttempt + 1;
                        currentQuestionIndex = 1;
                    }
                }
                loadQuestion(currentQuestionIndex);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("QuestionsActivity", "Failed to determine attempt number", databaseError.toException());
                Toast.makeText(QuestionsActivity.this, "Failed to determine attempt number", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadQuestion(int questionNumber) {
        questionsRef.child(String.valueOf(questionNumber)).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Question question = dataSnapshot.getValue(Question.class);
                if (question != null) {
                    txtQuestionNumber.setText("Question " + questionNumber + " of " + TOTAL_QUESTIONS);
                    txtQuestionDomain.setText(question.getDomain());
                    txtQuestionCognitive.setText(question.getCognitiveSituation());
                    txtQuestion.setText(question.getQuestionText());

                    radioGroup.removeAllViews();

                    RadioButton rb1 = new RadioButton(QuestionsActivity.this);
                    rb1.setText(question.getOption1());
                    radioGroup.addView(rb1);

                    RadioButton rb2 = new RadioButton(QuestionsActivity.this);
                    rb2.setText(question.getOption2());
                    radioGroup.addView(rb2);

                    RadioButton rb3 = new RadioButton(QuestionsActivity.this);
                    rb3.setText(question.getOption3());
                    radioGroup.addView(rb3);

                    RadioButton rb4 = new RadioButton(QuestionsActivity.this);
                    rb4.setText(question.getOption4());
                    radioGroup.addView(rb4);

                    RadioButton rb5 = new RadioButton(QuestionsActivity.this);
                    rb5.setText(question.getOption5());
                    radioGroup.addView(rb5);

                    if (selectedAnswers.containsKey(questionNumber)) {
                        String selectedAnswerText = selectedAnswers.get(questionNumber);
                        for (int i = 0; i < radioGroup.getChildCount(); i++) {
                            RadioButton rb = (RadioButton) radioGroup.getChildAt(i);
                            if (rb.getText().toString().equals(selectedAnswerText)) {
                                rb.setChecked(true);
                                submitButton.setEnabled(true);
                                continueButton.setEnabled(true);
                                break;
                            }
                        }
                    } else {
                        submitButton.setEnabled(false);
                        continueButton.setEnabled(false);
                    }

                    radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
                        boolean isChecked = checkedId != -1;
                        submitButton.setEnabled(isChecked);
                        continueButton.setEnabled(isChecked);  // Enable the continue button as well
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("QuestionsActivity", "Failed to load question", databaseError.toException());
                Toast.makeText(QuestionsActivity.this, "Failed to load question", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveSelectedAnswer() {
        if (userId == null) return;

        int selectedRadioButtonId = radioGroup.getCheckedRadioButtonId();
        if (selectedRadioButtonId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
            if (selectedRadioButton != null) {
                String answer = selectedRadioButton.getText().toString();
                String currentTime = getCurrentTime();

                selectedAnswers.put(currentQuestionIndex, answer);
                String cognitiveSituation = txtQuestionCognitive.getText().toString();
                String domain = txtQuestionDomain.getText().toString();
                int score = getScoreForAnswer(answer);

                // Create a map for answer and timestamp
                Map<String, String> answerData = new HashMap<>();
                answerData.put("Answer", answer);
                answerData.put("CognitiveSituation", cognitiveSituation);
                answerData.put("Domain", domain);
                answerData.put("Score", String.valueOf(score));
                answerData.put("Timestamp", currentTime);

                // Save the answer with the timestamp
                userAnswersRef.child(userId)
                        .child("Attempt_" + attemptNumber)
                        .child(String.valueOf(currentQuestionIndex))
                        .setValue(answerData);

                // Calculate the total score based on all answers for this attempt
                calculateScore();
            }
        }
    }

    private void calculateScore() {
        userAnswersRef.child(userId).child("Attempt_" + attemptNumber)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        final int[] totalScore = {0};
                        int answeredQuestions = 0;

                        // Maps to hold the total score for each Cognitive Situation and Domain
                        Map<String, Integer> cognitiveSituationScores = new HashMap<>();
                        Map<String, Integer> domainScores = new HashMap<>();

                        for (DataSnapshot answerSnapshot : dataSnapshot.getChildren()) {
                            if (!"lastUpdated".equals(answerSnapshot.getKey())) {
                                String scoreStr = answerSnapshot.child("Score").getValue(String.class);
                                String cognitiveSituation = answerSnapshot.child("CognitiveSituation").getValue(String.class);
                                String domain = answerSnapshot.child("Domain").getValue(String.class);

                                if (scoreStr != null && cognitiveSituation != null && domain != null) {
                                    // Convert score from String to Integer
                                    int score = Integer.parseInt(scoreStr);
                                    totalScore[0] += score;
                                    answeredQuestions++;

                                    // Retrieve and parse the existing score for the Cognitive Situation
                                    int currentCognitiveScore = cognitiveSituationScores.getOrDefault(cognitiveSituation, 0);
                                    cognitiveSituationScores.put(cognitiveSituation, currentCognitiveScore + score);

                                    // Retrieve and parse the existing score for the Domain
                                    int currentDomainScore = domainScores.getOrDefault(domain, 0);
                                    domainScores.put(domain, currentDomainScore + score);
                                }
                            }
                        }

                        boolean isAllQuestionsAnswered = (answeredQuestions == TOTAL_QUESTIONS);
                        String scoreType = isAllQuestionsAnswered ? "Total Score" : "Partial Score";

                        // Save the total score as a string
                        userAnswersRef.child(userId)
                                .child("Attempt_" + attemptNumber)
                                .child(scoreType)
                                .setValue(String.valueOf(totalScore[0]))
                                .addOnSuccessListener(aVoid -> {
                                    if (isAllQuestionsAnswered) {
                                        // Remove the Partial Score entry if all questions are answered
                                        userAnswersRef.child(userId)
                                                .child("Attempt_" + attemptNumber)
                                                .child("Partial Score")
                                                .removeValue()
                                                .addOnSuccessListener(aVoid1 -> {
                                                    Log.d("QuestionsActivity", "Partial Score deleted.");

                                                    // Calculate and save the NCD categorisation
                                                    String ncdCategorisation = getNCDCategorisation(totalScore[0]);
                                                    userAnswersRef.child(userId)
                                                            .child("Attempt_" + attemptNumber)
                                                            .child("NCD Categorisation")
                                                            .setValue(ncdCategorisation)
                                                            .addOnSuccessListener(aVoid2 -> Log.d("QuestionsActivity", "NCD Categorisation saved: " + ncdCategorisation))
                                                            .addOnFailureListener(e -> Log.e("QuestionsActivity", "Failed to save NCD Categorisation", e));
                                                })
                                                .addOnFailureListener(e -> Log.e("QuestionsActivity", "Failed to delete Partial Score", e));
                                    }
                                });

                        // Save the scores for each Cognitive Situation as strings
                        for (Map.Entry<String, Integer> entry : cognitiveSituationScores.entrySet()) {
                            userAnswersRef.child(userId)
                                    .child("Attempt_" + attemptNumber)
                                    .child("CognitiveSituationScores")
                                    .child(entry.getKey())
                                    .setValue(String.valueOf(entry.getValue()));
                        }

                        // Save the scores for each Domain as strings
                        for (Map.Entry<String, Integer> entry : domainScores.entrySet()) {
                            userAnswersRef.child(userId)
                                    .child("Attempt_" + attemptNumber)
                                    .child("DomainScores")
                                    .child(entry.getKey())
                                    .setValue(String.valueOf(entry.getValue()));
                        }

                        // Update the timestamp
                        userAnswersRef.child(userId)
                                .child("Attempt_" + attemptNumber)
                                .child("Last Updated")
                                .setValue(getCurrentTime())
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(QuestionsActivity.this, "Answer submitted.", Toast.LENGTH_SHORT).show();
                                    scheduleNotificationInOneMinute();
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("QuestionsActivity", "Failed to submit answer", e);
                                    Toast.makeText(QuestionsActivity.this, "Failed to submit answer", Toast.LENGTH_SHORT).show();
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("QuestionsActivity", "Failed to calculate total score", databaseError.toException());
                        Toast.makeText(QuestionsActivity.this, "Failed to calculate total score", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private String getNCDCategorisation(int totalScore) {
        if (totalScore >= 0 && totalScore <= 40) {
            return "NO NCD";
        } else if (totalScore >= 41 && totalScore <= 75) {
            return "Mild NCD";
        } else if (totalScore >= 76 && totalScore <= 100) {
            return "Major NCD";
        } else {
            return "Invalid Score"; // Just a safety check, though this case shouldn't occur
        }
    }


    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(System.currentTimeMillis());
    }

    private int getScoreForAnswer(String selectedAnswer) {
        if (selectedAnswer == null) return 0;
        switch (selectedAnswer) {
            case "None or not at all":
                return 0;
            case "Rare, less than a day or two":
                return 1;
            case "Mild, several days":
                return 2;
            case "Moderate, more than half the days":
                return 3;
            case "Severe, nearly every day":
                return 4;
            default:
                return 0;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Dementia Tester Notification";
            String description = "Channel for dementia tester app notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(NotificationReceiver.CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    private void showAlarmPermissionDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("This app requires permission to schedule exact alarms for timely notifications. Please enable this permission in settings.")
                .setPositiveButton("Go to Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }
}
