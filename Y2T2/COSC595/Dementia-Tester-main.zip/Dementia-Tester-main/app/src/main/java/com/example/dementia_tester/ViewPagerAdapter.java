package com.example.dementia_tester;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerAdapter extends FragmentStateAdapter {

    private final String userId;

    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity, String userId) {
        super(fragmentActivity);
        this.userId = userId;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 0) {
            return new DailyTasksFragment();
        } else if (position == 1) {
            return GraphFragment.newInstance(userId);
        } else if (position == 2) {
            return new MemoryGamesFragment();
        } else {
            return GraphFragment.newInstance(userId);
        }
    }


    @Override
    public int getItemCount() {
        return 3;
    }
}
