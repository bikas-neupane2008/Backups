package com.example.dementia_tester;

public class Question {
    private int questionNumber;
    private String domain;
    private String cognitiveSituation;
    private String questionText;
    private String option1;
    private String option2;
    private String option3;
    private String option4;
    private String option5;

    public Question(){

    }

    public Question(int questionNumber, String domain, String cognitiveSituation, String questionText, String option1, String option2, String option3, String option4, String option5) {
        this.questionNumber = questionNumber;
        this.domain = domain;
        this.cognitiveSituation = cognitiveSituation;
        this.questionText = questionText;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.option4 = option4;
        this.option5 = option5;
    }

    // Getters and setters
    public int getQuestionNumber() {
        return questionNumber;
    }

    public String getDomain() {
        return domain;
    }

    public String getCognitiveSituation() {
        return cognitiveSituation;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getOption1() {
        return option1;
    }

    public String getOption2() {
        return option2;
    }

    public String getOption3() {
        return option3;
    }

    public String getOption4() {
        return option4;
    }

    public String getOption5() {
        return option5;
    }
}
