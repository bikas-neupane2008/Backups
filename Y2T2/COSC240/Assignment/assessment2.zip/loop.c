#include <stdio.h>
#include <stdlib.h>

// The values being used by this program
// From Task 1
#define VALUE_MULTIPLIER 1
// From Task 1
#define VALUE_ADDED 52
// From Task 1
#define VALUES_SIZE 8
// From Task 1
int values[] = {7, 5, 6, 9, 6, 3, 2, 4};

// The value being calculated by this program
int total = 0;

// Perform a calculation on the given value
int calculate_value(int value) {
    return VALUE_MULTIPLIER * value + VALUE_ADDED;
}

// Program entry point
// Command line arguments are ignored
int main(int argc, char *argv[]) {
    for (int i = 0; i < VALUES_SIZE; i++) {
        total += calculate_value(values[i]);
    }
    printf("%d\n", total);
}
