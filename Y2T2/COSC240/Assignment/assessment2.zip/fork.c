#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  // Required for fork(), pipe(), and related system calls
#include <sys/wait.h>  // Required for wait(), waitpid()

// The values being used by this program
// From Task 1
#define VALUE_MULTIPLIER 1
// From Task 1
#define VALUE_ADDED 52
// From Task 1
#define VALUES_SIZE 8
// From Task 1
int values[] = {7, 5, 6, 9, 6, 3, 2, 4};

// The value being calculated by this program
int total = 0;

// Perform a calculation on the given value
int calculate_value(int value) {
    return VALUE_MULTIPLIER * value + VALUE_ADDED;
}

// Program entry point
// Command line arguments are ignored
int main(int argc, char *argv[]) {
    // Create a pipe for inter-process communication
    // pipefd[0] is the read end, pipefd[1] is the write end
    int pipefd[2];
    pipe(pipefd);  // Initialize the pipe to facilitate communication between processes

    // Loop over the values array
    for (int i = 0; i < VALUES_SIZE; i++) {
        // Fork a new process for each value in the array
        pid_t pid = fork();

        // In the child process
        if (pid == 0) {
            // Calculate the value using the formula defined in calculate_value()
            int calculated = calculate_value(values[i]);
            
            // Close the read end of the pipe in the child process as it won't be reading data
            close(pipefd[0]);
            
            // Write the calculated value to the write end of the pipe
            write(pipefd[1], &calculated, sizeof(int));
            
            // Close the write end of the pipe after writing to ensure proper communication
            close(pipefd[1]);
            
            // Terminate the child process after completing its task
            exit(0);
        }
    }

    // Close the write end of the pipe in the parent process as it will only be reading data
    close(pipefd[1]);

    // Parent process reads the calculated values from the pipe
    for (int i = 0; i < VALUES_SIZE; i++) {
        int calculated;
        
        // Read the next calculated value from the read end of the pipe
        read(pipefd[0], &calculated, sizeof(int));
        
        // Accumulate the calculated value into the total
        total += calculated;
    }

    // Close the read end of the pipe after all values have been read
    close(pipefd[0]);

    // Wait for all child processes to finish
    for (int i = 0; i < VALUES_SIZE; i++) {
        wait(NULL);  // wait(NULL) blocks until one of the child processes terminates
    }

    // Print the final total calculated by accumulating values from all child processes
    printf("%d\n", total);
}
