#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>  // Include the pthread library for POSIX thread functions

// The values being used by this program
// From Task 1
#define VALUE_MULTIPLIER 1
// From Task 1
#define VALUE_ADDED 52
// From Task 1
#define VALUES_SIZE 8
// From Task 1
int values[] = {7, 5, 6, 9, 6, 3, 2, 4};

// The value being calculated by this program
// This value will be modified by multiple threads, so we need to protect it with a mutex
int total = 0;

// Declare a mutex to ensure thread-safe access to the 'total' variable
pthread_mutex_t total_mutex;

// Perform a calculation on the given value
// This function calculates a value using the VALUE_MULTIPLIER and VALUE_ADDED constants
int calculate_value(int value) {
    return VALUE_MULTIPLIER * value + VALUE_ADDED;
}

// Function to be executed by each thread
// The function takes a pointer to an integer as an argument, calculates a value using that integer,
// and safely adds the result to the 'total' variable by locking and unlocking the mutex.
void* thread_function(void* arg) {
    int value = *(int*)arg;  // Dereference the passed pointer to get the value
    int calculated = calculate_value(value);  // Calculate the result using the calculate_value function

    // Lock the mutex before modifying the shared 'total' variable to prevent race conditions
    pthread_mutex_lock(&total_mutex);
    total += calculated;  // Safely add the calculated value to 'total'
    // Unlock the mutex after modifying 'total' to allow other threads to proceed
    pthread_mutex_unlock(&total_mutex);

    return NULL;  // Return NULL as the thread function's return type is void*
}

// Program entry point
// Command line arguments are ignored
int main(int argc, char *argv[]) {
    pthread_t threads[VALUES_SIZE];  // Create an array of thread identifiers, one for each value in 'values'

    // Initialize the mutex before creating threads
    pthread_mutex_init(&total_mutex, NULL);

    // Loop through each value in 'values' and create a new thread to process that value
    for (int i = 0; i < VALUES_SIZE; i++) {
        // Create a new thread that runs the thread_function, passing the address of the current value as an argument
        pthread_create(&threads[i], NULL, thread_function, &values[i]);
    }

    // Wait for all threads to complete execution
    // pthread_join ensures that the main thread waits for each created thread to finish before proceeding
    for (int i = 0; i < VALUES_SIZE; i++) {
        pthread_join(threads[i], NULL);
    }

    // Destroy the mutex after all threads have completed and 'total' is fully updated
    pthread_mutex_destroy(&total_mutex);

    // Print the final value of 'total' after all threads have completed their work
    printf("%d\n", total);
}
