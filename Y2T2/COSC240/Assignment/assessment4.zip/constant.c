/*
 * Constant Feedback Scheduler Implementation.
 * Processes are scheduled in 4 feedback queues, each with a quantum of 3 time steps.
 * Higher priority queues (lower index) are scheduled first.
 * Author: Bikash Neupane (bneupan2@myune.edu.au)
 */
#include <stdio.h>
#include <stdlib.h>

#define NUM_QUEUES 4   // Define the number of feedback queues
#define QUANTUM 3      // Define the quantum for each queue

// Structure to represent a process in the constant feedback scheduler
typedef struct constant_process {
    unsigned int pid;               // Process ID
    unsigned int processing_time;    // Total processing time required
    unsigned int arrival_time;       // Arrival time of the process
    unsigned int processed_time;     // Time the process has been processed so far
    unsigned int current_queue;      // Track which queue the process is in (0 to 3)
    struct constant_process *next_process; // Pointer to the next process in the queue
} constant_process;

// Array of pointers to represent the 4 feedback queues
constant_process *queues[NUM_QUEUES] = {NULL, NULL, NULL, NULL};

// Static variables to track the current process and quantum counter
static constant_process *current_process = NULL;
static unsigned int quantum_counter = 0;

/*
 * Prints the list of processes in the queue for debugging purposes.
 * Parameters:
 *   node - The process to start printing from.
 */
void print_queue(constant_process *node) {
    while (node) {
        printf("PID: %d, Queue: %d, Arrival: %d, Processing: %d, Processed: %d\n",
               node->pid, node->current_queue, node->arrival_time, node->processing_time, node->processed_time);
        node = node->next_process;
    }
}

/*
 * Adds a process to the specified queue.
 * Parameters:
 *   queue - The queue number (0 to 3) to add the process to.
 *   process - The process to add to the queue.
 */
void add_to_queue(int queue, constant_process *process) {
    process->next_process = queues[queue];
    queues[queue] = process;
}

/*
 * Removes and returns the first process from the specified queue.
 * Parameters:
 *   queue - The queue number (0 to 3) from which the process is removed.
 * Returns:
 *   The removed process, or NULL if the queue is empty.
 */
constant_process* remove_from_queue(int queue) {
    if (queues[queue] == NULL) {
        return NULL;
    }

    constant_process *removed_process = queues[queue];
    queues[queue] = queues[queue]->next_process;
    removed_process->next_process = NULL;
    return removed_process;
}

/*
 * Adds a new process to the system.
 * All new processes start in Queue 0 (highest priority queue).
 * Parameters:
 *   process - The process to add to the ready queue.
 */
void add_to_ready_queue(const process_initial process) {
    // Create and initialize a new process
    constant_process *new_process = malloc(sizeof(constant_process));
    if (!new_process) {
        perror("Failed to allocate memory for new process");
        exit(EXIT_FAILURE);
    }
    new_process->pid = process.pid;
    new_process->processing_time = process.processing_time;
    new_process->arrival_time = process.arrival_time;
    new_process->processed_time = 0;
    new_process->current_queue = 0; // New processes start in the highest priority queue
    new_process->next_process = NULL;

    // Add the new process to Queue 0
    add_to_queue(0, new_process);
}

/*
 * Checks if all the feedback queues are empty.
 * Returns:
 *   1 if all queues are empty, otherwise 0.
 */
int all_queues_empty() {
    for (int i = 0; i < NUM_QUEUES; i++) {
        if (queues[i] != NULL) {
            return 0; // Found a non-empty queue
        }
    }
    return 1; // All queues are empty
}

/*
 * Retrieves the next process to be scheduled based on the constant feedback scheduling algorithm.
 * The process runs for a maximum of 3 time steps (quantum) before moving to a lower priority queue.
 * Returns:
 *   The PID of the next scheduled process, or 0 if no process is ready.
 */
unsigned int get_next_scheduled_process() {
    // Check if a new process needs to be selected
    if (current_process == NULL || quantum_counter >= QUANTUM || current_process->processed_time >= current_process->processing_time) {
        // If the current process has completed, free its memory
        if (current_process != NULL && current_process->processed_time >= current_process->processing_time) {
            free(current_process);
            current_process = NULL;
        }
        // If the process has exceeded its quantum but hasn't completed, move it to the next lower queue
        else if (current_process != NULL && quantum_counter >= QUANTUM) {
            if (current_process->current_queue < NUM_QUEUES - 1) {
                current_process->current_queue++; // Move to lower priority queue
            }
            add_to_queue(current_process->current_queue, current_process); // Reinsert the process in the lower queue
            current_process = NULL;
        }

        // Find the next process from the highest non-empty queue
        for (int i = 0; i < NUM_QUEUES; i++) {
            current_process = remove_from_queue(i);
            if (current_process != NULL) {
                break; // Found a process to schedule
            }
        }

        // Reset the quantum counter for the new process
        quantum_counter = 0;
    }

    // If there's a current process, execute it for one time step
    if (current_process) {
        current_process->processed_time++;
        quantum_counter++;

        // Return the PID of the currently running process
        return current_process->pid;
    }

    // No process is ready to run
    return 0;
}

