/*
 * Custom Scheduling Algorithm
 * Combines features like dynamic quantum adjustment, boosted aging, real-time scheduling,
 * and I/O vs. CPU-bound process distinction to create an adaptive scheduler.
 * Author: Bikash Neupane (bneupan2@myune.edu.au)
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define INITIAL_QUANTUM 3        // Starting quantum for processes
#define MAX_QUANTUM 8            // Maximum allowed quantum for any process
#define MIN_QUANTUM 1            // Minimum allowed quantum for any process
#define BOOST_THRESHOLD 10       // Time threshold to boost aging for starved processes
#define DEADLINE_BOOST 5         // Priority boost for processes close to their deadline
#define IO_BOUND_RATIO 2         // Ratio to determine if a process is I/O bound
#define CPU_BOUND_RATIO 2        // Ratio to determine if a process is CPU bound

/* Structure to represent a process in the custom scheduling algorithm */
typedef struct custom_process {
    unsigned int pid;              // Process ID
    unsigned int processing_time;   // Total processing time required
    unsigned int arrival_time;      // Time at which the process arrives
    unsigned int processed_time;    // Time the process has been processed
    unsigned int quantum;           // Current quantum of the process
    unsigned int last_scheduled;    // Last time the process was scheduled
    unsigned int priority;          // Priority of the process (higher is more urgent)
    unsigned int deadline;          // Deadline of the process
    unsigned int io_burst;          // Count of I/O bursts for I/O-bound processes
    unsigned int cpu_burst;         // Count of CPU bursts for CPU-bound processes
    struct custom_process *next_process;  // Pointer to the next process in the ready queue
} custom_process;

/* The ready queue for all processes */
custom_process *ready_queue = NULL;

/* Track the current running process */
static custom_process *current_process = NULL;
static unsigned int current_time = 0;  // Track the current time in the system

/*
 * Adds a process to the ready queue, maintaining the order by priority and deadline.
 * Parameters:
 *   process: The new process to add to the ready queue.
 */
void add_to_ready_queue(const process_initial process) {
    custom_process *new_process = malloc(sizeof(custom_process));
    if (!new_process) {
        perror("Failed to allocate memory for new process");
        exit(EXIT_FAILURE);
    }
    
    // Initialize the new process details
    new_process->pid = process.pid;
    new_process->processing_time = process.processing_time;
    new_process->arrival_time = process.arrival_time;
    new_process->processed_time = 0;
    new_process->quantum = INITIAL_QUANTUM;  // Set initial quantum
    new_process->last_scheduled = current_time;
    new_process->priority = 0;  // Default priority
    new_process->deadline = process.arrival_time + process.processing_time * 2;  // Arbitrary deadline
    new_process->io_burst = 0;
    new_process->cpu_burst = 0;
    new_process->next_process = NULL;

    // Insert into the ready queue sorted by priority and deadline
    custom_process *node = ready_queue, *prev = NULL;
    while (node && (node->priority > new_process->priority || 
            (node->priority == new_process->priority && node->deadline < new_process->deadline))) {
        prev = node;
        node = node->next_process;
    }
    
    // Insert the new process into the queue
    if (prev) {
        prev->next_process = new_process;
    } else {
        ready_queue = new_process;
    }
    new_process->next_process = node;
}

/*
 * Checks if the ready queue is empty.
 * Returns: 1 if the ready queue is empty, otherwise 0.
 */
int is_ready_queue_empty() {
    return ready_queue == NULL;
}

/*
 * Removes and returns the first process from the ready queue.
 * Returns: The process removed from the ready queue.
 */
custom_process* remove_from_ready_queue() {
    if (is_ready_queue_empty()) return NULL;
    
    custom_process *removed_process = ready_queue;
    ready_queue = ready_queue->next_process;
    removed_process->next_process = NULL;
    
    return removed_process;
}

/*
 * Adjusts the quantum of the current process based on its CPU/I-O bound behavior.
 * Parameters:
 *   process: The process whose quantum will be adjusted.
 */
void adjust_quantum(custom_process *process) {
    if (process->cpu_burst > CPU_BOUND_RATIO * process->io_burst) {
        // If the process is CPU-bound, increase the quantum
        process->quantum = (process->quantum < MAX_QUANTUM) ? process->quantum * 2 : MAX_QUANTUM;
    } else if (process->io_burst > IO_BOUND_RATIO * process->cpu_burst) {
        // If the process is I/O-bound, decrease the quantum
        process->quantum = (process->quantum > MIN_QUANTUM) ? process->quantum / 2 : MIN_QUANTUM;
    }
}

/*
 * Boosts aging for processes that have been waiting too long.
 * Increases the priority of processes that have not been scheduled for a long time.
 */
void boost_aging() {
    custom_process *node = ready_queue;
    while (node) {
        if (current_time - node->arrival_time > BOOST_THRESHOLD) {
            node->priority += 1;  // Boost priority if the process is starved
        }
        node = node->next_process;
    }
}

/*
 * Implements real-time scheduling by boosting priority for processes nearing their deadlines.
 */
void apply_real_time_boost() {
    custom_process *node = ready_queue;
    while (node) {
        if (node->deadline - current_time < DEADLINE_BOOST) {
            node->priority += 2;  // Boost priority for processes close to their deadline
        }
        node = node->next_process;
    }
}

/*
 * Retrieves the next process to be scheduled based on the custom algorithm.
 * Returns: The PID of the next process to be scheduled, or 0 if no process should be scheduled.
 */
unsigned int get_next_scheduled_process() {
    // Boost aging for long-waiting processes
    boost_aging();

    // Apply real-time scheduling boost for processes nearing deadlines
    apply_real_time_boost();

    // Check if the current process has completed or needs to be replaced
    if (!current_process || current_process->processed_time >= current_process->processing_time) {
        if (current_process) {
            free(current_process);  // Free completed process
            current_process = NULL;
        }

        // Get the next process from the ready queue
        current_process = remove_from_ready_queue();
        
        if (current_process) {
            current_process->last_scheduled = current_time;  // Update scheduling time
            adjust_quantum(current_process);  // Adjust quantum based on process behavior
        }
    }

    // If there is a current process, run it for one time step
    if (current_process) {
        current_process->processed_time++;
        current_process->cpu_burst++;

        // Simulate I/O vs CPU-bound behavior based on process bursts
        if (current_process->processed_time % current_process->quantum == 0) {
            current_process->io_burst++;  // Assume I/O-bound behavior every quantum cycle
        }

        return current_process->pid;  // Return the PID of the running process
    }

    return 0;  // No process is ready to run
}

/*
 * Prints the current status of the ready queue for debugging purposes.
 */
void print_ready_queue() {
    custom_process *node = ready_queue;
    printf("Ready Queue Status:\n");
    while (node) {
        printf("PID: %d, Priority: %d, Quantum: %d, Remaining: %d\n",
               node->pid, node->priority, node->quantum, node->processing_time - node->processed_time);
        node = node->next_process;
    }
}

