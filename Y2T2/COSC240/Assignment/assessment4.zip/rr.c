/*
 * An implementation of Round Robin (RR) scheduling with a quantum of 3 time steps.
 * Author: Bikash Neupane (bneupan2@myune.edu.au)
 */

#include <stdio.h>
#include <stdlib.h>

// Define the structure to represent each process in the Round Robin scheduling algorithm.
typedef struct rr_process {
    unsigned int pid;               // Process ID
    unsigned int processing_time;    // Total processing time required for the process
    unsigned int arrival_time;       // Time at which the process arrives
    unsigned int processed_time;     // Time already spent processing the process
    struct rr_process *next_process; // Pointer to the next process in the ready queue
} rr_process;

// Define a global process list, which serves as the head of the ready queue.
rr_process process_list = {0, 0, 0, 0, NULL};

// Define the time quantum for the Round Robin scheduling algorithm.
#define QUANTUM 3

// Enable/disable debug mode with a flag. Set to 1 to enable debug prints.
#define DEBUG 0

// Variables to track the current process being executed and the quantum counter.
static rr_process *current_process = NULL;
static unsigned int quantum_counter = 0;

/*
 * Prints the list of all processes starting from the given node.
 * This function helps in debugging by displaying the state of the process list.
 * Parameters:
 *   node - The process node to start printing from.
 */
void print_list(rr_process *node) {
    while (node->next_process) {
        rr_process *next = node->next_process;
        printf("pid: %d, processing_time: %d, arrival_time: %d, processed_time: %d, next_process.pid: %d\n",
               next->pid,
               next->processing_time,
               next->arrival_time,
               next->processed_time,
               next->next_process ? next->next_process->pid : 0);
        node = node->next_process;
    }
}

/*
 * Adds the next process after a given node in the process list.
 * This function helps maintain the linked list structure of the process queue.
 * Parameters:
 *   node - The current process in the list.
 *   next - The new process to be added after the current node.
 */
void add_next(rr_process *node, rr_process *next) {
    next->next_process = node->next_process;
    node->next_process = next;
}

/*
 * Removes the next process from the given node in the process list.
 * Returns the removed process, allowing it to be freed or moved in the queue.
 * Parameters:
 *   node - The current process in the list from which the next process is to be removed.
 * Returns:
 *   The process that was removed from the queue.
 */
rr_process* remove_next(rr_process *node) {
    rr_process *next = node->next_process;
    if (next) {
        node->next_process = next->next_process;
    }
    return next;
}

/*
 * Moves the specified process to the end of the ready queue.
 * This is used when a process's quantum expires but it has not yet finished processing.
 * Parameters:
 *   proc - The process to be moved to the end of the queue.
 */
void move_to_end(rr_process *proc) {
    // Find and remove the process from its current position in the queue.
    rr_process *prev = &process_list;
    while (prev->next_process && prev->next_process != proc) {
        prev = prev->next_process;
    }
    if (prev->next_process == proc) {
        prev->next_process = proc->next_process;
        proc->next_process = NULL;
        
        // Find the end of the queue and append the process there.
        rr_process *end = &process_list;
        while (end->next_process) {
            end = end->next_process;
        }
        add_next(end, proc);
    }
}

/*
 * Adds a new process to the ready queue based on its arrival time and process ID.
 * The processes are inserted in the correct order in the list (by arrival time and PID).
 * Parameters:
 *   process - The new process to be added to the queue.
 */
void add_to_ready_queue(const process_initial process) {
    // Allocate memory for the new process.
    rr_process *new_process = malloc(sizeof(rr_process));
    if (!new_process) {
        perror("Failed to allocate memory for new process");
        exit(EXIT_FAILURE);
    }
    // Initialize the new process's attributes.
    new_process->pid = process.pid;
    new_process->processing_time = process.processing_time;
    new_process->arrival_time = process.arrival_time;
    new_process->processed_time = 0;
    new_process->next_process = NULL;

    // Find the appropriate position in the ready queue to insert the new process.
    rr_process *end = &process_list;
    while (end->next_process && end->next_process->arrival_time < new_process->arrival_time) {
        end = end->next_process;
    }
    while (end->next_process && end->next_process->arrival_time == new_process->arrival_time && end->next_process->pid < new_process->pid) {
        end = end->next_process;
    }
    // Insert the new process in the correct position.
    add_next(end, new_process);

    // Debugging: Print the process list after adding a new process, if debug mode is enabled.
    if (DEBUG) {
        printf("Process list after adding process with pid %d:\n", process.pid);
        print_list(&process_list);
    }
}

/*
 * Retrieves the next process to be scheduled based on the Round Robin scheduling algorithm.
 * It checks the current process and the quantum counter to determine whether to continue
 * with the current process or switch to the next one.
 * Returns:
 *   The PID of the next process to be scheduled, or 0 if no process is ready to be scheduled.
 */
unsigned int get_next_scheduled_process() {
    // Check if the current process needs to be swapped out due to quantum expiration or completion.
    if (current_process == NULL || quantum_counter >= QUANTUM || current_process->processed_time >= current_process->processing_time) {
        // If the current process has finished execution, remove it from the queue and free its memory.
        if (current_process != NULL && current_process->processed_time >= current_process->processing_time) {
            rr_process *node = &process_list;
            while (node->next_process && node->next_process != current_process) {
                node = node->next_process;
            }
            if (node->next_process == current_process) {
                remove_next(node);
                free(current_process);
            }
            current_process = NULL;
            quantum_counter = 0;
        } 
        // If the quantum expired but the process is not yet complete, move it to the end of the queue.
        else if (current_process != NULL && quantum_counter >= QUANTUM && current_process->processed_time < current_process->processing_time) {
            move_to_end(current_process);
            current_process = NULL;
            quantum_counter = 0;
        }

        // Select the next process from the ready queue.
        rr_process *node = &process_list;
        rr_process *next_proc = NULL;

        if (node->next_process) {
            next_proc = node->next_process;
            current_process = next_proc;
            quantum_counter = 0;
        }
    }

    // If there is a current process, execute it for one time step and increment the quantum counter.
    if (current_process) {
        current_process->processed_time++;
        quantum_counter++;

        // Debugging: Print the process being executed, if debug mode is enabled.
        if (DEBUG) {
            printf("Running PID %d at time step (processed_time: %d, quantum_counter: %d)\n",
                   current_process->pid,
                   current_process->processed_time,
                   quantum_counter);
        }

        // Return the PID of the process being executed.
        return current_process->pid;
    }

    // Return 0 if no process is ready to be executed.
    return 0;
}

