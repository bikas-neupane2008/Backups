/*
 * Exponential Feedback Scheduler Implementation.
 * Processes are scheduled in 4 feedback queues with exponentially increasing quantum times.
 * Queue 1: Quantum = 1, Queue 2: Quantum = 2, Queue 3: Quantum = 4, Queue 4: Quantum = 8
 * Higher priority queues (lower index) are scheduled first.
 * Author: Bikash Neupane (bneupan2@myune.edu.au)
 */

#include <stdio.h>
#include <stdlib.h>

#define NUM_QUEUES 4  // Number of feedback queues
unsigned int quanta[NUM_QUEUES] = {1, 2, 4, 8};  // Exponentially increasing quantum times for each queue

// Structure to represent a process in the Exponential Feedback Scheduler
typedef struct exponential_process {
    unsigned int pid;                // Process ID
    unsigned int processing_time;     // Total time required to complete the process
    unsigned int arrival_time;        // Time the process arrived
    unsigned int processed_time;      // Time the process has already been processed
    unsigned int current_queue;       // Current queue the process is in (0 to 3)
    struct exponential_process *next_process;  // Pointer to the next process in the queue
} exponential_process;

// Array to represent the 4 feedback queues
exponential_process *queues[NUM_QUEUES] = {NULL, NULL, NULL, NULL};

// Static variables to track the current running process and the quantum counter
static exponential_process *current_process = NULL;
static unsigned int quantum_counter = 0;

/*
 * Prints the list of processes in a specific queue for debugging purposes.
 * Parameters:
 *   node - Pointer to the process from which to start printing.
 */
void print_queue(exponential_process *node) {
    while (node) {
        printf("PID: %d, Queue: %d, Arrival: %d, Processing: %d, Processed: %d\n",
               node->pid, node->current_queue, node->arrival_time, node->processing_time, node->processed_time);
        node = node->next_process;
    }
}

/*
 * Adds a process to the specified feedback queue.
 * Parameters:
 *   queue - Queue index (0 to 3) where the process should be added.
 *   process - Pointer to the process to be added to the queue.
 */
void add_to_queue(int queue, exponential_process *process) {
    process->next_process = queues[queue];  // Insert process at the head of the queue
    queues[queue] = process;  // Update the queue head to point to the new process
}

/*
 * Removes and returns the first process from the specified queue.
 * Parameters:
 *   queue - Queue index (0 to 3) from which to remove the process.
 * Returns:
 *   Pointer to the removed process, or NULL if the queue is empty.
 */
exponential_process* remove_from_queue(int queue) {
    if (queues[queue] == NULL) {
        return NULL;  // Return NULL if the queue is empty
    }

    // Remove the process from the front of the queue
    exponential_process *removed_process = queues[queue];
    queues[queue] = queues[queue]->next_process;  // Update the queue head
    removed_process->next_process = NULL;  // Unlink the process
    return removed_process;  // Return the removed process
}

/*
 * Adds a new process to the system, placing it in the highest priority queue (Queue 0).
 * Parameters:
 *   process - The process to be added to the ready queue.
 */
void add_to_ready_queue(const process_initial process) {
    exponential_process *new_process = malloc(sizeof(exponential_process));  // Allocate memory for the new process
    if (!new_process) {
        perror("Failed to allocate memory for new process");  // Handle memory allocation failure
        exit(EXIT_FAILURE);
    }

    // Initialize the new process
    new_process->pid = process.pid;
    new_process->processing_time = process.processing_time;
    new_process->arrival_time = process.arrival_time;
    new_process->processed_time = 0;
    new_process->current_queue = 0;  // Start in the highest priority queue (Queue 0)
    new_process->next_process = NULL;

    // Add the new process to Queue 0 (highest priority)
    add_to_queue(0, new_process);
}

/*
 * Checks if all feedback queues are empty.
 * Returns:
 *   1 if all queues are empty, 0 if any queue contains a process.
 */
int all_queues_empty() {
    for (int i = 0; i < NUM_QUEUES; i++) {
        if (queues[i] != NULL) {  // Check if any queue is non-empty
            return 0;  // Return 0 if at least one queue has a process
        }
    }
    return 1;  // Return 1 if all queues are empty
}

/*
 * Retrieves the next process to be scheduled based on the Exponential Feedback Scheduling algorithm.
 * The process runs for its assigned quantum, then moves to the next lower priority queue if not completed.
 * Returns:
 *   The PID of the next scheduled process, or 0 if no process is ready.
 */
unsigned int get_next_scheduled_process() {
    // Check if a new process needs to be selected
    if (current_process == NULL || quantum_counter >= quanta[current_process->current_queue] || current_process->processed_time >= current_process->processing_time) {
        // If the current process has completed, free its memory and reset
        if (current_process != NULL && current_process->processed_time >= current_process->processing_time) {
            free(current_process);
            current_process = NULL;
        }
        // If the current process has used up its quantum but hasn't completed, move it to a lower queue
        else if (current_process != NULL && quantum_counter >= quanta[current_process->current_queue]) {
            if (current_process->current_queue < NUM_QUEUES - 1) {
                current_process->current_queue++;  // Move to the next lower priority queue
            }
            add_to_queue(current_process->current_queue, current_process);  // Re-add process to the appropriate queue
            current_process = NULL;
        }

        // Select the next process from the highest non-empty queue
        for (int i = 0; i < NUM_QUEUES; i++) {
            current_process = remove_from_queue(i);  // Remove process from the highest priority queue
            if (current_process != NULL) {
                break;  // Exit the loop once a process is selected
            }
        }

        quantum_counter = 0;  // Reset the quantum counter for the newly selected process
    }

    // If a process is selected, increment its processed time and quantum counter
    if (current_process) {
        current_process->processed_time++;  // Process the current process for one time unit
        quantum_counter++;  // Increment the quantum counter

        return current_process->pid;  // Return the PID of the current process
    }

    return 0;  // Return 0 if no process is ready to be scheduled
}

