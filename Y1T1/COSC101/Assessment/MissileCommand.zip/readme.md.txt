Controls
Mouse click: Fires a counter-missile to the clicked location.
ENTER key: Starts a new game or restart if the game is over.
ESC key: Exits the game.

Running the Game
Before running the game make sure the library required i.e Sound and GifAnimation is installed in the Processing environment.
To run the game, open the .pde file in Processing and click the "Run" button. Make sure all images and sound files are located in the sources folder.

The game is in default in the screen size of 1200 X 900.